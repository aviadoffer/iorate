/**************************************************************************
 *
 *  ior_rand.c - the IORATE random number generation program
 *
 *  Written by Vince Westin (vince.westin@emc.com).
 *
 *  This is just a simple randomized random number generator.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_rand.c,v 1.1 2011/10/14 05:31:19 westiv Exp westiv $";

/*
 * We load fcntl for AIX early, or bad things happen
 */
#if	defined( _AIX )
#include <fcntl.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

/*
 * Solaris needs ior_mach.h to be after the above or
 *     llseek() returns 4-byte values
 *  -- Specifically this seems to be sys/types.h
 */

#include "ior_mach.h"

/*
 * main - make a random number happen
 */
int	main( int argc, char** argv )
{
    int		value;			/* final random number */
    struct timeval tp;			/* our time */
    long	seed;			/* seed to use */

    value = strlen( rcsid );		/* STOP unused complaints from compiler */

    gettimeofday( &tp, 0 );		/* get current time */
    seed = tp.tv_sec;			/* set seed to current seconds */

    seed += getpid();			/* add process ID */

    SEED( seed );			/* fix random generation */

    value = RAND();			/* finally, get the number */

    printf( "%d\n", value );		/* print the value */

    return( 0 );
}

