/**************************************************************************
 *
 *  ior_test.c - the IORATE routines to do the test
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_test.c,v 3.23 2011/11/03 15:44:20 westiv Exp westiv $";

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iorate.h"

/*
 * ior_rand_scaled - fast bounded random in [0, limit)
 *
 * Uses high-bit scaling instead of rand % N, which helps avoid low-bit bias
 * in large address ranges with very low CPU overhead.
 */
static HUGE ior_rand_scaled( ior_config *cfg, HUGE limit )
{
	unsigned long long r;
	unsigned long long n;

	if ( limit <= 1 ) {
		return( 0 );
	}

	r = (unsigned long long)
			((unsigned long) ior_rand( cfg ) & 0x7fffffffUL);
	n = (unsigned long long) limit;

	return( (HUGE)(( r * n ) >> 31 ));
}

static void ior_blocking_reset( ior_config *cfg )
{
	cfg->c_blocking_count = 0;
}

static int ior_blocking_use_shared( ior_config *cfg )
{
	return( cfg->c_shared_blocking != NULL
		&& cfg->c_shared_blocking->bq_depth > 0 );
}

static void ior_blocking_lock( ior_config *cfg )
{
	if ( !ior_blocking_use_shared( cfg )) {
		return;
	}

	while ( __sync_lock_test_and_set( &( cfg->c_shared_blocking->bq_lock ), 1 )) {
		ior_sleep_usec( cfg, 50 );
	}
}

static int ior_blocking_try_lock( ior_config *cfg )
{
	if ( !ior_blocking_use_shared( cfg )) {
		return( TRUE );
	}

	return( __sync_lock_test_and_set( &( cfg->c_shared_blocking->bq_lock ), 1 ) == 0 );
}

static void ior_blocking_unlock( ior_config *cfg )
{
	if ( ior_blocking_use_shared( cfg )) {
		__sync_lock_release( &( cfg->c_shared_blocking->bq_lock ));
	}
}

static int ior_blocking_is_producer_pat( ior_pattern *pat )
{
	return( pat->p_is_blocking && pat->p_is_unmap
		&& !pat->p_is_meta && !pat->p_is_s3 );
}

static int ior_blocking_can_consume_pat( ior_pattern *pat )
{
	return( !pat->p_is_unmap && !pat->p_is_meta && !pat->p_is_s3 );
}

static int ior_blocking_is_producer_skew( ior_skew_pat *pat )
{
	return( pat->p_is_blocking && pat->p_is_unmap );
}

static int ior_blocking_can_consume_skew( ior_skew_pat *pat )
{
	return( !pat->p_is_unmap );
}

static int ior_blocking_push( ior_config *cfg, HUGE pos, long io_size,
		ior_skew_area *area )
{
	ior_shared_blocking_queue *shared_q;

	shared_q = cfg->c_shared_blocking;
	if ( ior_blocking_use_shared( cfg )) {
		ior_blocking_lock( cfg );

		if ( shared_q->bq_count >= shared_q->bq_depth ) {
			memmove( &( shared_q->bq_entries[ 0 ] ),
				&( shared_q->bq_entries[ 1 ] ),
				(size_t)( shared_q->bq_depth - 1 )
					* sizeof( ior_blocking_entry ));
			shared_q->bq_count = shared_q->bq_depth - 1;
		}

		shared_q->bq_entries[ shared_q->bq_count ].b_pos = pos;
		shared_q->bq_entries[ shared_q->bq_count ].b_io_size = io_size;
		shared_q->bq_entries[ shared_q->bq_count ].b_area = area;
		shared_q->bq_count++;
		if ( cfg->c_shared_stats ) {
			cfg->c_shared_stats[ cfg->c_my_index ].blocking_publishes++;
		}

		ior_blocking_unlock( cfg );
		return( TRUE );
	}

	if (( cfg->c_blocking_entries == NULL ) || ( cfg->c_blocking_depth < 1 )) {
		return( FALSE );
	}

	if ( cfg->c_blocking_count >= cfg->c_blocking_depth ) {
		memmove( &( cfg->c_blocking_entries[ 0 ] ),
			&( cfg->c_blocking_entries[ 1 ] ),
			(size_t)( cfg->c_blocking_depth - 1 )
				* sizeof( ior_blocking_entry ));
		cfg->c_blocking_count = cfg->c_blocking_depth - 1;
	}

	cfg->c_blocking_entries[ cfg->c_blocking_count ].b_pos = pos;
	cfg->c_blocking_entries[ cfg->c_blocking_count ].b_io_size = io_size;
	cfg->c_blocking_entries[ cfg->c_blocking_count ].b_area = area;
	cfg->c_blocking_count++;
	if ( cfg->c_shared_stats ) {
		cfg->c_shared_stats[ cfg->c_my_index ].blocking_publishes++;
	}

	return( TRUE );
}

static int ior_blocking_pop( ior_config *cfg, long io_size,
		ior_blocking_entry *entry )
{
	long idx;
	ior_shared_blocking_queue *shared_q;

	shared_q = cfg->c_shared_blocking;
	if ( ior_blocking_use_shared( cfg )) {
		if ( shared_q->bq_count < 1 ) {
			return( FALSE );
		}

		if ( !ior_blocking_try_lock( cfg )) {
			return( FALSE );
		}

		if ( shared_q->bq_count < 1 ) {
			ior_blocking_unlock( cfg );
			return( FALSE );
		}

		for ( idx = shared_q->bq_count - 1; idx >= 0; idx-- ) {
			if ( shared_q->bq_entries[ idx ].b_io_size < io_size ) {
				continue;
			}

			*entry = shared_q->bq_entries[ idx ];
			entry->b_io_size = io_size;
			if ( idx + 1 < shared_q->bq_count ) {
				memmove( &( shared_q->bq_entries[ idx ] ),
					&( shared_q->bq_entries[ idx + 1 ] ),
					(size_t)( shared_q->bq_count - idx - 1 )
						* sizeof( ior_blocking_entry ));
			}
			shared_q->bq_count--;
			if ( cfg->c_shared_stats ) {
				cfg->c_shared_stats[ cfg->c_my_index ].blocking_consumes++;
			}
			ior_blocking_unlock( cfg );
			return( TRUE );
		}

		ior_blocking_unlock( cfg );
		return( FALSE );
	}

	if (( cfg->c_blocking_entries == NULL ) || ( cfg->c_blocking_count < 1 )) {
		return( FALSE );
	}

	for ( idx = cfg->c_blocking_count - 1; idx >= 0; idx-- ) {
		if ( cfg->c_blocking_entries[ idx ].b_io_size < io_size ) {
			continue;
		}

		*entry = cfg->c_blocking_entries[ idx ];
		entry->b_io_size = io_size;
		if ( idx + 1 < cfg->c_blocking_count ) {
			memmove( &( cfg->c_blocking_entries[ idx ] ),
				&( cfg->c_blocking_entries[ idx + 1 ] ),
				(size_t)( cfg->c_blocking_count - idx - 1 )
					* sizeof( ior_blocking_entry ));
		}
		cfg->c_blocking_count--;
		return( TRUE );
	}

	return( FALSE );
}

static int ior_blocking_remove_exact( ior_config *cfg, HUGE pos, long io_size,
		ior_skew_area *area )
{
	long idx;
	ior_shared_blocking_queue *shared_q;

	shared_q = cfg->c_shared_blocking;
	if ( ior_blocking_use_shared( cfg )) {
		ior_blocking_lock( cfg );

		for ( idx = shared_q->bq_count - 1; idx >= 0; idx-- ) {
			if (( shared_q->bq_entries[ idx ].b_pos != pos ) ||
				( shared_q->bq_entries[ idx ].b_io_size != io_size ) ||
				( shared_q->bq_entries[ idx ].b_area != area )) {
				continue;
			}

			if ( idx + 1 < shared_q->bq_count ) {
				memmove( &( shared_q->bq_entries[ idx ] ),
					&( shared_q->bq_entries[ idx + 1 ] ),
					(size_t)( shared_q->bq_count - idx - 1 )
						* sizeof( ior_blocking_entry ));
			}
			shared_q->bq_count--;
			ior_blocking_unlock( cfg );
			return( TRUE );
		}

		ior_blocking_unlock( cfg );
		return( FALSE );
	}

	if (( cfg->c_blocking_entries == NULL ) || ( cfg->c_blocking_count < 1 )) {
		return( FALSE );
	}

	for ( idx = cfg->c_blocking_count - 1; idx >= 0; idx-- ) {
		if (( cfg->c_blocking_entries[ idx ].b_pos != pos ) ||
			( cfg->c_blocking_entries[ idx ].b_io_size != io_size ) ||
			( cfg->c_blocking_entries[ idx ].b_area != area )) {
			continue;
		}

		if ( idx + 1 < cfg->c_blocking_count ) {
			memmove( &( cfg->c_blocking_entries[ idx ] ),
				&( cfg->c_blocking_entries[ idx + 1 ] ),
				(size_t)( cfg->c_blocking_count - idx - 1 )
					* sizeof( ior_blocking_entry ));
		}
		cfg->c_blocking_count--;
		return( TRUE );
	}

	return( FALSE );
}

static int ior_run_sel_pat_at( ior_config *cfg, long pat, HUGE pos )
{
	int		result;
	ior_pattern	*cur_pat;

	result = 0;
	cur_pat = &( cfg->c_pats[ pat ]);
	if ( ior_blocking_is_producer_pat( cur_pat )) {
		ior_blocking_push( cfg, pos, cur_pat->p_io_size, NULL );
	}

	cfg->c_cur_pat = pat;

	result = ior_io( cfg, cur_pat->p_read_use[ ior_rand( cfg ) % 100 ],
		cur_pat->p_io_size, pos, NULL );
	if ( result != 0 ) {
		if ( ior_blocking_is_producer_pat( cur_pat )) {
			ior_blocking_remove_exact( cfg, pos, cur_pat->p_io_size, NULL );
		}
		return( result );
	}

	cur_pat->p_pos = cfg->c_pos;

	if ( cur_pat->p_history > 0 ) {
		sprintf( msg_buf, "-->> Recording pattern %ld I/O as history element %ld [%d.%d]",
			pat + 1, cur_pat->p_hist_next + 1,
			cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
		ior_verbose( cfg, msg_buf );

		cur_pat->p_hist_records[ cur_pat->p_hist_next++ ] = pos;
		if ( cur_pat->p_hist_active < cur_pat->p_hist_next ) {
			cur_pat->p_hist_active = cur_pat->p_hist_next;
#ifdef __linux__
			/* Complete the initial history transfers before reusing their offsets. */
			if ( cfg->c_aio && cur_pat->p_hist_active == cur_pat->p_history &&
					cur_pat->p_reuse_pct > 0 ) {
				result = ior_aio_drain( cfg );
				if ( result != 0 ) {
					return( result );
				}
			}
#endif
		}
		if ( cur_pat->p_hist_next >= cur_pat->p_history ) {
			cur_pat->p_hist_next = 0;
		}
	}

	if ( !( cur_pat->p_is_seq ) ||
		    (( cur_pat->p_max_seq > 0 ) &&
			( ++( cur_pat->p_cur_seq ) >= cur_pat->p_max_seq ))) {
		ior_set_rand_pos( cfg, pat );
		cur_pat->p_cur_seq = 0;
		sprintf( msg_buf, "I/O pattern %ld new random location chosen (%ldk) [%d.%d]",
			pat + 1, (long) ( cur_pat->p_pos / 1024L ),
			cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
		ior_verbose( cfg, msg_buf );
	} else {
		if ( cur_pat->p_pos + cur_pat->p_io_size >= cur_pat->p_end ) {
			sprintf( msg_buf, "I/O pattern %ld wrapped to %ldk (%ldk >= %ldk) [%d.%d]",
				pat + 1, (long) ( cur_pat->p_start / 1024L ),
				(long) (( cur_pat->p_pos + cur_pat->p_io_size ) / 1024L ),
				(long) ( cur_pat->p_end / 1024L ),
				cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
			ior_verbose( cfg, msg_buf );
			cur_pat->p_pos = cur_pat->p_start;
			cur_pat->p_cur_seq = 0;
		}
	}

	return( result );
}

static int ior_run_skew_at( ior_config *cfg, long pat, ior_skew_list *cur_skew,
		ior_skew_pat *cur_pat, ior_skew_area *cur_area, HUGE pos )
{
	int	result;
	int	next;
#ifdef __linux__
	int	history_filled = 0;
#endif

	result = 0;
	if ( ior_blocking_is_producer_skew( cur_pat )) {
		ior_blocking_push( cfg, pos, cur_pat->p_io_size, cur_area );
	}

	if ( cur_pat->p_history > 0 ) {
		sprintf( msg_buf, "-->> Recording pattern %ld I/O as history element %ld [%d.%d]",
			pat + 1, cur_pat->p_hist_next + 1,
			cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
		ior_verbose( cfg, msg_buf );

		next = cur_pat->p_hist_next++;
		cur_pat->p_hist_records[ next ] = pos;
		cur_pat->p_hist_areas[ next ] = cur_area;

		if ( cur_pat->p_hist_active < cur_pat->p_hist_next ) {
			cur_pat->p_hist_active = cur_pat->p_hist_next;
#ifdef __linux__
			history_filled = cur_pat->p_hist_active == cur_pat->p_history &&
				cur_pat->p_reuse_pct > 0;
#endif
		}
		if ( cur_pat->p_hist_next >= cur_pat->p_history ) {
			cur_pat->p_hist_next = 0;
		}
	}

	result = ior_io( cfg, cur_pat->p_read_use[ ior_rand( cfg ) % 100 ],
		cur_pat->p_io_size, pos, cur_skew );
#ifdef __linux__
	if ( result == 0 && cfg->c_aio && history_filled ) {
		result = ior_aio_drain( cfg );
	}
#endif
	if ( result != 0 ) {
		if ( ior_blocking_is_producer_skew( cur_pat )) {
			ior_blocking_remove_exact( cfg, pos, cur_pat->p_io_size,
				cur_area );
		}
		return( result );
	}

	cur_pat->p_pos = cfg->c_pos;

	return( result );
}

/*
 * ior_run_dev_test - run a test pass on a selected drive
 */
int	ior_run_dev_test( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		done;			/* is timing done? */
    ior_test	*cur_test;		/* test we are running */
    ior_device	*cur_dev;		/* current active device */
    ior_skew_list *cur_skew;		/* currrent skew group list */
    ior_skew_area *cur_area;		/* current skew area */
    ior_clock	cur_time;		/* current time */
    ior_clock	elapsed_time;		/* time gone by */
    HUGE	o_size;			/* old size */
    HUGE	n_size;			/* new size */
    HUGE	over_size;		/* size we go over a set for this device */
    HUGE	tgt_size;		/* size needed for test */
    int		area_copies;		/* base copes of all areas */
    double	d_size;			/* percent sizing of values */
    long	shuffle_count;		/* how many areas to shuffle */
    int		group;			/* skew group we are adding to */
    int		skew_count;		/* skews in group for stats */
    int		skew_start;		/* starting skew for stats */
    int		n_skew;			/* current skew ID being added */
    HUGE	n_iops;			/* iops for this group */
    double	n_resp_time;		/* response time for this group */
    char	msg[ 200 ];		/* message buffer */
    int		i;
    
    /* Variables for realistic IO logic */
    long    last_second = 0;
    double  baseline_iops = 0.0;
    int     is_warmup = 1;

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_dev_test: Entering code -->>" );

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0;				/* all OK so far */
    done = 0;				/* time not up yet */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);

    sprintf( msg_buf, "Test starting on device %d.%d '%s'",
	    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur_dev->d_name );
    ior_debug( cfg, msg_buf );

					/* fix sizing of this test */
	/** NOTE: all locations are aligned when the random	**/
	/**       positions for the next I/O are chosen later.	**/
    if ( cur_test->t_start_pct >= 0 ) {
	d_size = cur_test->t_start_pct / 100.0;
	d_size *= cur_dev->d_capacity;
	cur_test->t_start = d_size;
	sprintf( msg_buf,
		"  --> Sizing dev %d.%d test start at %.3lf%% of %0.2fm (%0.2fm)",
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur_test->t_start_pct,
		cur_dev->d_capacity / 1048576.0,
		cur_test->t_start / 1048576.0 );
	ior_debug( cfg, msg_buf );
    };
    if ( cur_test->t_start < cur_dev->d_offset ) {
	cur_test->t_start = cur_dev->d_offset;
    };

    if ( cur_test->t_size_pct >= 0 ) {
	d_size = cur_test->t_size_pct / 100.0 ;
	d_size *= cur_dev->d_capacity;
	cur_test->t_size = d_size;
	sprintf( msg_buf,
		"  --> Sizing dev %d.%d test size to %.3lf%% of %0.2fm (%0.2fm)",
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur_test->t_size_pct,
		cur_dev->d_capacity / 1048576.0,
		cur_test->t_size / 1048576.0 );
	ior_debug( cfg, msg_buf );
    };

    if ( cur_test->t_size <= 0 ) {	/* no size set yet */
	cur_test->t_end = cur_dev->d_capacity - ( IOR_MAX_IO_SIZE * 2 );
	cur_test->t_size = cur_test->t_end - cur_test->t_start;
    };

    cur_test->t_end = cur_test->t_start + cur_test->t_size;

	    				/* wrapped, so limit the size (quiet) */
    if ( cur_test->t_end < 0 ) {
	cur_test->t_end = IOR_MAX_SEEK - IOR_MAX_IO_SIZE;
	cur_test->t_size = cur_test->t_end - cur_test->t_start;
	sprintf( msg_buf,
		"  --> Dev %d.%d test size over limit (wrapped) - fixed",
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	ior_debug( cfg, msg_buf );
    };
if ( !cur_dev->d_is_s3 && cur_test->t_end > cur_dev->d_capacity ) {
	o_size = cur_test->t_end - cur_test->t_start;

	cur_test->t_end = cur_dev->d_capacity;

	n_size = cur_test->t_end - cur_test->t_start;

	sprintf( msg_buf,
		"Test size in test %d '%s' is too large for device %d.%d:\n\t-- Reduced to %0.2fm (from %0.2fm)",
		cfg->c_cur_test + 1, cur_test->t_name,
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		n_size / 1048576.0, o_size / 1048576.0 );

					/* note change if > .1% */
	if (( o_size - n_size ) > ( o_size / 1000 )) {
	    ior_warn( cfg, msg_buf );
	} else {
	    ior_debug( cfg, msg_buf );
	};

	cur_test->t_size = n_size;
    };
if ( !cur_dev->d_is_s3 && cur_test->t_end > ( IOR_MAX_SEEK - IOR_MAX_IO_SIZE )) {
	o_size = cur_test->t_end - cur_test->t_start;

	cur_test->t_end = IOR_MAX_SEEK - IOR_MAX_IO_SIZE;

	n_size = cur_test->t_end - cur_test->t_start;

	sprintf( msg_buf,
		"Test size in test %d '%s' is too long for seek, reduced to %0.2fm",
		cfg->c_cur_test + 1, cur_test->t_name, n_size / 1048576.0 );

					/* note change if > .1% */
	if (( o_size - n_size ) > ( o_size / 1000 )) {
	    ior_warn( cfg, msg_buf );
	} else {
	    ior_debug( cfg, msg_buf );
	};

	cur_test->t_size = n_size;
    };

		/* checks for test if skew is on */
    if ( cur_test->t_skew > 0 ) {

		/* if skewed, check the size */
	if ( cur_test->t_size <
		    cur_test->t_area * IOR_AREA_MIN_PER_DRIVE ) {
	    strcpy( msg, ior_size_to_ascii( cfg, cur_test->t_area ));
	    sprintf( msg_buf, "device '%s' %d.%d: size (%s) less than %d * skew area (%s)",
		cur_dev->d_name, 
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		ior_size_to_ascii( cfg, cur_test->t_size ),
		(int)( IOR_AREA_MIN_PER_DRIVE ),
		msg );
	    ior_error( cfg, msg_buf );

	    return( -10 );
	};

		    /* note the overall sizes we are targeting */
					/* how large without wrapping */
	cfg->c_skew_set_size = cfg->c_num_areas * cur_test->t_area;
					/* number of additional copies we MAY need */
	area_copies = cur_test->t_size / cfg->c_skew_set_size;
					/* size we target ABOVE the copies */
	tgt_size = cur_test->t_size - area_copies * cfg->c_skew_set_size;

	if ( cfg->c_cur_adev < 1 ) {	/* only note for one copy of a device */
	    sprintf( msg_buf, "ior_test: device %d: unique mapped space %ldk, copies %d, overflow size %ldk",
		cfg->c_cur_dev + 1,
		(long)( cfg->c_skew_set_size / 1024L ),
		(int)( area_copies ),
		(long)( tgt_size / 1024L ));
	    ior_debug_l( cfg, IOR_DEBUG_MINOR, msg_buf );
	};

					/* no over capacity yet */
	over_size = 0;
			/* number of copies for this test */
	for ( i = 0; i < cfg->c_num_areas; i++  ) { /* walk the areas */
	    cur_area = &( cfg->c_areas[ i ]);

			/* at least base copies, 1 more if in range */
	    cur_area->a_copies = area_copies;
	    if ( over_size <= tgt_size ) {
		cur_area->a_copies++;

			/* note area added here */
		over_size += cur_test->t_area;
	    };
	};


	/* now randomize the areas in each group for more realistic simulation */
	/*    this is done here so the pattern is unique per device copy */
	/* --- note that a new random seed per test/device is set in iorate.c --- */
	for ( group = 0; group < IOR_SKEW_LISTS; group++ ) {
	    cur_skew = &( cfg->c_skewed[ group ]);
	    cur_area = cur_skew->s_areas;

					/* shuffle 100-300% - mix it up */
	    shuffle_count = ( cur_skew->s_area_current *
			( 100 + ior_rand( cfg ) % 200 )) / 100;

	    for ( ; shuffle_count > 0; shuffle_count-- ) {
					/* pick a random area */
		for ( i = ior_rand( cfg ) %
			    ( cur_skew->s_area_current - 2 );
			i > 0; i-- ) {
		    cur_area = cur_area->a_next;
		};

		sprintf( msg_buf, "randomizing: area %ld to tail of group %d - %ld more to go, %ld in group",
		    cur_area->a_id, group,
		    (long)( shuffle_count - 1 ),
		    cur_skew->s_area_current );
		ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

					/* move it to the end */
		ior_area( cfg, IOR_AREA_TAIL, cur_area, cur_skew );

		cur_area = cur_skew->s_areas;
	    };
	};

    };

    sprintf( msg_buf,
	    "    --> Ready to test dev %d.%d:\n\tStart %.2fm - Size %.2fm - End %.2fm",
	    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
	    cur_test->t_start / 1048576.0,
	    cur_test->t_size / 1048576.0,
	    cur_test->t_end / 1048576.0 );
    ior_debug( cfg, msg_buf );

    if ( cur_test->t_skew < IOR_SKEW_MIN ) {
	result = ior_test_prep_std( cfg );	/* prep for all our patterns to run */
    } else {
	result = ior_test_prep_skew( cfg );
    };

					/* open the target device */
    if ( result == 0 ) {
	result = ior_open_dev( cfg, cfg->c_cur_dev );
    };
#ifdef __linux__
    if ( result == 0 && cur_dev->d_queue_depth > 1 ) {
	result = ior_aio_open( cfg );
    };
#endif


    if ( cur_test->t_ignore < 1 ) {	/* no delay - start stats now */
	cur_test->t_running = 1;
    };

    if ( cfg->c_target_resp > 0 ) {	/* using target I/O rate */

	/* since we will be waiting, sleep for a random desired time */
	/* to avoid process contention on devices on startup */

	ior_debug( cfg, "Using target iorate, so starting with random delay" );

	ior_sleep_usec( cfg, ior_rand( cfg ) % cfg->c_target_resp );
    };

    cur_time = ior_get_time( cfg );	/* start with time */

    while ( !done && !result ) {
	long pat = cur_test->t_patterns[ ior_rand( cfg ) % IOR_TEST_PCT_SLOTS ];

#ifdef __linux__
	/* Discard must follow all earlier transfers, including for blocking UNMAP. */
	if ( cfg->c_aio && cfg->c_pats[ pat ].p_is_unmap ) {
	    result = ior_aio_drain( cfg );
	    if ( result != 0 ) {
		break;
	    }
	}
#endif
	if ( cur_test->t_skew > 0 ) {
	    result = ior_run_skew( cfg, pat );
	} else {
	    result = ior_run_pat( cfg, pat );
	};

	cur_time = ior_get_time( cfg );	/* check for time done */
	elapsed_time = cur_time - cfg->c_start_time;
	cfg->c_io_time = elapsed_time;	/* current I/O time */

    /* REALISTIC I/O LOGIC */
    if ( cfg->c_realistic_io ) {
        long current_second = (long)cfg->c_io_time;
        
        /* 
         * WARMUP LOGIC:
         * If tests.ior passed a target rate (c_target_resp > 0), use that as baseline immediately.
         * If not, wait 30 seconds to establish baseline from max speed.
         */
        if ( is_warmup ) {
            if ( cfg->c_target_resp > 0 ) {
                /* Target IOPS provided in config file - use it immediately */
                baseline_iops = 1000000.0 / cfg->c_target_resp;
                is_warmup = 0; /* No need to wait 30s */
                sprintf( msg_buf, "Realistic IO: Using config IOPS as baseline (%.2f)", baseline_iops );
                ior_debug_l( cfg, IOR_DEBUG_MINOR, msg_buf );
            } else if ( cfg->c_io_time >= 30.0 ) {
                /* No target provided - calculated from first 30s of max speed */
                is_warmup = 0;
				baseline_iops = (double)(cfg->c_reads + cfg->c_writes + cfg->c_unmaps) / cfg->c_io_time;
                sprintf( msg_buf, "Realistic IO: Warmup complete. Calculated Baseline IOPS = %.2f", baseline_iops );
                ior_debug_l( cfg, IOR_DEBUG_MINOR, msg_buf );
            }
        }

        /* Fluctuation Phase (Every Second) */
        if ( !is_warmup && current_second > last_second ) {
            last_second = current_second;
            
            /* Calculate Random Fluctuation (e.g., 0% to 15% drop) */
		    int fluctuation_pct = ior_rand( cfg ) % ( cfg->c_realistic_io_fluctuation + 1 );
            double factor = 1.0 - (double)fluctuation_pct / 100.0;
            
            double target_iops = baseline_iops * factor;
            
            /* Apply new target rate via Virtual Start Time Method */
            if ( target_iops > 0.1 ) {
                double new_target_sec = 1.0 / target_iops;
                long new_target_resp = (long)( 1000000.0 / target_iops );
                
                /*
                 * VIRTUAL START TIME CALCULATION:
                 * We are changing speed at 'cur_time'.
				 * We have completed 'total_ops' (reads+writes+unmaps).
                 * We want the Token Bucket in ior_io to see:
                 * (cur_time - VIRTUAL_START) / new_target_sec ~= total_ops
                 * So: VIRTUAL_START = cur_time - (total_ops * new_target_sec)
                 */
				HUGE total_ops = cfg->c_reads + cfg->c_writes + cfg->c_unmaps;
                double virtual_elapsed = (double)total_ops * new_target_sec;
                
                /* Update the start time so ior_io sees consistent progress */
                cfg->c_start_time = cur_time - virtual_elapsed;
                
                cfg->c_target_sec = new_target_sec;
                cfg->c_target_resp = new_target_resp;
            } 
        }
    }

	if ( !cur_test->t_running ) {
	    if ( elapsed_time >= cur_test->t_ignore ) {
#ifdef __linux__
		if ( result == 0 && cfg->c_aio ) {
		    result = ior_aio_drain( cfg );
		    if ( result != 0 ) {
			break;
		    }
		}
#endif
		cur_test->t_running = 1;
		cfg->c_reads = 0;
		cfg->c_bytes_read = 0;
		cfg->c_writes = 0;
		cfg->c_bytes_written = 0;
		cfg->c_unmaps = 0;
		cfg->c_bytes_unmapped = 0;
		cfg->c_read_time_msecs = 0;
		cfg->c_write_time_msecs = 0;
		cfg->c_unmap_time_msecs = 0;
        
        /* Reset realistic IO trackers if we just started counting stats */
        if(cfg->c_realistic_io) {
            /* If resetting stats, we must align start time to now so math works */
            cfg->c_start_time = cur_time;
        }

					/* and for each skew group */
		if ( cur_test->t_skew > 0 ) {
		    for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
			cur_skew = &( cfg->c_skewed[ i ]);

			cur_skew->s_perf.sp_rand_reads = 0;
			cur_skew->s_perf.sp_rand_read_resp = 0;
			cur_skew->s_perf.sp_seq_reads = 0;
			cur_skew->s_perf.sp_seq_read_resp = 0;
			cur_skew->s_perf.sp_rand_writes = 0;
			cur_skew->s_perf.sp_rand_write_resp = 0;
			cur_skew->s_perf.sp_seq_writes = 0;
			cur_skew->s_perf.sp_seq_write_resp = 0;
		    };
		};

#ifdef	IOR_ENGINEERIG
		ior_eng_reset_stats( cfg );
#endif

	    };
	} else {
	    cfg->c_io_time -= cur_test->t_ignore; /* no record of ignored I/Os */
	};

	if ( elapsed_time >= cur_test->t_duration ) {
	    done = 1;
	};
    };
#ifdef __linux__
    if ( cfg->c_aio ) {
	if ( result == 0 ) {
	    result = ior_aio_drain( cfg );
	    cur_time = ior_get_time( cfg );
	    cfg->c_io_time = cur_time - cfg->c_start_time - cur_test->t_ignore;
	}
	i = ior_aio_close( cfg );
	if ( result == 0 ) {
	    result = i;
	}
    }
#endif
					/* close the target device */
    if ( cfg->c_devs[ cfg->c_cur_dev ].d_is_active ) {
	i = ior_close_dev( cfg, cfg->c_cur_dev );
    } else {
	i = 0;
    };

    if ( result == 0 ) {
	result = i;			/* set result to close status */

	cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

	fprintf( cfg->c_perf_file, "%d\t%s\t%d\t%s\t%ld\t%ld", 
		cfg->c_cur_test + 1,
		cfg->c_tests[ cfg->c_cur_test ].t_name,
		cfg->c_cur_dev + 1,
		cur_dev->d_name,
		cur_time - cfg->c_start_time,
		cfg->c_io_time );

	fprintf( cfg->c_perf_file, "\t%ld\t%ld\t%.3lf",
		(long)( cfg->c_reads ),
		(long)( cfg->c_bytes_read / 1024L ),
		cfg->c_reads == 0 ? (double) 0.0 : /* no div by zero */
		    cfg->c_read_time_msecs / cfg->c_reads );

	fprintf( cfg->c_perf_file, "\t%ld\t%ld\t%.3lf",
		(long)( cfg->c_writes ), (long)( cfg->c_bytes_written / 1024L ),
		cfg->c_writes == 0 ? (double) 0.0 : /* no div by zero */
		    cfg->c_write_time_msecs / cfg->c_writes );

	fprintf( cfg->c_perf_file, "\t%ld\t%ld\t%.3lf",
		(long)( cfg->c_reads + cfg->c_writes + cfg->c_unmaps ),
		(long)(( cfg->c_bytes_read + cfg->c_bytes_written + cfg->c_bytes_unmapped ) / 1024L ),
		( cfg->c_reads + cfg->c_writes + cfg->c_unmaps ) == 0 ? (double) 0.0 :
		    ( cfg->c_read_time_msecs + cfg->c_write_time_msecs + cfg->c_unmap_time_msecs ) /
			( cfg->c_reads + cfg->c_writes + cfg->c_unmaps ));

	fprintf( cfg->c_perf_file, "\t%ld\t%ld\t%ld",
		(long)(( cfg->c_reads + cfg->c_writes + cfg->c_unmaps ) / cfg->c_io_time ),
		(long)(( cfg->c_bytes_read + cfg->c_bytes_written + cfg->c_bytes_unmapped ) /
		    1024.0 / cfg->c_io_time ),
		(long)( cfg->c_cur_adev + 1 ));

		/* add skew area performance data as well */
	if ( cur_test->t_skew > 0 ) {

		/* for DEBUG, we give data for each skew group */
	    if ( cfg->c_debug_level >= IOR_DEBUG_MAJOR ) {
		for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
		    cur_skew = &( cfg->c_skewed[ i ]);

		    fprintf( cfg->c_perf_file, "\t%ld\t%.2f\t%ld\t%.2f\t%ld\t%.2f\t%ld\t%.2f",
			    (long)( cur_skew->s_perf.sp_rand_reads  ),
			    (float)( cur_skew->s_perf.sp_rand_reads == 0 ? 0 :
				    cur_skew->s_perf.sp_rand_read_resp /
					cur_skew->s_perf.sp_rand_reads ),
			    (long)( cur_skew->s_perf.sp_seq_reads ),
			    (float)( cur_skew->s_perf.sp_seq_reads == 0 ? 0 :
				    cur_skew->s_perf.sp_seq_read_resp /
				    cur_skew->s_perf.sp_seq_reads ),
			    (long)( cur_skew->s_perf.sp_rand_writes ),
			    (float)( cur_skew->s_perf.sp_rand_writes == 0 ? 0 :
				    cur_skew->s_perf.sp_rand_write_resp /
				    cur_skew->s_perf.sp_rand_writes ),
			    (long)( cur_skew->s_perf.sp_seq_writes ),
			    (float)( cur_skew->s_perf.sp_seq_writes == 0 ? 0 :
				    cur_skew->s_perf.sp_seq_write_resp /
				    cur_skew->s_perf.sp_seq_writes ));
		};
		/* otherwise, we give data for the target regions */
	    } else {

		skew_start = 0;	/* none totaled yet */
		for ( i = 0; i < 3; i++ ) {
		    skew_count = cfg->c_skew_group_count[ i ];

		    n_iops = 0;
		    n_resp_time = 0;
		    for ( n_skew = skew_start + skew_count - 1;
			    n_skew >= skew_start; n_skew-- ) {
			cur_skew = &( cfg->c_skewed[ n_skew ]);
			n_iops += cur_skew->s_perf.sp_rand_reads;
			n_resp_time += cur_skew->s_perf.sp_rand_read_resp;
		    };
		    fprintf( cfg->c_perf_file, "\t%ld\t%.2f",
			    (long)( n_iops ),
			    (float)( n_iops == 0 ? 0 :
				( n_resp_time / n_iops )));

		    n_iops = 0;
		    n_resp_time = 0;
		    for ( n_skew = skew_start + skew_count - 1;
			    n_skew >= skew_start; n_skew-- ) {
			cur_skew = &( cfg->c_skewed[ n_skew ]);
			n_iops += cur_skew->s_perf.sp_seq_reads;
			n_resp_time += cur_skew->s_perf.sp_seq_read_resp;
		    };
		    fprintf( cfg->c_perf_file, "\t%ld\t%.2f",
			    (long)( n_iops ),
			    (float)( n_iops == 0 ? 0 :
				( n_resp_time / n_iops )));

		    n_iops = 0;
		    n_resp_time = 0;
		    for ( n_skew = skew_start + skew_count - 1;
			    n_skew >= skew_start; n_skew-- ) {
			cur_skew = &( cfg->c_skewed[ n_skew ]);
			n_iops += cur_skew->s_perf.sp_rand_writes;
			n_resp_time += cur_skew->s_perf.sp_rand_write_resp;
		    };
		    fprintf( cfg->c_perf_file, "\t%ld\t%.2f",
			    (long)( n_iops ),
			    (float)( n_iops == 0 ? 0 :
				( n_resp_time / n_iops )));

		    n_iops = 0;
		    n_resp_time = 0;
		    for ( n_skew = skew_start + skew_count - 1;
			    n_skew >= skew_start; n_skew-- ) {
			cur_skew = &( cfg->c_skewed[ n_skew ]);
			n_iops += cur_skew->s_perf.sp_seq_writes;
			n_resp_time += cur_skew->s_perf.sp_seq_write_resp;
		    };
		    fprintf( cfg->c_perf_file, "\t%ld\t%.2f",
			    (long)( n_iops ),
			    (float)( n_iops == 0 ? 0 :
				( n_resp_time / n_iops )));

		    skew_start += skew_count;
		};
	    };
	};

#ifdef	IOR_ENGINEERING
	ior_eng_test_done( cfg );
#endif

	fprintf( cfg->c_perf_file, "\n" );
	fflush( cfg->c_perf_file );
    } else {
	fprintf( cfg->c_perf_file,
		"TEST%03d,%s,FAILED,device %d copy %d\n",
		cfg->c_cur_test + 1, cfg->c_devs[ cfg->c_cur_dev ].d_name,
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	fflush( cfg->c_perf_file );

	ior_error( cfg, "BAILING out of test due to errors" );
    };

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_dev_test: <<-- Leaving code" );

    return( result );
}


/*
 * ior_test_prep_std - prepare for a non-skew test run
 */
int	ior_test_prep_std( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		cur;			/* current item in loop */
    ior_test	*cur_test;		/* test we are running */
    ior_pattern	*cur_pat;		/* current active pattern */
    HUGE	saved_start;		/* saved pattern start */
    HUGE	saved_end;		/* saved pattern end */
    HUGE	o_size;			/* old size */
    HUGE	n_size;			/* new size */
    HUGE	h_tmp;			/* huge temp value */
    double	d_size;			/* percent sizing of values */
    char	msg[ 200 ];		/* message buffer */
    int		i;

    ior_debug_l( cfg, IOR_DEBUG_MINOR, "ior_test_prep_std: Entering code -->>" );

    result = 0;				/* all OK so far */
	ior_blocking_reset( cfg );

    cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);

					/* start each pattern */
    for ( cur = 0; cur < cfg->c_npat; cur++ ) {

	cur_pat = &( cfg->c_pats[ cur ]);

					/* only check on active patterns */
	if (( !cur_pat->p_valid ) || ( cur_test->t_pat_pct[ cur ] < 1 )) {
	    continue;
	};

			/* fix sizing for this pattern */
	if ( cur_pat->p_start_pct == 0 ) {
	    cur_pat->p_start = 0;
	};
	if ( cur_pat->p_start_pct > 0 ) {
	    d_size = cur_pat->p_start_pct / 100.0 ;
	    d_size *= cur_test->t_size;
	    cur_pat->p_start = d_size;
	    sprintf( msg_buf,
		    "    --> Sizing dev %d.%d pat %d start to %.3lf%% of %0.2fm (%0.2fm)",
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		    cur + 1, cur_pat->p_start_pct,
		    cur_test->t_size / 1048576.0,
		    cur_pat->p_start / 1048576.0 );
	    ior_debug( cfg, msg_buf );
	};
	if ( cur_test->t_start > 0 ) {	/* include any offset from test */
	    cur_pat->p_start += cur_test->t_start;
	    sprintf( msg_buf,
		    "  --> Adding test start of %ldk to dev %d.%d pat %d start",
		    (long)( cur_test->t_start / 1024L ),
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur + 1 );
	    ior_debug( cfg, msg_buf );
	};
	if ( cur_pat->p_size_pct >= 0 ) {
	    d_size = cur_pat->p_size_pct / 100.0 ;
	    d_size *= cur_test->t_size;
	    cur_pat->p_size = d_size;
	    sprintf( msg_buf,
		    "    --> Sizing dev %d.%d pat %d size to %.3lf%% of %0.2fm (%0.2fm)",
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		    cur + 1, cur_pat->p_size_pct,
		    cur_test->t_size / 1048576.0,
		    cur_pat->p_size / 1048576.0 );
	    ior_debug( cfg, msg_buf );
	};
	cur_pat->p_end = cur_pat->p_start + cur_pat->p_size;

					/* check for too large */
	if ( cur_pat->p_end > cur_test->t_end ) {
	    o_size = cur_pat->p_end - cur_pat->p_start;

	    cur_pat->p_end = cur_test->t_end;

	    n_size = cur_pat->p_end - cur_pat->p_start;

	    sprintf( msg_buf,
		    "    -->> Pattern '%s' (%d) size too large for test:\n\t-- Reduced to %0.2fm",
		    cur_pat->p_name, cur + 1, n_size / 1048576.0 );

					/* note change if > .1% */
	    if (( o_size - n_size ) > ( o_size / 1000 )) {
		ior_warn( cfg, msg_buf );
	    } else {
		ior_debug( cfg, msg_buf );
	    };

	    cur_pat->p_size = n_size;
	};
					/* prep localities */
	if ( cur_pat->p_local_pct > 0 ) {
	    cur_pat->p_local_size = (HUGE)(cur_pat->p_size *
		    cur_pat->p_local_pct / 100);
	    sprintf( msg_buf, "Setting locality size to %.0f%% (%ldk)",
		    cur_pat->p_local_pct,
		    (long)( cur_pat->p_local_size / 1024L ));
	    ior_debug( cfg, msg_buf );
	};
	if ( cur_pat->p_local_size > 0 ) {

	    if ( cur_pat->p_local_size < cur_pat->p_io_size * 5 ) {
		sprintf( msg_buf,
			"Locality size too small (%ldk) in pattern %d - increased to %ldk",
			(long)( cur_pat->p_local_size / 1024L ), cur + 1,
			(long)(( cur_pat->p_io_size * 5 ) / 1024L ));
		ior_warn( cfg, msg_buf );
		cur_pat->p_local_size = cur_pat->p_io_size * 5;
	    };

	    cur_pat->p_local_avail = cur_pat->p_size / 
			( cur_pat->p_local_size * 2 );

	    if ( cur_pat->p_local_avail < 1 ) {
		sprintf( msg_buf,
			"Not enough space for even 1 locality buffer in pattern %d",
			cur + 1 );
		ior_error( cfg, msg_buf );
		cur_pat->p_local_avail = 1; /* get through the code here */
		result = -4;
	    };

	    if ( cur_pat->p_local_avail < cur_pat->p_local_count ) {
		sprintf( msg_buf,
#ifdef	IOR_LARGE_FILES
			"Available localities (%llu) less than requested (%llu)", 
			(long long unsigned)( cur_pat->p_local_avail ),
			(long long unsigned)( cur_pat->p_local_count ));
#else
			"Available localities (%lu) less than requested (%lu)", 
			(long unsigned)( cur_pat->p_local_avail ),
			(long unsigned)( cur_pat->p_local_count ));
#endif
		ior_error( cfg, msg_buf );
		result = -3;
	    };

	    sprintf( msg_buf,
		    " -->> Locality buffers: count %ld size %ldk avail %ld",
		    (long)( cur_pat->p_local_count ),
		    (long)( cur_pat->p_local_size / 1024L ),
		    (long)( cur_pat->p_local_avail ));
	    ior_debug( cfg, msg_buf );


	    saved_start = cur_pat->p_start;
	    saved_end = cur_pat->p_end;

	    for ( i = 0; i < cur_pat->p_local_count; i++) {

		sprintf( msg_buf, "Preparing locality %d", i + 1 );
		ior_verbose( cfg, msg_buf );

		cur_pat->p_local_uses[ i ] = 0;
		cur_pat->p_local_seqs[ i ] = 0;

		h_tmp = ior_rand( cfg ) % cur_pat->p_local_avail;
		h_tmp *= 2 * cur_pat->p_local_size;
		cur_pat->p_local_starts[ i ] = saved_start + h_tmp;
		cur_pat->p_local_ends[ i ] =
			cur_pat->p_local_starts[ i ] + cur_pat->p_local_size;

		cur_pat->p_start = cur_pat->p_local_starts[ i ];
		cur_pat->p_end = cur_pat->p_local_ends[ i ];
		cur_pat->p_size = cur_pat->p_end - cur_pat->p_start;

					/* and a random starting location */
		ior_set_rand_pos( cfg, cur );
		cur_pat->p_local_pos[ i ] = cur_pat->p_pos;

		sprintf( msg_buf,
			" -->> Pattern %d locality %d -- from %ldk to %ldk pos %ldk",
			cur + 1, i + 1,
			(long)( cur_pat->p_local_starts[ i ] / 1024L ),
			(long)( cur_pat->p_local_ends[ i ] / 1024L ),
			(long)( cur_pat->p_local_pos[ i ] / 1024L ));
		ior_debug( cfg, msg_buf );
	    };

	    cur_pat->p_start = saved_start;
	    cur_pat->p_end = saved_end;
	    cur_pat->p_size = cur_pat->p_end - cur_pat->p_start;
	};

	cur_pat->p_hist_active = 0;	/* no active history records */
	cur_pat->p_hist_next = 0;	/* start with item 0 */

					/* help wih code debug */
	sprintf( msg, "Pattern %d dev %d.%d: Test from %0.2fm to %0.2fm (size %0.2fm)",
		cur + 1, cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		cur_pat->p_start / 1048576.0,
		cur_pat->p_end / 1048576.0,
		cur_pat->p_size / 1048576.0 );
	ior_debug( cfg, msg );
					/* check for bad pattern sizing */
	if ( cur_pat->p_size <= ( cur_pat->p_io_size * 2 )) {
	    sprintf( msg, "Device %d.%d: Pattern %d: Too small a size (%ldk)",
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur + 1,
		(long) ( cur_pat->p_size / 1024L ));
	    ior_error( cfg, msg );
	    result = -5;		/* note we took an error */
	};
					/* with no sequential history */
	cur_pat->p_cur_seq = 0;
					/* and a random starting location */
	ior_set_rand_pos( cfg, cur );
    };

    ior_debug_l( cfg, IOR_DEBUG_MINOR, "ior_test_prep_std: <<-- Leaving code" );

    return( result );
}

/*
 * ior_run_pat - run the pattern on the given device
 */
int	ior_run_pat( ior_config *cfg, long pat )
/* ior_config	*cfg;			our configuration */
/* long		pat;			pattern to use */
{
    int		result;			/* final return code */
    ior_pattern	*cur_pat;		/* current active pattern */
    ior_pattern	saved_pat;		/* save area for local stuff */
    long	hist;			/* which history record to use */
    long	local;			/* local we are using */
    HUGE	h_tmp;			/* huge temp value */
	ior_blocking_entry block_entry;

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_run_pat: Entering code -->>" );

    result = 0;				/* all OK so far */

    cfg->c_cur_pat = pat;		/* note which pattern we are using */

    cur_pat = &( cfg->c_pats[ pat ]);
	if ( ior_blocking_can_consume_pat( cur_pat ) &&
		ior_blocking_pop( cfg, cur_pat->p_io_size, &block_entry )) {

		sprintf( msg_buf, "-> Using blocking I/O at %ldk",
			(long) ( block_entry.b_pos / 1024L ));
		ior_verbose( cfg, msg_buf );

		result = ior_run_sel_pat_at( cfg, pat, block_entry.b_pos );
					/* use history if appropriate */
					/* ONLY if history is FULL */
	} else if ( cur_pat->p_history
	    && ( cur_pat->p_hist_active >= cur_pat->p_history )
	    && cur_pat->p_hist_use[ ior_rand( cfg ) % 100 ]) {

	hist = ior_rand( cfg ) % cur_pat->p_hist_active;

	if ( cfg->c_verbose ) {
	    sprintf( msg_buf, "-> Using history I/O %ld at %ldk",
		    hist + 1, (long) ( cur_pat->p_hist_records[ hist ]/ 1024L ));
	    ior_verbose( cfg, msg_buf );
	}
	if ( ior_blocking_is_producer_pat( cur_pat )) {
		ior_blocking_push( cfg, cur_pat->p_hist_records[ hist ],
			cur_pat->p_io_size, NULL );
	}

	result = ior_io( cfg, cur_pat->p_read_use[ ior_rand( cfg ) % 100 ],
		cur_pat->p_io_size, cur_pat->p_hist_records[ hist ], NULL );
	if (( result != 0 ) && ior_blocking_is_producer_pat( cur_pat )) {
		ior_blocking_remove_exact( cfg, cur_pat->p_hist_records[ hist ],
			cur_pat->p_io_size, NULL );
	}

    } else if ( cur_pat->p_local_size > 0 ) { /* do locality stuff */

					/* choose which local to use */
	local = ior_rand( cfg ) % cur_pat->p_local_count;
	cur_pat->p_cur_local = local;

	sprintf( msg_buf, "Using I/O locality %ld (%ldk -> %ldk) [%d.%d]",
		local + 1, 
		(long) ( cur_pat->p_local_starts[ local ] / 1024L ),
		(long) ( cur_pat->p_local_ends[ local ] / 1024L ),
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	ior_verbose( cfg, msg_buf );

	saved_pat.p_pos = cur_pat->p_pos; /* save current pattern info */
	saved_pat.p_cur_seq = cur_pat->p_cur_seq;
	saved_pat.p_start = cur_pat->p_start;
	saved_pat.p_end = cur_pat->p_end;
	cur_pat->p_pos = cur_pat->p_local_pos[ local ];
	cur_pat->p_cur_seq = cur_pat->p_local_seqs[ local ];
	cur_pat->p_start = cur_pat->p_local_starts[ local ];
	cur_pat->p_end = cur_pat->p_local_ends[ local ];
	cur_pat->p_size = cur_pat->p_end - cur_pat->p_start;

	result = ior_run_sel_pat( cfg, pat );

	cur_pat->p_local_uses[ local ]++;

	if (( cur_pat->p_local_limit > 0 )
		&& ( cur_pat->p_local_uses[ local ]
			>= cur_pat->p_local_limit )) {

	    cur_pat->p_local_uses[ local ] = 0;
	    cur_pat->p_local_seqs[ local ] = 0;



	    h_tmp = ior_rand( cfg ) % cur_pat->p_local_avail;
	    h_tmp *= 2 * cur_pat->p_local_size;
	    cur_pat->p_local_starts[ local ] = saved_pat.p_start + h_tmp;
	    cur_pat->p_local_ends[ local ] =
		    cur_pat->p_local_starts[ local ]
		    + cur_pat->p_local_size;

	    cur_pat->p_start = cur_pat->p_local_starts[ local ];
	    cur_pat->p_end = cur_pat->p_local_ends[ local ];
	    cur_pat->p_size = cur_pat->p_end - cur_pat->p_start;
				    /* and a random starting location */
	    ior_set_rand_pos( cfg, pat );
	    cur_pat->p_local_pos[ local ] = cur_pat->p_pos;

	    sprintf( msg_buf,
		    " -->> Pattern %ld locality %ld NOW from %ldk to %ldk pos %ldk [%d.%d]",
		    pat + 1, local + 1,
		    (long)( cur_pat->p_local_starts[ local ] / 1024L ),
		    (long)( cur_pat->p_local_ends[ local ] / 1024L ),
		    (long)( cur_pat->p_local_pos[ local ] / 1024L ),
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	    ior_debug( cfg, msg_buf );
	} else {
	    cur_pat->p_local_pos[ local ] = cur_pat->p_pos;
	    cur_pat->p_local_seqs[ local ] = cur_pat->p_cur_seq;
	};

					/* restore saved pattern info */
	cur_pat->p_pos = saved_pat.p_pos;
	cur_pat->p_cur_seq = saved_pat.p_cur_seq;
	cur_pat->p_start = saved_pat.p_start;
	cur_pat->p_end = saved_pat.p_end;
	cur_pat->p_size = cur_pat->p_end - cur_pat->p_start;

    } else {
	result = ior_run_sel_pat( cfg, pat );
    };

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_run_pat: <<-- Leaving code" );

    return( result );
}

/*
 * ior_run_sel_pat - run the selected pattern on the given device
 */
int	ior_run_sel_pat( ior_config *cfg, long pat )
/* ior_config	*cfg;			our configuration */
/* long		pat;			pattern to use */
{
    return( ior_run_sel_pat_at( cfg, pat, cfg->c_pats[ pat ].p_pos ));
}

/*
 * ior_test_prep_skew - prepare for a skew test run
 */
int	ior_test_prep_skew( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		cur;			/* current item in loop */
    ior_test	*cur_test;		/* test we are running */
    ior_pattern	*cur_pat;		/* current active pattern */
    char	msg[ 200 ];		/* message buffer */

    ior_debug_l( cfg, IOR_DEBUG_MINOR, "ior_test_prep_skew: Entering code -->>" );

    result = 0;				/* all OK so far */
	ior_blocking_reset( cfg );

    cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);

					/* start each pattern */
    for ( cur = 0; cur < cfg->c_npat; cur++ ) {

	cur_pat = &( cfg->c_pats[ cur ]);

					/* only check on active patterns */
	if (( !cur_pat->p_valid ) || ( cur_test->t_pat_pct[ cur ] < 1 )) {
	    continue;
	};

					/* limit sequential */
	if ( cur_pat->p_max_seq > IOR_SKEW_MAX_SEQ ) {
	    sprintf( msg, "limiting sequential operations from %ld to %d due to skew testing",
		    (long) cur_pat->p_max_seq, IOR_SKEW_MAX_SEQ );
	    ior_verbose( cfg, msg );

	    cur_pat->p_max_seq = IOR_SKEW_MAX_SEQ;
	};

	cur_pat->p_hist_active = 0;	/* no active history records */
	cur_pat->p_hist_next = 0;	/* start with item 0 */

					/* with no sequential history */
	cur_pat->p_cur_seq = 0;

	/* NOTE: position chosen at I/O time with skew.... */
    };

    ior_debug_l( cfg, IOR_DEBUG_MINOR, "ior_test_prep_skew: <<-- Leaving code" );

    return( result );
}

/*
 * ior_run_skew - run an I/O with the skew profile
 */
int	ior_run_skew( ior_config *cfg, long pat )
/* ior_config	*cfg;			our configuration */
/* long		pat;			pattern to use */
{
    int		result;			/* final return code */
    int		group;			/* group for I/O */
    int		do_seq_next;		/* do next sequential I/O */
    ior_skew_list *cur_skew;		/* current target skew group */
    ior_skew_pat *cur_pat;		/* current target group pattern */
    ior_skew_area *cur_area;		/* current target group area */
    int		align;			/* alignment size */
    long	cur_copy;		/* which copy of area to use */
    long	hist;			/* which history record to use */
    HUGE	area_end;		/* end address of target area */
    HUGE	block;			/* new position block offset */
    HUGE	n_pos;			/* new position */
	ior_blocking_entry block_entry;

    result = 0;				/* all OK so far */

	/* choose a skew group to process against */
    group = ior_odds_pick( cfg, &( cfg->c_odds ));
    cur_skew = &( cfg->c_skewed[ group ]);
    cur_pat = &( cur_skew->s_pats[ pat ]);
    cfg->c_cur_pat = pat;
    cur_area = cur_skew->s_areas;	/* assume this target area */

    while ( cur_area->a_copies < 1 ) {	/* for empty areas, pick again */

	sprintf( msg_buf, "ior_run_skew: (starting) - skipping empty area %ld",
		cur_area->a_id );
	ior_debug_l( cfg, IOR_DEBUG_ALL, msg_buf );

	ior_area( cfg, IOR_AREA_TAIL, cur_area, cur_skew );

	cur_area = cur_skew->s_areas;	/* pick the new head */
    };

    sprintf( msg_buf, "ior_run_skew: Entering code -->>  pattern %d, skew group %d, area %d",
	    (int)( pat + 1 ), group, (int)( cur_area->a_id ));
    ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

	if ( ior_blocking_can_consume_skew( cur_pat ) &&
		ior_blocking_pop( cfg, cur_pat->p_io_size, &block_entry )) {

		if (( block_entry.b_area != NULL ) &&
			( block_entry.b_area->a_list != NULL )) {
			cur_area = block_entry.b_area;
			cur_skew = cur_area->a_list;
			cur_pat = &( cur_skew->s_pats[ pat ] );
		}

		sprintf( msg_buf, "-> Using blocking I/O at %ldk in area %ld",
			(long) ( block_entry.b_pos / 1024L ),
			cur_area != NULL ? cur_area->a_id : -1L );
		ior_verbose( cfg, msg_buf );

		result = ior_run_skew_at( cfg, pat, cur_skew, cur_pat,
			cur_area, block_entry.b_pos );

	} else if ( cur_pat->p_history
					/* use history if appropriate */
					/* ONLY if history is FULL */
	    && ( cur_pat->p_hist_active >= cur_pat->p_history )
	    && cur_pat->p_hist_use[ ior_rand( cfg ) % 100 ]) {

	hist = ior_rand( cfg ) % cur_pat->p_hist_active;

	cur_area = cur_pat->p_hist_areas[ hist ];
		/* NOT setting pattern position to save next sequential */

	sprintf( msg_buf, "-> Using history I/O %ld at %ldk in area %ld",
		hist + 1, (long) ( cur_pat->p_hist_records[ hist ]/ 1024L ),
		cur_area->a_id );
	ior_verbose( cfg, msg_buf );
	if ( ior_blocking_is_producer_skew( cur_pat )) {
		ior_blocking_push( cfg, cur_pat->p_hist_records[ hist ],
			cur_pat->p_io_size, cur_area );
	}

	result = ior_io( cfg, cur_pat->p_read_use[ ior_rand( cfg ) % 100 ],
		cur_pat->p_io_size, cur_pat->p_hist_records[ hist ],
		cur_skew );
	if (( result != 0 ) && ior_blocking_is_producer_skew( cur_pat )) {
		ior_blocking_remove_exact( cfg, cur_pat->p_hist_records[ hist ],
			cur_pat->p_io_size, cur_area );
	}

    } else {		/* not history - a new, unique I/O */

	do_seq_next = FALSE;			/* assume not sequential */

	if (( cur_pat->p_is_seq ) &&
		cur_pat->p_seq_area != NULL ) {	/* if a chance of sequential */

					/* HOPEFULL for sequential */
	    cur_copy = cur_pat->p_seq_copy;	/* remember the copy */
	    cur_area = cur_pat->p_seq_area;	/* remember the area */

	    area_end = cur_area->a_end +
		    cur_copy * cfg->c_skew_set_size;

				/* if seq. too long, do random */
	    if (( cur_pat->p_max_seq > 0 ) &&
		    ( ++( cur_pat->p_cur_seq ) >= cur_pat->p_max_seq )) {

		/* nope, not sequential */

	    } else if ( cur_pat->p_pos + cur_pat->p_io_size >= area_end ) {
		sprintf( msg_buf, "ior_run_skew: seq I/O pattern %ld went over end of area %ld (%ldk), sequence interrupted",
			pat + 1, cur_area->a_id,
			(long) ( area_end / 1024L ));
		ior_verbose( cfg, msg_buf );

		/* and not sequential */

	    } else {
		do_seq_next = TRUE;		/* finally a good one! */
	    };
	};

	if ( do_seq_next ) {

	    /* the position stays where it was from the last I/O */

	} else {		/* random new location */

	    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_run_skew: -- start new random" );

	    cur_area = cur_skew->s_areas;	/* pick target area */

	    cur_copy = (long) ior_rand_scaled( cfg, cur_area->a_copies );
	    n_pos = ior_rand_scaled( cfg, cur_area->a_size ) +
		    cur_area->a_start +
		    cur_copy * cfg->c_skew_set_size;

					/* now fix the alignment */
					/* -- first is by I/O size */
	    align = cur_pat->p_io_size / (HUGE) IOR_BLOCK_SIZE;
					/* -- or larger if align needed */
	    if ( align < cfg->c_align ) {
		align = cfg->c_align;
	    };

	    block = n_pos / (HUGE)( IOR_BLOCK_SIZE );
	    block = ( block / align ) * align; /* aligned! */
	    if ( block < 1 ) {		/* we want to align by starting at 1 */
		block = align;
	    };
	    cur_pat->p_pos = block * (HUGE) IOR_BLOCK_SIZE;

			/* save these, even if the pattern is not sequential */
	    cur_pat->p_cur_seq = 0;
	    cur_pat->p_seq_area = cur_area;

	    sprintf( msg_buf, "ior_run_skew: I/O pattern %ld new random location chosen (%ldk) [%d.%d], copy %ld of area %ld (start %.2fm)",
		    pat + 1, (long) ( cur_pat->p_pos / 1024L ),
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		    cur_copy, cur_area->a_id,
		    (float)(( cur_area->a_start + cur_copy * cfg->c_skew_set_size ) / ( 1024.0 * 1024.0 )));
	    ior_verbose( cfg, msg_buf );
	    if ( !( cfg->c_verbose )) {
		ior_debug_l( cfg, IOR_DEBUG_MINOR, msg_buf );
	    };
	};

	result = ior_run_skew_at( cfg, pat, cur_skew, cur_pat,
		cur_area, cur_pat->p_pos );
    };

				/* avoid selecting this area next */
    ior_area( cfg, IOR_AREA_TAIL, cur_area, cur_skew );

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_run_skew: <<-- Leaving code" );

    return( result );
}


/*
 * Count successful transfers using bytes so sub-KiB I/O sizes are retained.
 * The pattern ID belongs to the issued request, including on async completion.
 */
void ior_record_io( ior_config *cfg, long io, HUGE bytes, double resp,
		    ior_skew_list *skew, int pat )
{
    int seq = skew != NULL && skew->s_pats[ pat ].p_is_seq;

    if ( io == IOR_READ ) {
	cfg->c_reads++;
	cfg->c_bytes_read += bytes;
	if ( skew != NULL ) {
	    if ( seq ) {
		skew->s_perf.sp_seq_reads++;
		skew->s_perf.sp_seq_read_resp += resp;
	    } else {
		skew->s_perf.sp_rand_reads++;
		skew->s_perf.sp_rand_read_resp += resp;
	    }
	}
    } else {
	if ( io == IOR_WRITE ) {
	    cfg->c_writes++;
	    cfg->c_bytes_written += bytes;
	} else {
	    cfg->c_unmaps++;
	    cfg->c_bytes_unmapped += bytes;
	}
	if ( skew != NULL ) {
	    if ( seq ) {
		skew->s_perf.sp_seq_writes++;
		skew->s_perf.sp_seq_write_resp += resp;
	    } else {
		skew->s_perf.sp_rand_writes++;
		skew->s_perf.sp_rand_write_resp += resp;
	    }
	}
    }
}

/*
 * ior_io - perform an I/O against the target device
 */
int	ior_io( ior_config *cfg, long io, long io_size, HUGE pos, ior_skew_list *skew )
/* ior_config	*cfg;			our configuration */
/* long		io;			type of I/O to do */
/* long		io_size;		size of this I/O */
/* HUGE		pos;			position for I/O */
/* double	*io_resp;		RETURN response time */
{
    int		result;			/* final return code */
    ior_device	*cur_dev;		/* our current device */
    double	cur_resp;		/* response time on the I/O */
    HUGE	bytes = io_size;		/* successful bytes transferred */
    int		invalid_pos;

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    invalid_pos = ( pos < 0 ) || ( pos + io_size > cur_dev->d_capacity );

    if ( cfg->c_debug && ( cfg->c_debug_level >= IOR_DEBUG_SMALL || invalid_pos )) {
	const char *io_name = ( io == IOR_READ ) ? "Read from" :
	    ( io == IOR_WRITE ) ? "Write to" :
	    ( io == IOR_UNMAP ) ? "Unmap at" : "Unknown I/O at";

	sprintf( msg_buf, "ior_io: Entering code: %s position %ldk size %ldk [%d.%d]",
		io_name,
		(long) ( pos / 1024L ),
		(long) ( io_size / 1024L ),
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

	if ( invalid_pos && cfg->c_debug_level < IOR_DEBUG_ALL ) {
	    ior_debug( cfg, msg_buf );
	};
    };

    if ( invalid_pos ) {
	sprintf( msg_buf,
		"internal: bad position in 'ior_io', file %d.%d, pattern %d",
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		cfg->c_cur_pat + 1 );
	ior_error( cfg, msg_buf );

	if ( pos < 0 ) {
	    sprintf( msg_buf, "starting position (%ldk) too small (0k) [%d.%d]",
		    (long) ( pos / 1024L ),
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	    ior_error( cfg, msg_buf );
	} else {
	    sprintf( msg_buf, "ending position (%ldk) too large (%ldk) [%d.%d]",
		    (long) (( pos + io_size )/ 1024L ),
		    (long) ( cur_dev->d_capacity / 1024L ),
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	    ior_error( cfg, msg_buf );
	};

	ior_debug( cfg, "ior_io: <<-- Leaving code ** DUE TO ERRORS **" );
	return( -1 );
    };

#ifdef __linux__
    if ( cfg->c_aio && ( io == IOR_READ || io == IOR_WRITE )) {
	result = ior_aio_enqueue( cfg, io, io_size, pos, skew );
	if ( result != 0 ) {
	    return( result );
	}
	goto throttle;
    }
#endif
    if ( pos != cfg->c_pos ) {		/* seek if needed */
	if ( ior_seek( cfg, pos ) != 0 ) {
	    ior_debug( cfg, "ior_io: <<-- Leaving code ** DUE TO ERRORS ** SEEK Failed" );
	    return( -2 );
	};
    };

    if ( io == IOR_READ ) {		/* perform a read? */
	result = ior_read( cfg, io_size, &cur_resp );
	if ( result != 0 ) {
	    sprintf( msg_buf, "ior_io: <<-- Leaving code ** READ Failed position %ldk, size %ldk [%d.%d], code %d",
		    (long) ( pos / 1024L ),
		    (long) ( io_size / 1024L ),
		    cfg->c_cur_dev + 1,
		    cfg->c_cur_adev + 1,
		    result );
	    ior_debug( cfg, msg_buf );

	    return( -3 );
	};

	bytes = cfg->c_last_read_bytes > 0 ? cfg->c_last_read_bytes : (HUGE) io_size;
    } else if ( io == IOR_WRITE ) {
	result = ior_write( cfg, io_size, &cur_resp );
	if ( result != 0 ) {
	    sprintf( msg_buf, "ior_io: <<-- Leaving code ** WRITE Failed position %ldk, size %ldk [%d.%d], code %d",
		    (long) ( pos / 1024L ),
		    (long) ( io_size / 1024L ),
		    cfg->c_cur_dev + 1,
		    cfg->c_cur_adev + 1,
		    result );
	    ior_debug( cfg, msg_buf );

	    return( -4 );
	};

    } else if ( io == IOR_UNMAP ) {
	result = ior_unmap( cfg, io_size, &cur_resp );
	if ( result != 0 ) {
	    sprintf( msg_buf, "ior_io: <<-- Leaving code ** UNMAP Failed position %ldk, size %ldk [%d.%d], code %d",
		    (long) ( pos / 1024L ),
		    (long) ( io_size / 1024L ),
		    cfg->c_cur_dev + 1,
		    cfg->c_cur_adev + 1,
		    result );
	    ior_debug( cfg, msg_buf );

	    return( -5 );
	};

    } else {
	sprintf( msg_buf, "ior_io: invalid I/O type %ld", io );
	ior_error( cfg, msg_buf );
	return( -6 );
    }

    ior_record_io( cfg, io, bytes, cur_resp, skew, cfg->c_cur_pat );

#ifdef __linux__
throttle:
#endif
    if ( cfg->c_target_resp > 0 ) {
	HUGE issued = cfg->c_reads + cfg->c_writes + cfg->c_unmaps;
	long wait_usec = -1;
	double target_time;

#ifdef __linux__
	if ( cfg->c_aio ) {
	    issued += ior_aio_outstanding( cfg );
	}
#endif
	target_time = cfg->c_target_sec * issued;
	if ( cfg->c_realistic_io ) {
	    double elapsed = ior_get_time( cfg ) - cfg->c_start_time;
	    double ahead = target_time - elapsed;

	    /* Accumulate at least 2 ms of delay to avoid frequent sleeps. */
	    if ( ahead > 0.002 ) {
		wait_usec = (long)( ahead * 1000000.0 );
	    }
	} else if ( target_time > cfg->c_io_time ) {
	    wait_usec = cfg->c_target_resp;
	} else if ( target_time >= cfg->c_io_time ) {
	    wait_usec = ior_rand( cfg ) % cfg->c_target_resp;
	}

	if ( wait_usec >= 0 ) {
#ifdef __linux__
	    if ( cfg->c_aio && ( result = ior_aio_drain( cfg )) != 0 ) {
		return( result );
	    }
#endif
	    ior_sleep_usec( cfg, wait_usec );
	}
    };

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_io: <<-- Leaving code" );
    return( result );
}
/*
 * ior_set_rand_pos - set a new, random position for next I/O
 */
int	ior_set_rand_pos( ior_config *cfg, long pat )
/* ior_config	*cfg;			our configuration */
/* long		pat;			pattern being worked on */
{
    HUGE	block;			/* chosen block to perform I/O at */
    HUGE	pat_blocks;		/* blocks in the pattern */
    HUGE	h_tmp;			/* huge temp value */
    int		result;			/* final return code */
    int		align;			/* alignment size */
    ior_pattern	*cur_pat;		/* current active pattern */

    result = 0;				/* all OK so far */

					/* find current pattern */
    cur_pat = &( cfg->c_pats[ pat ]);

    pat_blocks = cur_pat->p_size / (HUGE) IOR_BLOCK_SIZE;
    if ( pat_blocks < 1 ) {
	sprintf( msg_buf, "Pattern size invalid (%ldk) for pattern %ld [%d.%d]",
		(long)( cur_pat->p_size / 1024L ), pat + 1,
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	ior_error( cfg, msg_buf );
	cur_pat->p_pos = cur_pat->p_start;
	return( -1 );
    };
                                        /* limit random range to ensure io_size fits */
    {
        HUGE io_blocks = cur_pat->p_io_size / (HUGE) IOR_BLOCK_SIZE;
        if ( pat_blocks > io_blocks ) {
            pat_blocks -= io_blocks;
        } else {
            pat_blocks = 1;
        }
    }
                                        /* pick a block to start with */
	h_tmp = ior_rand_scaled( cfg, pat_blocks );
    block = cur_pat->p_start / (HUGE) IOR_BLOCK_SIZE + h_tmp;

					/* now fix the alignment */
					/* -- first is by I/O size */
    align = cur_pat->p_io_size / (HUGE) IOR_BLOCK_SIZE;
					/* -- or larger if align needed */
    if ( align < cfg->c_align ) {
	align = cfg->c_align;
    };
    block = ( block / align ) * align; /* aligned! */
    if ( block < 1 ) {			/* we want to align by starting at 1 */
	block = align;
    };

    cur_pat->p_pos = block * (HUGE) IOR_BLOCK_SIZE;

					/* just in case we go outside -- */
    if (( cur_pat->p_pos < cur_pat->p_start ) ||
	    ( cur_pat->p_pos + cur_pat->p_io_size > cur_pat->p_end )) {
	sprintf( msg_buf, "Pattern position invalid (%ldk) for pattern %ld [%d.%d]",
		(long)( cur_pat->p_pos / 1024L ), pat + 1,
		cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
	ior_warn( cfg, msg_buf );
	cur_pat->p_pos = cur_pat->p_start; /* default to start of device */
    };

    return( result );
}


/*
 * ior_run_meta_test - run a metadata test pass on a device (directory)
 *
 *   Metadata uses the directory device or the parent of a file device.
 *   This function scans the directory for files, then performs
 *   metadata operations (stat, open/close, readdir) against them.
 */
int	ior_run_meta_test( ior_config *cfg )
{
    int		result = 0;
    int		done = 0;
    ior_test	*cur_test;
    ior_device	*cur_dev;
    ior_pattern	*cur_pat;
    ior_clock	cur_time;
    ior_clock	elapsed_time;
    int		meta_op;
    double	cur_resp;
    long	file_idx;
    long	dir_idx;
    long	total_usec;
    const char *meta_dir;
    int		pat_idx;
	long	meta_count;

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_meta_test: Entering code -->>" );

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);

    sprintf( msg_buf, "Metadata test starting on device %d.%d '%s'",
	    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur_dev->d_name );
    ior_debug( cfg, msg_buf );

    meta_dir = cur_dev->d_meta_dir ? cur_dev->d_meta_dir : cur_dev->d_name;

    /* Release the inherited scan before replacing it for this worker. */
    for ( file_idx = 0; file_idx < cfg->c_meta_nfiles; file_idx++ )
        free( cfg->c_meta_files[ file_idx ] );
    for ( dir_idx = 0; dir_idx < cfg->c_meta_ndirs; dir_idx++ )
        free( cfg->c_meta_dirs[ dir_idx ] );
    cfg->c_meta_nfiles = 0;
    cfg->c_meta_ndirs = 0;

    /* Each worker scans its own device, not the last device prepared. */
    {
	sprintf( msg_buf, "Scanning folders/files in '%s', this might take some time...",
		meta_dir );
	ior_log( cfg, msg_buf );
	result = ior_meta_scan_dir( cfg, meta_dir );
	if ( result != 0 ) {
	    ior_error( cfg, "Failed to scan metadata directory" );
	    return( -1 );
	}
    }

    sprintf( msg_buf, "Metadata: found %ld files and %ld directories in '%s'",
	    cfg->c_meta_nfiles, cfg->c_meta_ndirs, meta_dir );
    ior_log( cfg, msg_buf );

    if ( cfg->c_meta_nfiles == 0 ) {
	/* Only error out if there are non-filecreate meta patterns in this test */
	int needs_files = 0;
	int _p;
	for ( _p = 0; _p < cfg->c_npat; _p++ ) {
	    if ( cur_test->t_pat_pct[ _p ] > 0 &&
		    cfg->c_pats[ _p ].p_is_meta &&
		    cfg->c_pats[ _p ].p_meta_mode != IOR_META_FILECREATE ) {
		needs_files = 1;
		break;
	    }
	}
	if ( needs_files ) {
	    sprintf( msg_buf, "ERROR: No files found in '%s' for metadata testing. "
		    "Please populate the directory with files before running metadata tests.",
		    meta_dir );
	    ior_error( cfg, msg_buf );
	    return( -2 );
	}
    }

    if ( cfg->c_meta_ndirs == 0 ) {
	/* At minimum, the base dir should be there */
	sprintf( msg_buf, "WARNING: No subdirectories found in '%s'. "
		"readdir operations will only scan the base directory.",
		meta_dir );
	ior_warn( cfg, msg_buf );
    }

    /* initialize stats */
    cfg->c_meta_ops[ IOR_META_STAT ] = 0;
    cfg->c_meta_ops[ IOR_META_OPENCLOSE ] = 0;
    cfg->c_meta_ops[ IOR_META_READDIR ] = 0;
    cfg->c_meta_ops[ IOR_META_FILECREATE ] = 0;
    cfg->c_meta_time_msecs[ IOR_META_STAT ] = 0;
    cfg->c_meta_time_msecs[ IOR_META_OPENCLOSE ] = 0;
    cfg->c_meta_time_msecs[ IOR_META_READDIR ] = 0;
    cfg->c_meta_time_msecs[ IOR_META_FILECREATE ] = 0;

    if ( cur_test->t_ignore < 1 ) {
	cur_test->t_running = 1;
    }

    cur_time = ior_get_time( cfg );

    while ( !done && !result ) {
	/* pick which pattern to use */
	pat_idx = cur_test->t_patterns[ ior_rand( cfg ) % IOR_TEST_PCT_SLOTS ];
	cur_pat = &( cfg->c_pats[ pat_idx ]);
	cfg->c_cur_pat = pat_idx;

	/* check if this is a metadata pattern or a regular I/O pattern */
	if ( cur_pat->p_is_meta ) {
	    /* determine which meta op to perform */
	    if ( cur_pat->p_meta_mode == IOR_META_MIX ) {
		/* equal mix: randomly select among stat(0), openclose(1), readdir(2) */
		meta_op = ior_rand( cfg ) % IOR_META_TYPES;
	    } else {
		meta_op = cur_pat->p_meta_mode;
	    }

	    /* perform the operation */
	    cur_resp = 0.0;
        long read_dir_items = 0; /* track number of files returned by readdir */
	    switch ( meta_op ) {
	    case IOR_META_STAT:
		file_idx = ior_rand( cfg ) % cfg->c_meta_nfiles;
		result = ior_meta_stat( cfg, cfg->c_meta_files[ file_idx ], &cur_resp );
		break;

	    case IOR_META_OPENCLOSE:
		file_idx = ior_rand( cfg ) % cfg->c_meta_nfiles;
		result = ior_meta_openclose( cfg, cfg->c_meta_files[ file_idx ], &cur_resp );
		break;

	    case IOR_META_READDIR:
		dir_idx = ( cfg->c_meta_ndirs > 0 ) ?
			( ior_rand( cfg ) % cfg->c_meta_ndirs ) : 0;
		result = ior_meta_readdir( cfg,
			( cfg->c_meta_ndirs > 0 ) ?
			    cfg->c_meta_dirs[ dir_idx ] : meta_dir, &cur_resp, &read_dir_items );
		break;

	    case IOR_META_FILECREATE:
		result = ior_meta_filecreate( cfg, meta_dir,
			cur_pat->p_io_size > 0 ? cur_pat->p_io_size : 4096, &cur_resp );
		break;
	    }

	    if ( result != 0 ) {
		sprintf( msg_buf, "Metadata op %d failed (transient), continuing",
			meta_op );
		ior_debug( cfg, msg_buf );
		result = 0;
	    }

	    /* accumulate stats if test is running (past ignore period) */
	    if ( cur_test->t_running ) {
		switch ( meta_op ) {
		case IOR_META_OPENCLOSE:
		    meta_count = 2; /* open + close */
		    break;
		case IOR_META_READDIR:
            /* 
             * A single readdir loop over the network batches chunked RPCs (getdents64). 
             * Based on array metrics, we yield about ~154 files per batch response.
             */
		    meta_count = 3 + (read_dir_items / IOR_READDIR_BATCH_SIZE); /* opendir + closedir + readdir batches */
		    break;
		case IOR_META_FILECREATE:
		    meta_count = 1; /* one file create+write+close = 1 op */
		    break;
		case IOR_META_STAT:
		default:
		    meta_count = 3; /* stat (translates to Create, GetInfo, Close) */
		    break;
		}
		cfg->c_meta_ops[ meta_op ] += meta_count;
		cfg->c_meta_time_msecs[ meta_op ] += cur_resp;

		if ( cfg->c_shared_stats ) {
		    total_usec = (long)( cur_resp * 1000.0 );
		    cfg->c_shared_stats[ cfg->c_my_index ].meta_ops[ meta_op ] += meta_count;
		    cfg->c_shared_stats[ cfg->c_my_index ].meta_usec[ meta_op ] += total_usec;
		}
	    }
	} else {
	    /* File devices keep their I/O target; directories use discovered files. */
	    int is_read = ( cur_pat->p_read_use[ ior_rand( cfg ) % 100 ] == IOR_READ );
            const char *io_path = cur_dev->d_name;
            if ( strcmp( meta_dir, cur_dev->d_name ) == 0 ) {
                file_idx = ior_rand( cfg ) % cfg->c_meta_nfiles;
                io_path = cfg->c_meta_files[ file_idx ];
            }
	    cur_resp = 0.0;
	    result = ior_meta_fileio( cfg, io_path,
		    cur_pat->p_io_size, is_read, &cur_resp );

	    if ( result != 0 ) {
		sprintf( msg_buf, "File I/O on '%s' failed (transient), continuing",
			io_path );
		ior_debug( cfg, msg_buf );
		result = 0;
	    }

	    /* accumulate as regular read/write stats */
	    if ( cur_test->t_running ) {
		long io_bytes = cur_pat->p_io_size;
		if ( cfg->c_shared_stats ) {
		    total_usec = (long)( cur_resp * 1000.0 );
		    if ( is_read ) {
			cfg->c_shared_stats[ cfg->c_my_index ].reads++;
			cfg->c_shared_stats[ cfg->c_my_index ].bytes_read += io_bytes;
			cfg->c_shared_stats[ cfg->c_my_index ].read_usec += total_usec;
		    } else {
			cfg->c_shared_stats[ cfg->c_my_index ].writes++;
			cfg->c_shared_stats[ cfg->c_my_index ].bytes_written += io_bytes;
			cfg->c_shared_stats[ cfg->c_my_index ].write_usec += total_usec;
		    }
		}
	    }
	}

	/* IOPS throttling (same approach as ior_io) */
	if ( cfg->c_target_resp > 0 ) {
	    HUGE total_ops = cfg->c_meta_ops[0] + cfg->c_meta_ops[1] + cfg->c_meta_ops[2] + cfg->c_meta_ops[3];
	    double target_time = cfg->c_target_sec * total_ops;

	    if ( target_time > cfg->c_io_time ) {
		ior_sleep_usec( cfg, cfg->c_target_resp );
	    } else if ( target_time >= cfg->c_io_time ) {
		ior_sleep_usec( cfg, ior_rand( cfg ) % cfg->c_target_resp );
	    }
	}

	cur_time = ior_get_time( cfg );
	elapsed_time = cur_time - cfg->c_start_time;
	cfg->c_io_time = elapsed_time;

	if ( !cur_test->t_running ) {
	    if ( elapsed_time >= cur_test->t_ignore ) {
		cur_test->t_running = 1;
		cfg->c_meta_ops[0] = 0;
		cfg->c_meta_ops[1] = 0;
		cfg->c_meta_ops[2] = 0;
		cfg->c_meta_ops[3] = 0;
		cfg->c_meta_time_msecs[0] = 0;
		cfg->c_meta_time_msecs[1] = 0;
		cfg->c_meta_time_msecs[2] = 0;
		cfg->c_meta_time_msecs[3] = 0;
		cfg->c_start_time = cur_time;
	    }
	} else {
	    cfg->c_io_time -= cur_test->t_ignore;
	}

	if ( elapsed_time >= cur_test->t_duration ) {
	    done = 1;
	}
    }

    /* write perf output for metadata test */
    {
	HUGE stat_ops = cfg->c_meta_ops[ IOR_META_STAT ];
	HUGE oc_ops = cfg->c_meta_ops[ IOR_META_OPENCLOSE ];
	HUGE rd_ops = cfg->c_meta_ops[ IOR_META_READDIR ];
	HUGE fc_ops = cfg->c_meta_ops[ IOR_META_FILECREATE ];
	HUGE total_meta = stat_ops + oc_ops + rd_ops + fc_ops;
	double stat_avg = stat_ops > 0 ? cfg->c_meta_time_msecs[IOR_META_STAT] / stat_ops : 0.0;
	double oc_avg = oc_ops > 0 ? cfg->c_meta_time_msecs[IOR_META_OPENCLOSE] / oc_ops : 0.0;
	double rd_avg = rd_ops > 0 ? cfg->c_meta_time_msecs[IOR_META_READDIR] / rd_ops : 0.0;
	double fc_avg = fc_ops > 0 ? cfg->c_meta_time_msecs[IOR_META_FILECREATE] / fc_ops : 0.0;
	double total_avg = total_meta > 0 ?
		(cfg->c_meta_time_msecs[0] + cfg->c_meta_time_msecs[1] +
		 cfg->c_meta_time_msecs[2] + cfg->c_meta_time_msecs[3]) / total_meta : 0.0;

	fprintf( cfg->c_perf_file, "%d\t%s\t%d\t%s\t%ld\t%ld",
		cfg->c_cur_test + 1,
		cfg->c_tests[ cfg->c_cur_test ].t_name,
		cfg->c_cur_dev + 1,
		cur_dev->d_name,
		cur_time - cfg->c_start_time,
		cfg->c_io_time );

	/* metadata columns: stat, oc, rd, fc, total with latencies, OPS */
	fprintf( cfg->c_perf_file, "\t%ld\t%.3lf\t%ld\t%.3lf\t%ld\t%.3lf\t%ld\t%.3lf\t%ld\t%.3lf\t%ld",
		(long) stat_ops, stat_avg,
		(long) oc_ops, oc_avg,
		(long) rd_ops, rd_avg,
		(long) fc_ops, fc_avg,
		(long) total_meta, total_avg,
		cfg->c_io_time > 0 ? (long)( total_meta / cfg->c_io_time ) : 0L );

	fprintf( cfg->c_perf_file, "\t%ld\n",
		(long)( cfg->c_cur_adev + 1 ));
	fflush( cfg->c_perf_file );
    }

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_meta_test: <<-- Leaving code" );

    return( result );
}