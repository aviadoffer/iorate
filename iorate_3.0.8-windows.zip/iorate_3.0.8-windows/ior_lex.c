/**************************************************************************
 *
 *  ior_lex.c - the IORATE lexical analyzer
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_lex.c,v 3.3 2011/06/24 08:44:01 westiv Exp westiv $";

#include "ior_mach.h"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "iorate.h"
#include "ior_pars.h"

#define	LEX_SIZE	4096		/* max line size for analysis */

static ior_config *lex_cfg;		/* config we are in */
static char lex_buffer[ LEX_SIZE + 10 ]; /* line reading buffer */
static char *lex_next = 0;		/* next char to use in buffer */
static char *lex_end = 0;		/* end of buffer */
FILE	*yyin;			/* parse target file */

static char *lex_seps = "#\";,=%@";	/* separator tokens */

#define	LEX_N_VAR_TOKENS	36
#define	LEX_N_REG_TOKENS	8
static char *lex_var_tokens[ LEX_N_VAR_TOKENS ] = {
	"SEC", "MIN", "HOU", "DEV", "PAT",
	"SEQ", "RAN", "CAP", "MAX", "IGN",
	"OFF", "ONL", "TEM", "TMP", "ZON",
	"TES", "BLO", "WRI", "PAU", "IOP",
	"REA", "SIZ", "FRO", "TAR", "LOC",
	"HIS", "REU", "COU", "LIM", "CRE",
	"COP", "SKE", "SEE", "COR", "ARE",
	"SHI"
};
static char *lex_reg_tokens[ LEX_N_REG_TOKENS ] = {
	"KB", "MB", "GB", "TB", "PB",
	"AT", "FOR", "IO"
};

static int lex_var_token_ids[ LEX_N_VAR_TOKENS ] = {
	IOR_L_SECONDS, IOR_L_MINUTES, IOR_L_HOURS, IOR_L_DEVICE, IOR_L_PATTERN,
	IOR_L_SEQUENTIAL, IOR_L_RANDOM, IOR_L_CAPACITY, IOR_L_MAXIMUM, IOR_L_IGNORE,
	IOR_L_OFFSET, IOR_L_ONLY, IOR_L_TEMP, IOR_L_TEMP, IOR_L_ZONE,
	IOR_L_TEST, IOR_L_BLOCK, IOR_L_WRITE, IOR_L_PAUSE, IOR_L_IOPS,
	IOR_L_READ, IOR_L_SIZE, IOR_L_FROM, IOR_L_TARGET, IOR_L_LOCK,
	IOR_L_HISTORY, IOR_L_REUSE, IOR_L_COUNT, IOR_L_LIMIT, IOR_L_CREATE,
	IOR_L_COPY, IOR_L_SKEW, IOR_L_SEED, IOR_L_CORRELATE, IOR_L_AREA,
	IOR_L_SHIFT
};
static int lex_reg_token_ids[ LEX_N_REG_TOKENS ] = {
	IOR_L_KB, IOR_L_MB, IOR_L_GB, IOR_L_TB, IOR_L_PB,
	IOR_L_AT, IOR_L_FOR, IOR_L_IO
};

extern int ior_lex_prep( ior_config *cfg );
extern int ior_lex_is_sep( ior_config *cfg, char c );
extern int ior_lex_done( ior_config *cfg );

/*
 * yylex - main call for next token
 */
int	yylex()
{
    char	*c;
    int		token_index;		/* lookup of active tokens */
    char	msg_buf[ LEX_SIZE ];	/* print buffer */
    int		is_float;		/* floating point number? */

    while ( 1 ) {			/* read until token or EOF */

	if ( lex_next >= lex_end ) {	/* read another line */
	    fgets( lex_buffer, LEX_SIZE, yyin );
	    if ( feof( yyin )) {
		ior_debug( lex_cfg, "yylex: end of file" );
		lex_cfg->c_l_cur_pos = 0; /* not active in parse string */
		return( 0 );
	    };

	    lex_next = lex_buffer;
	    lex_end = lex_buffer + strlen( lex_buffer );
	};

	is_float = 0;

	switch ( *lex_next ) {

	case '#':			/* comment */
	    lex_next = lex_end - 1;	/* eat up rest of line */
	    sprintf( msg_buf, "yylex: comment in line %d",
		    lex_cfg->c_l_line );
	    ior_debug( lex_cfg, msg_buf );
	    break;

	case '.':
	    is_float = 1;		/* saw decimal point */
		/* intentional fall through */
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	    c = lex_cfg->c_l_str;
	    if ( *lex_next == '.' ) {
		*( c++ ) = *( lex_next++ );
	    };
	    while (( lex_next < lex_end ) &&
		    ( isdigit( *lex_next ) ||
			(( *lex_next == '.' ) && !is_float ))) {
		if ( *lex_next == '.' ) {
		    is_float++;
		};
		*( c++ ) = *( lex_next++ );
	    };
	    *c = '\0';			/* end the string */
	    lex_cfg->c_l_value = atof( lex_cfg->c_l_str );
	    sprintf( msg_buf, "yylex: saw number %s (%.4f)",
		    lex_cfg->c_l_str, (float)( lex_cfg->c_l_value ));
	    ior_debug( lex_cfg, msg_buf );
	    lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
	    return( IOR_L_NUMBER );

	case '\"':			/* a text string */
	    lex_next++;
	    c = lex_cfg->c_l_str;
	    while (( lex_next < lex_end ) && ( *lex_next != '\"' )) {
		*( c++ ) = *( lex_next++ );
	    };
	    *c = '\0';			/* end the string */
	    if ( *lex_next != '\"' ) {
		sprintf( msg_buf, "yylex: saw open string '%s'",
			lex_cfg->c_l_str );
		ior_debug( lex_cfg, msg_buf );
		lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
		return( IOR_L_STRING_WITH_NEWLINE );
	    } else {
		lex_next++;		/* eat closing quote */
		sprintf( msg_buf, "yylex: saw string '%s'",
			lex_cfg->c_l_str );
		ior_debug( lex_cfg, msg_buf );
		lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
		return( IOR_L_STRING );
	    };

	case ';':			/* single character tokens */
	case ',':			/* single character tokens */
	case '=':			/* single character tokens */
	case '%':			/* single character tokens */
	case '+':			/* single character tokens */
	case '-':			/* single character tokens */
	case '*':			/* single character tokens */
	case '/':			/* single character tokens */
	case '(':			/* single character tokens */
	case ')':			/* single character tokens */
	case '@':			/* single character tokens */
	    c = lex_next++;
	    sprintf( msg_buf, "yylex: saw char token '%c'", *c );
	    ior_debug( lex_cfg, msg_buf );
	    lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
	    return( *c );

	case '\n':			/* eat white space */
	    lex_cfg->c_l_line++;	/* note new line */
	    ior_debug( lex_cfg, "yylex: saw EOL" );
	    /* intentional fall through */
	case ' ':			/* eat white space */
	case '\t':			/* eat white space */
	case '\r':			/* eat white space */
	case '\v':			/* eat white space */
	    lex_next++;
	    break;

	default:
	    if ( isspace( *lex_next )) { 
		lex_next++;		/* other white space - in case */
	    } else if ( isalnum( *lex_next )) {
		c = lex_cfg->c_l_str;
		while ( isalnum( *lex_next ) ||
			    (( *lex_next == '.' ) && !is_float )) {
		    if ( *lex_next == '.' ) {
			is_float++;
		    };
		    *( c++ ) = toupper( *( lex_next++ ));
		};
		*c = '\0';			/* end the string */

		for ( token_index = 0; token_index < LEX_N_VAR_TOKENS;
			token_index++ ) {
		    if ( strncmp( lex_var_tokens[ token_index ],
				lex_cfg->c_l_str, 3 ) == 0 ) {
			sprintf( msg_buf, "yylex: saw token '%s'",
				lex_cfg->c_l_str );
			ior_debug( lex_cfg, msg_buf );
			lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
			return( lex_var_token_ids[ token_index ]);
		    };
		};
		for ( token_index = 0; token_index < LEX_N_REG_TOKENS;
			token_index++ ) {
		    if ( strcmp( lex_reg_tokens[ token_index ],
				lex_cfg->c_l_str ) == 0 ) {
			sprintf( msg_buf, "yylex: saw token '%s'",
				lex_cfg->c_l_str );
			ior_debug( lex_cfg, msg_buf );
			lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
			return( lex_reg_token_ids[ token_index ]);
		    };
		};

		sprintf( lex_cfg->c_l_error, "unknown token '%s'",
			lex_cfg->c_l_str );
		lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
		return( IOR_L_UNKNOWN );
	    } else {
		c = lex_cfg->c_l_str;
		while (( lex_next < lex_end ) &&
			( !ior_lex_is_sep( lex_cfg, *lex_next ))) {
		    *( c++ ) = *( lex_next++ );
		};
		*c = '\0';			/* end the string */
		sprintf( lex_cfg->c_l_error, "unknown token '%s'",
			lex_cfg->c_l_str );
		lex_cfg->c_l_cur_pos = lex_next - lex_buffer; /* note our position */
		return( IOR_L_UNKNOWN );
	    };
	};
    };
};

/*
 * ior_lex_prep - prepare for lexical analysis
 */
int	ior_lex_prep( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0;				/* all OK so far */

    lex_cfg = cfg;			/* note our config */
    lex_cfg->c_l_cur_txt = lex_buffer;	/* offer access to line being read */

    return( result );
}

/*
 * ior_lex_is_sep - check for a known separator
 */
int	ior_lex_is_sep( ior_config *cfg, char c )
/* ior_config	*cfg;			 our configuration */
/* char		c;			 character to analyze */
{
    int		i;			/* array index */

    if ( isspace( c )) {
	return( TRUE );			/* white space is always separator */
    };

    for ( i = 0; lex_seps[ i ] != '\0'; i++ ) {
	if ( lex_seps[ i ] == c ) {	/* match - a separator */
	    return( TRUE );
	};
    };

    return( FALSE );
}

/*
 * ior_lex_done - finished with lexical analysis
 */
int	ior_lex_done( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    lex_cfg = NULL;			/* forget old config */

    return( result );
}

