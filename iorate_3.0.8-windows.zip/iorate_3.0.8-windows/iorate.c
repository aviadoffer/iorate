/**************************************************************************
 *
 *  iorate.c - the IORATE main program
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/iorate.c,v 3.33 2011/11/03 15:48:38 westiv Exp westiv $";
static const char *version = "3.08";

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "iorate.h"

char msg_buf[ 1024 ];			/* buffer for messages */
char log_buf[ 1024 ];			/* buffer for log writes */
char tmp_buf[ 1024 ];			/* buffer for other temp data */

static ior_config *signal_config;	/* config stuff for signal routines */

extern int	ior_set_write( ior_config *cfg );
extern int	ior_proc_check( ior_config *cfg );
extern int	ior_cleanup( ior_config *cfg );


/*
 * Thread scaling helpers
 */
static void ior_save_base_thread_counts( ior_config *cfg )
{
    int i;

    for ( i = 0; i < IOR_MAX_DEVICES + 2; i++ ) {
	cfg->c_dev_base_counts[ i ] = 0;
    }

    for ( i = 0; i < cfg->c_ndev; i++ ) {
	if ( cfg->c_devs[ i ].d_valid ) {
	    cfg->c_dev_base_counts[ i ] = cfg->c_devs[ i ].d_count;
	}
    }
}

static int ior_apply_scaled_thread_counts( ior_config *cfg, long scale_run )
{
    int cur;
    int copy;
    int n_valid;
    long new_count;
    ior_device *cur_dev;

    /* Start totals clean, then rebuild the same way ior_read_config did */
    cfg->c_adev = 0;
    cfg->c_vdev = 0;
    n_valid = 0;

    for ( cur = 0; cur < cfg->c_ndev; cur++ ) {
	cur_dev = &( cfg->c_devs[ cur ] );

	if ( !cur_dev->d_valid ) {
	    continue;
	}

	new_count = (long) cfg->c_dev_base_counts[ cur ];

	if ( cfg->c_scale_threads_by > 0 ) {
	    new_count += ( cfg->c_scale_threads_by * scale_run );
	}

	/* Enforce the same constraints as ior_read_config */
	if ( new_count < 1 ) {
	    new_count = 1;
	} else if ( new_count > IOR_MAX_DEV_COPIES ) {
	    new_count = IOR_MAX_DEV_COPIES;
	}

	if ( ( new_count > 1 ) && ( cur_dev->d_is_temp || cur_dev->d_create || cur_dev->d_lock ) ) {
	    new_count = 1;
	}

	cur_dev->d_count = (int) new_count;

	n_valid += cur_dev->d_count;
	cfg->c_adev += cur_dev->d_count;

	for ( copy = 0; copy < IOR_MAX_DEV_COPIES + 1; copy++ ) {
	    cur_dev->d_procs[ copy ] = 0;
	}
	cur_dev->d_is_active = 0;
    }

    cfg->c_vdev = n_valid;

    return( 0 );
}

/*
 * main - it all starts here
 */
int	main( int argc, char** argv )
{
    int		result;			/* final return code */
    static ior_config	cfg;		/* our configuration */
    					/* some extra space for LINUX aligns */
    static BYTE	read_space[ IOR_MAX_IO_SIZE + 5*4096 ];
    static BYTE	write_space[ IOR_MAX_IO_SIZE + 5*4096 ];
#ifdef _LINUX_
    size_t page_size;			/* memory page size - for LINUX */
#endif

    result = 0;				/* all OK so far */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */

    cfg.c_debug_level = IOR_DEBUG_MINOR; /* set the default debug level */

    cfg.c_read_buf = read_space;	/* set up I/O buffers */
    cfg.c_write_buf = write_space;

#ifdef _LINUX_

    /*
     *  For LINUX, we need to be page-aligned for raw I/O to work.
     */

    page_size = getpagesize();		/* get the memory page size */

    cfg.c_read_buf += SWAB_ALIGN_OFFSET;
    cfg.c_read_buf = PTR_ALIGN ( cfg.c_read_buf, page_size);
    cfg.c_write_buf += SWAB_ALIGN_OFFSET;
    cfg.c_write_buf = PTR_ALIGN ( cfg.c_write_buf, page_size);

#endif

    cfg.c_ndev = 0;			/* drop devices, patterns, tests */
    cfg.c_npat = 0;
    cfg.c_ntest = 0;
    cfg.c_adev = 0;
    memset( cfg.c_devs, '\0',
	    ( IOR_MAX_DEVICES + 1 ) * sizeof( ior_device ));
    memset( cfg.c_pats, '\0',
	    ( IOR_MAX_PATTERNS + 1 ) * sizeof( ior_pattern ));
    memset( cfg.c_tests, '\0',
	    ( IOR_MAX_TESTS + 1 ) * sizeof( ior_test ));

    signal_config = &cfg;		/* help signal handler with config */

    cfg.c_is_active = 0;		/* not doing active testing yet */

					/* read in cmd line args */
    if ( ior_read_args( &cfg, argc, argv ) != 0 ) {
	fprintf( stderr, "%s: command line argument parsing failed - ABORTING\n",
		argv[ 0 ]);
	exit( -1 );
    };
					/* note our version */
    sprintf( msg_buf, "Starting IORATE (%s) version %s\n",
	    cfg.c_program, version );
    ior_msg( &cfg, NULL, msg_buf );

    ior_set_write( &cfg );		/* set write pattern */

					/* read the configuration */
    if ( ior_read_config( &cfg ) != 0 ) {
	ior_error( &cfg, "reading of test configuration failed - ABORTING" );
	ior_cleanup( &cfg );
	exit( -2 );
    };
					
					/* save baseline thread counts for optional scaling */
    ior_save_base_thread_counts( &cfg );

/* prepare to run the config */
    if ( ior_prepare( &cfg ) != 0 ) {
	ior_error( &cfg, "preparations for testing failed - ABORTING" );
	ior_cleanup( &cfg );
	exit( -3 );
    };
					/* run the configuration (optionally scaled by thread count) */
    {
	long	total_runs;
	long	run;
	long	runs_left;
	long	delta;

	total_runs = 1;
	if ( cfg.c_scale_threads_count > 0 ) {
	    total_runs += cfg.c_scale_threads_count;
	}

	for ( run = 0; run < total_runs; run++ ) {

	    cfg.c_scale_threads_run = run;

	    if ( run > 0 ) {
		ior_apply_scaled_thread_counts( &cfg, run );
	    }

	    runs_left = total_runs - run - 1;
	    delta = run * cfg.c_scale_threads_by;

	    if ( cfg.c_scale_threads_count > 0 ) {
		sprintf( msg_buf,
			"\nThread scaling run %ld of %ld: +%ld threads vs baseline, %ld runs remaining",
			run + 1, total_runs, delta, runs_left );
		ior_log( &cfg, msg_buf );
	    } else if ( cfg.c_threads_override > 0 ) {
		sprintf( msg_buf,
			"\nThread override active: --threads=%ld (no scaling runs requested)",
			cfg.c_threads_override );
		ior_log( &cfg, msg_buf );
	    }

	    cfg.c_errors = 0;
	    cfg.c_is_active = 0;

	    if ( ior_run_tests( &cfg ) != 0 ) {
		ior_warn( &cfg, "tests did not all complete successfully" );
		result = -4;
	    };
	}
    };
					/* close down the configuration */
    if ( ior_cleanup( &cfg ) != 0 ) {
	ior_warn( &cfg, "errors occurred cleaing up after testing" );
	result = -5;
    };

    return( result );
}

/*
 * ior_read_args - read and validate command line flags
 *
 * -n is no I/O (open devices, but no I/O)
 * -v is verbose (details on what is happening)
 */
int	ior_read_args( ior_config *cfg, int argc, char **argv )
/* ior_config	*cfg;			our configuration */
/* int		argc; */
/* char		**argv; */
{
    int		result;			/* final return code */
    char	*str;			/* current string */
    char	name_buf[ 1024 ];	/* file name buffer */

    result = 0;				/* all OK so far */

#ifdef	IOR_DEBUG
    cfg->c_debug = 1;			/* force debug if defined */
#endif

    ior_debug( cfg, "ior_read_args: Entering code -->>" );

    cfg->c_verbose = 0;			/* assume not verbose */
    cfg->c_debug = 0;			/* assume not debug */
    cfg->c_silent = 0;			/* assume not silent */
    cfg->c_show_limit = 0;		/* assume not showing limits */
    cfg->c_no_testing = 0;		/* assume we will test */
    cfg->c_direct_io = 0;		/* no direct I/O - yet */

    cfg->c_threads_override = 0;		/* no override threads */
    cfg->c_scale_threads_by = 0;		/* no scaling by default */
    cfg->c_scale_threads_count = 0;	/* no scaling by default */
    cfg->c_scale_threads_run = 0;		/* baseline run */

					/* save program name */
    cfg->c_program = ior_strdup( cfg, argv[ 0 ]);

    cfg->c_log_file = (FILE *) 0;	/* no log file yet */
    cfg->c_perf_file = (FILE *) 0;	/* no perf file yet */

    cfg->c_align = 4096 / IOR_BLOCK_SIZE; /* start with 4K alignment */

    cfg->c_sleep = 0;			/* assume no delay */
    cfg->c_ignore = 0;			/* assume no delay for measuring */

					/* check the environment for defaults */
    if (( str = getenv( "IOR_IOPS_FILE" )) == NULL ) {
	cfg->c_iops_name = NULL;
    } else {
	ior_debug( cfg,
		"ior_read_args: Found IOPS file name in environment (IOR_IOPS_FILE)" );
	cfg->c_iops_name = ior_strdup( cfg, str );
    };

    if (( str = getenv( "IOR_DEV_FILE" )) == NULL ) {
	str = "devices.ior";		/* default devices file */
    } else {
	ior_debug( cfg,
		"ior_read_args: Found devices file name in environment (IOR_DEV_FILE)" );
    };
    cfg->c_dev_name = ior_strdup( cfg, str );

    if (( str = getenv( "IOR_PAT_FILE" )) == NULL ) {
	str = "patterns.ior";		/* default patterns file */
    } else {
	ior_debug( cfg,
		"ior_read_args: Found patterns file name in environment (IOR_PAT_FILE)" );
    };
    cfg->c_pat_name = ior_strdup( cfg, str );

    if (( str = getenv( "IOR_TEST_FILE" )) == NULL ) {
	str = "tests.ior";		/* default tests file */
    } else {
	ior_debug( cfg,
		"ior_read_args: Found tests file name in environment (IOR_TEST_FILE)" );
    };
    cfg->c_test_name = ior_strdup( cfg, str );

    if (( str = getenv( "IOR_OUTPUT_BASE" )) == NULL ) {
	str = "iorate";			/* default output base */
    } else {
	ior_debug( cfg,
		"ior_read_args: Found output file base name in environment (IOR_OUTPUT_BASE)" );
    };
    sprintf( name_buf, "%s.log", str );	/* log file */
    cfg->c_log_name = ior_strdup( cfg, name_buf );
    sprintf( name_buf, "%s.perf", str ); /* performance file */
    cfg->c_perf_name = ior_strdup( cfg, name_buf );

    if (( str = getenv( "TEMP" )) == NULL ) {
	if (( str = getenv( "TMP" )) == NULL ) {
	    str = "/tmp";			/* default output base */
	} else {
	    ior_debug( cfg,
		    "ior_read_args: Found performance temp name in environment (TMP)" );
	};
    } else {
	ior_debug( cfg,
		"ior_read_args: Found performance temp name in environment (TEMP)" );
    };
    cfg->c_perf_dir = ior_strdup( cfg, str );

    argv++;				/* read the command line . . . */
    argc--;				/* -- SKIP command name */
    while ( argc > 0 ) {
	if ( *( argv[ 0 ]) != '-' ) {
	    ior_usage( cfg );		/* note usage */
	    argv++;
	    argc--;
	    result = -30;
	    continue;
	};



	/* Handle GNU-style long options: --opt=value or --opt value */
	if ( ( argv[ 0 ][ 0 ] == '-' ) && ( argv[ 0 ][ 1 ] == '-' ) ) {
	    const char	*opt;
	    const char	*eq;
	    const char	*val;
	    size_t	opt_len;
	    long	tmp_l;

	    opt = argv[ 0 ] + 2;
	    eq = strchr( opt, '=' );
	    val = NULL;

	    if ( eq ) {
		opt_len = (size_t)( eq - opt );
		val = eq + 1;
	    } else {
		opt_len = strlen( opt );
		if ( argc < 2 ) {
		    sprintf( msg_buf, "Missing value for option '--%s'", opt );
		    ior_error( cfg, msg_buf );
		    ior_usage( cfg );
		    argv++;
		    argc--;
		    result = -30;
		    continue;
		}
		val = argv[ 1 ];
	    }

	    if ( val == NULL || *val == '\0' ) {
		sprintf( msg_buf, "Missing value for option '--%.*s'", (int)opt_len, opt );
		ior_error( cfg, msg_buf );
		ior_usage( cfg );
		argv++;
		argc--;
		result = -30;
		continue;
	    }

	    if ( opt_len == strlen( "threads" ) && strncmp( opt, "threads", opt_len ) == 0 ) {
		tmp_l = atol( val );
		if ( tmp_l < 1 ) {
		    sprintf( msg_buf, "Invalid --threads value '%s' (must be >= 1)", val );
		    ior_error( cfg, msg_buf );
		    result = -30;
		} else {
		    if ( tmp_l > IOR_MAX_DEV_COPIES ) {
			sprintf( msg_buf, "Requested --threads=%ld exceeds max %u, capped to %u",
				tmp_l, IOR_MAX_DEV_COPIES, IOR_MAX_DEV_COPIES );
			ior_warn( cfg, msg_buf );
			tmp_l = IOR_MAX_DEV_COPIES;
		    }
		    cfg->c_threads_override = tmp_l;
		}
	    } else if ( opt_len == strlen( "scale_threads_by" ) &&
		    strncmp( opt, "scale_threads_by", opt_len ) == 0 ) {
		tmp_l = atol( val );
		if ( tmp_l < 1 ) {
		    sprintf( msg_buf, "Invalid --scale_threads_by value '%s' (must be >= 1)", val );
		    ior_error( cfg, msg_buf );
		    result = -30;
		} else {
		    cfg->c_scale_threads_by = tmp_l;
		}
	    } else if ( opt_len == strlen( "scale_threads_count" ) &&
		    strncmp( opt, "scale_threads_count", opt_len ) == 0 ) {
		tmp_l = atol( val );
		if ( tmp_l < 1 ) {
		    sprintf( msg_buf, "Invalid --scale_threads_count value '%s' (must be >= 1)", val );
		    ior_error( cfg, msg_buf );
		    result = -30;
		} else {
		    cfg->c_scale_threads_count = tmp_l;
		}
	    } else {
		sprintf( msg_buf, "Unknown option '--%.*s'", (int)opt_len, opt );
		ior_error( cfg, msg_buf );
		ior_usage( cfg );
		result = -30;
	    }

	    argv++;			/* consume this arg */
	    argc--;

	    if ( eq == NULL ) {		/* also consume the value token */
		argv++;
		argc--;
	    }

	    continue;
	};

	switch ( *( ++argv[ 0 ])) {
	case 'a':			/* set accept short reads */
	    cfg->c_tollerate_short_reads = 1;
	    ior_debug( cfg, "ior_read_args: SHORT READS OK flag turned ON" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		argv[ 0 ][ 0 ] = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 'c':			/* change (increase) shift */
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		str = &( argv[ 0 ][ 1 ]);
	    } else {			/* next arg */
		argv++;
		argc--;
		str = argv[ 0 ];
	    };
	    cfg->c_shift = atoi( str );
	    if (( cfg->c_shift < 0 ) ||
		    ( cfg->c_shift > 100 )) {
		sprintf( msg_buf,
			"Invalid change shift percentage \"%s\" (%d%%) - must be 0%% to 100%%",
			str, cfg->c_shift );
		ior_error( cfg, msg_buf );
	    } else {
		sprintf( msg_buf,
			"ior_read_args: change (increase) skew shift by %d%%",
			cfg->c_shift );
		ior_verbose( cfg, msg_buf );
	    };
	    argv++;
	    argc--;
	    break;

	case 'd':			/* set debug */
	    cfg->c_debug = 1;

	    sprintf( msg_buf,
		    "ior_read_args: DEBUG flag turned ON (default level %d)",
		    cfg->c_debug_level );

	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		argv[ 0 ][ 0 ] = '-';	/* flag arg */

		if ( isdigit((int)( argv[ 0 ][ 1 ]))) { /* debug level */
		    str = &( argv[ 0 ][ 1 ]);
		} else {
		    ior_debug( cfg, msg_buf );

		    break;		/* BREAK to next .... */
		};
	    } else {			/* next arg */
		argv++;
		argc--;

		if (( argc > 0 ) &&
			( isdigit((int)( argv[ 0 ][ 0 ])))) { /* debug level */
		    str = &( argv[ 0 ][ 0 ]);
		} else {
		    ior_debug( cfg, msg_buf );

		    break;		/* BREAK to next .... */
		};
	    };

	    /* IF there is no level specified, then break already happened... */
	    cfg->c_debug_level = atoi( str );

	    argv++;			/* this eats the rest of this arg */
	    argc--;

	    sprintf( msg_buf,
		    "ior_read_args: DEBUG flag turned ON (level %d)",
		    cfg->c_debug_level );
	    ior_debug( cfg, msg_buf );

	    break;

	case 'n':			/* set no testing */
	    cfg->c_no_testing = 1;
	    ior_log( cfg, "Testing DISABLED (-n flag used)" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		*( argv[ 0 ]) = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 's':			/* set silent */
	    cfg->c_silent = 1;
	    ior_debug( cfg, "ior_read_args: SILENT flag turned ON" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		*( argv[ 0 ]) = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 'u':			/* set direct I/O */
	    cfg->c_direct_io = 1;
	    ior_debug( cfg, "ior_read_args: DIRECT I/O flag turned ON" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		*( argv[ 0 ]) = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 'v':			/* set verbose */
	    cfg->c_verbose = 1;
	    ior_debug( cfg, "ior_read_args: VERBOSE flag turned ON" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		*( argv[ 0 ]) = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 'l':			/* set show limits */
	    cfg->c_show_limit = 1;
	    ior_debug( cfg, "ior_read_args: Show LIMIT flag turned ON" );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* more args */
		*( argv[ 0 ]) = '-';	/* flag arg */
	    } else {			/* next arg */
		argv++;
		argc--;
	    };
	    break;

	case 'i':			/* set iops file */
	    if( cfg->c_iops_name ) {
		sprintf( msg_buf,
			"ior_read_args: IOPS file name changed - was '%s'",
			cfg->c_iops_name );
		ior_debug( cfg, msg_buf );
		free( cfg->c_iops_name );
	    };
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		cfg->c_iops_name = ior_strdup( cfg, &( argv[ 0 ][ 1 ]));
	    } else {			/* next arg */
		argv++;
		argc--;
		cfg->c_iops_name = ior_strdup( cfg, argv[ 0 ]);
	    };
	    sprintf( msg_buf,
		    "ior_read_args: IOPS file name changed - is now '%s'",
		    cfg->c_iops_name );
	    ior_debug( cfg, msg_buf );
	    argv++;
	    argc--;
	    break;

	case 'r':			/* set iops target rate */
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		str = &( argv[ 0 ][ 1 ]);
	    } else {			/* next arg */
		argv++;
		argc--;
		str = argv[ 0 ];
	    };
	    cfg->c_target_rate = atoi( str );
	    if (( cfg->c_target_rate < 0 ) ||
		    ( cfg->c_target_rate > 100 )) {
		sprintf( msg_buf,
			"Invalid target rate percentage \"%s\" (%d%%) - must be 0%% to 100%%",
			str, cfg->c_target_rate );
		ior_error( cfg, msg_buf );
	    } else {
		sprintf( msg_buf,
			"ior_read_args: IOPS target rate set to %d%%",
			cfg->c_target_rate );
		ior_verbose( cfg, msg_buf );
	    };
	    argv++;
	    argc--;
	    break;

	case 'f':			/* set devices file */
	    sprintf( msg_buf,
		    "ior_read_args: DEVICES file name changed - was '%s'",
		    cfg->c_dev_name );
	    ior_debug( cfg, msg_buf );
	    free( cfg->c_dev_name );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		cfg->c_dev_name = ior_strdup( cfg, &( argv[ 0 ][ 1 ]));
	    } else {			/* next arg */
		argv++;
		argc--;
		cfg->c_dev_name = ior_strdup( cfg, argv[ 0 ]);
	    };
	    sprintf( msg_buf,
		    "ior_read_args: DEVICES file name changed - is now '%s'",
		    cfg->c_dev_name );
	    ior_debug( cfg, msg_buf );
	    argv++;
	    argc--;
	    break;

	case 'p':			/* set patterns file */
	    sprintf( msg_buf,
		    "ior_read_args: PATTERNS file name changed - was '%s'",
		    cfg->c_pat_name );
	    ior_debug( cfg, msg_buf );
	    free( cfg->c_pat_name );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		cfg->c_pat_name = ior_strdup( cfg, &( argv[ 0 ][ 1 ]));
	    } else {			/* next arg */
		argv++;
		argc--;
		cfg->c_pat_name = ior_strdup( cfg, argv[ 0 ]);
	    };
	    sprintf( msg_buf,
		    "ior_read_args: PATTERNS file name changed - is now '%s'",
		    cfg->c_pat_name );
	    ior_debug( cfg, msg_buf );
	    argv++;
	    argc--;
	    break;

	case 't':			/* set tests file */
	    sprintf( msg_buf,
		    "ior_read_args: TESTS file name changed - was '%s'",
		    cfg->c_test_name );
	    ior_debug( cfg, msg_buf );
	    free( cfg->c_test_name );
	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		cfg->c_test_name = ior_strdup( cfg, &( argv[ 0 ][ 1 ]));
	    } else {			/* next arg */
		argv++;
		argc--;
		cfg->c_test_name = ior_strdup( cfg, argv[ 0 ]);
	    };
	    sprintf( msg_buf,
		    "ior_read_args: TESTS file name changed - is now '%s'",
		    cfg->c_test_name );
	    ior_debug( cfg, msg_buf );
	    argv++;
	    argc--;
	    break;

	case 'o':			/* set output files */
	    sprintf( msg_buf,
		    "ior_read_args: OUTPUT file names changed - were log '%s', perf '%s'",
		    cfg->c_log_name, cfg->c_perf_name );
	    ior_debug( cfg, msg_buf );
	    free( cfg->c_log_name );
	    free( cfg->c_perf_name );

	    if ( argv[ 0 ][ 1 ] != '\0' ) { /* string follows flag */
		str = &( argv[ 0 ][ 1 ]);
	    } else {			/* next arg */
		argv++;
		argc--;
		str = argv[ 0 ];
	    };
	    sprintf( name_buf, "%s.log", str );	/* log file */
	    cfg->c_log_name = ior_strdup( cfg, name_buf );
	    sprintf( name_buf, "%s.perf", str ); /* performance file */
	    cfg->c_perf_name = ior_strdup( cfg, name_buf );
	    sprintf( msg_buf,
		    "ior_read_args: OUTPUT file names changed - now log '%s', perf '%s'",
		    cfg->c_log_name, cfg->c_perf_name );
	    ior_debug( cfg, msg_buf );
	    argv++;
	    argc--;
	    break;

	default:
	    ior_usage( cfg );		/* note usage */
	    argv++;
	    argc--;
	    result = -30;
	};
    };
	
					/* validate thread scaling options */
    if ( ( ( cfg->c_scale_threads_by > 0 ) && ( cfg->c_scale_threads_count < 1 ) ) ||
	    ( ( cfg->c_scale_threads_by < 1 ) && ( cfg->c_scale_threads_count > 0 ) ) ) {
	ior_error( cfg, "Both --scale_threads_by and --scale_threads_count must be provided together" );
	ior_usage( cfg );
	result = -30;
    };
				/* start the log file */
    if (( cfg->c_log_file = fopen( cfg->c_log_name, "w" )) == NULL ) {
	perror( cfg->c_log_name );
	ior_error( cfg, "Can't open log file" );
	result = -1;
    };
					/* start the perf file */
    if (( cfg->c_perf_file = fopen( cfg->c_perf_name, "w" )) == NULL ) {
	perror( cfg->c_perf_name );
	ior_error( cfg, "Can't open performance file" );
	
	result = -2;
    };

    if ( cfg->c_log_file != NULL ) {
    if ( cfg->c_threads_override > 0 ) {
	sprintf( msg_buf, "CLI option: --threads=%ld (override device copy count in devices file)", cfg->c_threads_override );
	ior_log( cfg, msg_buf );
    };
    if ( cfg->c_scale_threads_count > 0 ) {
	sprintf( msg_buf, "CLI options: --scale_threads_by=%ld --scale_threads_count=%ld (will run tests %ld total times)",
		cfg->c_scale_threads_by, cfg->c_scale_threads_count, 1 + cfg->c_scale_threads_count );
	ior_log( cfg, msg_buf );
    };
    };
    if ( !cfg->c_debug ) {		/* force level to zero if no live */
	cfg->c_debug_level = 0;
    };

    if (( result == 0 ) && ( cfg->c_errors )) {
	result -= cfg->c_errors;
    };

    ior_randomize( cfg );		/* randomize our results */

    ior_debug( cfg, "ior_read_args: <<-- Leaving code" );

    return( result );
}

/*
 * ior_read_config - read and validate configuration files
 */
int	ior_read_config( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    int		n_valid;		/* number of valid entries */
    int		cur;			/* current item count */
    ior_device	*cur_dev;		/* working device */
    ior_pattern	*cur_pat;		/* working pattern */
    ior_test	*cur_test;		/* working test */
    HUGE	max_pattern_io_size;	/* maximum pattern I/O size */
    int		pct;			/* percent seen */
    int		pat;			/* pattern we are in */
    int		call_res;		/* result of last function call */
    int		copy;			/* active disk copy */
    int		i;
    char	tmp_buf2[ 64 ];		/* string space */

    result = 0;				/* all OK so far */

    ior_debug( cfg, "ior_read_config: Entering code -->>" );

    sprintf( msg_buf, "Bytes in HUGE is %d", HUGE_BYTES );
    ior_debug( cfg, msg_buf );

    if ( HUGE_BYTES < 6 ) {
	sprintf( msg_buf, "File access limited to 2 GB\n" );
	ior_warn( cfg, msg_buf );
    } else {
	if ( cfg->c_show_limit ) {
	sprintf( msg_buf, "File access available to %.2f TB (%ld GB)\n",
		(double)IOR_MAX_SEEK / (1024.0 * 1024.0 * 1024.0 * 1024.0),
		(long)( IOR_MAX_SEEK / ((HUGE) 1024 * 1024 * 1024 )));
	ior_log( cfg, msg_buf );
	};
    };

#ifdef	sun

    sprintf( msg_buf, "%s\n%s\n\n",
	"Solaris systems with too many devices defined can crash.",
	"See notes in default devices.ior file for more." );
    ior_warn( cfg, msg_buf );

#endif

    if ( cfg->c_show_limit ) {		/* if just showing limits, done */
	ior_cleanup( cfg );
	exit( 0 );			/* use in make - MUST exit 0 */
    };

    if ( cfg->c_shift > 0 ) {		/* note if changing skew */
	sprintf( msg_buf, "All skewed test workloads shifted by +%d%%\n",
		cfg->c_shift );
	ior_warn( cfg, msg_buf );
    };
    if ( cfg->c_target_rate > 0 ) {	/* note if scaling IOPS */
	sprintf( msg_buf, "Target IOPS rates scaled by %d%%\n",
		cfg->c_target_rate );
	ior_warn( cfg, msg_buf );
    };

    fflush( cfg->c_log_file );		/* flush our files */
    fflush( cfg->c_perf_file );
    fflush( stdout );

    call_res = ior_read_devs( cfg );	/* read devices */
    if ( call_res != 0 ) {
	result = call_res;
    };
    for ( cur = 0, n_valid = 0; cur < cfg->c_ndev; cur++ ) {
	cur_dev = &( cfg->c_devs[ cur ]); /* device to work on */

	if ( cur_dev->d_valid ) {
               /* AVIAD */
		cur_dev->d_is_async = 1;        /* assume asynch writes , relevent to newer RH*/
		/* AVIAD */

				/* apply CLI thread override (if any) */
		    if ( cfg->c_threads_override > 0 ) {
			cur_dev->d_count = (int) cfg->c_threads_override;
		    };

				/* ensure the offset meets the minimum */
	    if ( cur_dev->d_offset < IOR_MIN_POS ) {
		sprintf( msg_buf,
			"-->> Insufficient OFFSET is %s <<--",
			ior_size_to_ascii( cfg, (HUGE) cur_dev->d_offset ));
		ior_verbose( cfg, msg_buf );
		sprintf( msg_buf,
			"Starting position in device %d '%s' set to minimum (%s)",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, (HUGE) IOR_MIN_POS ));
		ior_warn( cfg, msg_buf );
		cur_dev->d_offset = IOR_MIN_POS;
	    };

					/* if needed, check device size */
	    if (( cur_dev->d_capacity == 0 ) &&
		    !cfg->c_no_testing &&
		    !cur_dev->d_is_temp ) {
		call_res = ior_get_capacity( cfg, cur );
		if ( call_res != 0 ) {
		    result = call_res;
		};
	    };
					/* check for over size - in case */
	    if (( cur_dev->d_capacity + cur_dev->d_offset > IOR_MAX_SEEK ) ||
		    ( cur_dev->d_capacity < 0 )) {
		sprintf( msg_buf,
			"Device %d '%s' capacity limited to %s",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, (HUGE) IOR_MAX_SEEK ));
		ior_warn( cfg, msg_buf );

		cur_dev->d_capacity = IOR_MAX_SEEK;
	    };

	    if ( cur_dev->d_capacity % IOR_BLOCK_SIZE != 0 ) {
		cur_dev->d_capacity =
			( cur_dev->d_capacity / IOR_BLOCK_SIZE ) *
			IOR_BLOCK_SIZE;

				/* if size is real small, note change */
		if ( cur_dev->d_capacity < 100 * IOR_BLOCK_SIZE ) {
		    sprintf( msg_buf,
			    "Device %d '%s' capacity rounded down to %s",
			    cur + 1, cur_dev->d_name,
			    ior_size_to_ascii( cfg, cur_dev->d_capacity ));
		    ior_warn( cfg, msg_buf );
		};
	    };

	    if (( cur_dev->d_capacity < IOR_BLOCK_SIZE ) &&
		    cur_dev->d_is_temp ) {
		sprintf( msg_buf,
			"Device %d '%s' has no capacity but is type temp",
			cur + 1, cur_dev->d_name );
		ior_error( cfg, msg_buf );
		cur_dev->d_valid = 0;
	    };

	    if ( cur_dev->d_block_size < IOR_BLOCK_SIZE ) {
		cur_dev->d_block_size = IOR_BLOCK_SIZE;
		sprintf( msg_buf,
			"Device %d '%s' block size increased to minimum %s",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, (HUGE) cur_dev->d_block_size ));
		ior_warn( cfg, msg_buf );
	    } else if (( cur_dev->d_block_size % IOR_BLOCK_SIZE ) != 0 ) {
		cur_dev->d_block_size =
			(( cur_dev->d_block_size + IOR_BLOCK_SIZE - 1 ) /
			    IOR_BLOCK_SIZE ) *
			IOR_BLOCK_SIZE;
		sprintf( msg_buf,
			"Device %d '%s' block size rounded up to %s",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, (HUGE) cur_dev->d_block_size ));
		ior_warn( cfg, msg_buf );
	    };

	    if ( cur_dev->d_count < 0 ) {
		cur_dev->d_count = 1;
		sprintf( msg_buf,
			"Device %d '%s' copy count set to minimum of 1",
			cur + 1, cur_dev->d_name );
		ior_warn( cfg, msg_buf );
	    } else if ( cur_dev->d_count > IOR_MAX_DEV_COPIES ) {
		cur_dev->d_count = IOR_MAX_DEV_COPIES;
		sprintf( msg_buf,
			"Device %d '%s' copy count set to maximum of %u",
			cur + 1, cur_dev->d_name, IOR_MAX_DEV_COPIES);
		ior_warn( cfg, msg_buf );
	    };

	    if ( cur_dev->d_count > 1 ) { /* be sure multiples make sense */
		if ( cur_dev->d_is_temp ) {
		    cur_dev->d_count = 1;
		    sprintf( msg_buf,
			    "Device %d '%s' copy count set to 1 due to TEMP file flag",
			    cur + 1, cur_dev->d_name );
		    ior_warn( cfg, msg_buf );
		};
		if ( cur_dev->d_create ) {
		    cur_dev->d_count = 1;
		    sprintf( msg_buf,
			    "Device %d '%s' copy count set to 1 due to CREATE file flag",
			    cur + 1, cur_dev->d_name );
		    ior_warn( cfg, msg_buf );
		};
		if ( cur_dev->d_lock ) {
		    cur_dev->d_count = 1;
		    sprintf( msg_buf,
			    "Device %d '%s' copy count set to 1 due to LOCK file flag",
			    cur + 1, cur_dev->d_name );
		    ior_warn( cfg, msg_buf );
		};
	    };
	};

	if ( cur_dev->d_valid ) {

	    n_valid += cur_dev->d_count; /* more valid devices */

	    cfg->c_adev += cur_dev->d_count; /* count all copies */

	    for ( copy = 0; copy < IOR_MAX_DEV_COPIES + 1; copy++ ) {
		cur_dev->d_procs[ copy ] = 0; /* no active process */
	    };
	    cur_dev->d_fid = -1;	/* file is not open */
	    cur_dev->d_is_created = 0;	/* not built yet */
	    cur_dev->d_is_active = 0;	/* not yet active */
					/* note smallest device we see */
	    if (( cfg->c_min_dev_size < 1 ) ||
		    ( cfg->c_min_dev_size > cur_dev->d_capacity )) {
		cfg->c_min_dev_size = cur_dev->d_capacity;
	    };
					/* note largest device we see */
	    if (( cfg->c_max_dev_size < 1 ) ||
		    ( cfg->c_max_dev_size < cur_dev->d_capacity )) {
		cfg->c_max_dev_size = cur_dev->d_capacity;
	    };

	    sprintf( msg_buf, "Device %d '%s' is valid (%d copies)", cur + 1,
		    cur_dev->d_name, cur_dev->d_count );
	    ior_verbose( cfg, msg_buf );
	};
    };
    if ( n_valid < 1 ) {		/* no devices to test? */
	ior_error( cfg, "No valid devices to test" );
	ior_log( cfg,
		"TRY: Device = \"testfile.tst\" offset 100MB capacity 450MB;" );
	result = -1;
    } else {
	cfg->c_vdev = n_valid;		/* note number of valid devices */

	ior_log_devs( cfg );
    };

    fflush( cfg->c_log_file );		/* flush our files */
    fflush( cfg->c_perf_file );
    fflush( stdout );

    call_res = ior_read_pats( cfg );	/* read patterns */
    if ( call_res != 0 ) {
	result = call_res;
    };
    max_pattern_io_size = 0;		/* no patterns checked yet */
    for ( cur = 0, n_valid = 0; cur < cfg->c_npat; cur++ ) {

	cur_pat = &( cfg->c_pats[ cur ]);

	if ( cur_pat->p_valid ) {
	    if ( cur_pat->p_io_size > IOR_MAX_IO_SIZE ) {
		sprintf( msg_buf, "Pattern %d '%s' I/O size limited to %s(",
			cur + 1, cur_pat->p_name,
			ior_size_to_ascii( cfg, IOR_MAX_IO_SIZE ));
		strcat( msg_buf,
			ior_size_to_ascii( cfg, (HUGE) cur_pat->p_io_size ));
		strcat( msg_buf, ")" );
		ior_error( cfg, msg_buf );
		cur_pat->p_io_size = IOR_MAX_IO_SIZE;
		cur_pat->p_valid = 0;
	    };

	    if ( cur_pat->p_io_size % IOR_BLOCK_SIZE != 0 ) {
		cur_pat->p_io_size =
			(( cur_pat->p_io_size + IOR_BLOCK_SIZE - 1 ) /
			    IOR_BLOCK_SIZE ) *
			IOR_BLOCK_SIZE;
		sprintf( msg_buf, "Pattern %d '%s' I/O size rounded up to %s",
			cur + 1, cur_pat->p_name,
			ior_size_to_ascii( cfg, (HUGE) cur_pat->p_io_size ));
		ior_warn( cfg, msg_buf );
	    };
					/* if NO sizing given, use default */
	    if (( cur_pat->p_start < 0 ) && ( cur_pat->p_start_pct < 0 )
		    && ( cur_pat->p_size < 0 )
		    && ( cur_pat->p_size_pct < 0 )) {
		cur_pat->p_start_pct = 0;
		cur_pat->p_size_pct = 100;
		sprintf( msg_buf,
			"Pattern %d '%s': using default start (0%%) and size (100%%)",
			cur + 1, cur_pat->p_name );
		ior_verbose( cfg, msg_buf );
	    };
	    if ( cur_pat->p_start_pct >= 100 ) {
		cur_pat->p_start_pct = 0;
		sprintf( msg_buf,
			"Pattern %d '%s' start percent over 100%%, dropped to %.3f%%",
			cur + 1, cur_pat->p_name,
			cur_pat->p_start_pct );
		ior_error( cfg, msg_buf );
		cur_pat->p_valid = 0;
	    };
	    if (( cur_pat->p_start_pct < 0 ) && ( cur_pat->p_size_pct >= 0 )) {
		cur_pat->p_start_pct = 0;
		sprintf( msg_buf,
			"Pattern %d '%s': size percent given, starting at %.3f%%",
			cur + 1, cur_pat->p_name, cur_pat->p_start_pct );
		ior_verbose( cfg, msg_buf );
	    };
	    if (( cur_pat->p_start_pct >= 0 ) && ( cur_pat->p_size_pct < 0 )) {
		cur_pat->p_size_pct = 99.999 - cur_pat->p_start_pct;
		sprintf( msg_buf,
			"Pattern %d '%s': start percent given, sizing at %.3f%%",
			cur + 1, cur_pat->p_name,
			cur_pat->p_size_pct );
		ior_warn( cfg, msg_buf );
	    };
	    if ( cur_pat->p_start_pct + cur_pat->p_size_pct > 100 ) {
		cur_pat->p_size_pct = 99.999 - cur_pat->p_start_pct;
		sprintf( msg_buf,
			"Pattern %d '%s' size percent excessive, reduced to %.3f%%",
			cur + 1, cur_pat->p_name,
			cur_pat->p_size_pct );
		ior_error( cfg, msg_buf );
		cur_pat->p_valid = 0;
	    };

	    if ( cur_pat->p_reuse_pct > 100 ) {
		cur_pat->p_reuse_pct = 100;
		sprintf( msg_buf,
			"Pattern %d '%s' reuse percent excessive, reduced to %.3f%%",
			cur + 1, cur_pat->p_name,
			cur_pat->p_reuse_pct );
		ior_warn( cfg, msg_buf );
	    };

		  /* Treat near-100% reuse as 100% (avoid 99% due to rounding) */
	    if ( cur_pat->p_reuse_pct >= 99.999 ) {
			cur_pat->p_reuse_pct = 100;
	    };
	  
	    if ( cur_pat->p_valid ) {
		n_valid++;

		cur_pat->p_cur_seq = 0;	/* no seq. reads done */
		cur_pat->p_pos = -1;	/* force seek on next I/O */

		for ( i = 0; i < 100; i++ ) { /* set when to read */
		    cur_pat->p_read_use[ i ] =
			    ( cur_pat->p_read_pct >= i + 1 )
				? IOR_READ : IOR_WRITE;
		};

		if (( cur_pat->p_local_limit > 0 ) &&
			( cur_pat->p_local_count < 1 )) {
		    cur_pat->p_local_count = 1;
		    sprintf( msg_buf,
			    "Pattern %d '%s' locality limit set, so count set to 1",
			    cur + 1, cur_pat->p_name );
		    ior_warn( cfg, msg_buf );
		};

		if ((( cur_pat->p_local_size > 0 ) ||
			    ( cur_pat->p_local_pct > 0 )) &&
			( cur_pat->p_local_count < 1 )) {
		    cur_pat->p_local_count = 1;
		    sprintf( msg_buf,
			    "Pattern %d '%s' locality size set, so count set to 1",
			    cur + 1, cur_pat->p_name );
		    ior_warn( cfg, msg_buf );
		};

		if ( cur_pat->p_local_count > 0 ) { /* prep localities */

					/* validate size is OK */
		    if ( cur_pat->p_local_pct < .001 ) {

					/* not specified */
			if (( cur_pat->p_local_size < 1 ) &&
				( cur_pat->p_local_pct < .001 )) {
			    cur_pat->p_local_pct = 5;
			    sprintf( msg_buf,
				    "Pattern %d '%s' locality size not set, using %.f%%",
				    cur + 1, cur_pat->p_name,
				    cur_pat->p_local_pct );
			    ior_warn( cfg, msg_buf );
			};

			if (( cur_pat->p_local_size > 1 )
				&& ( cur_pat->p_local_size
				    < cur_pat->p_io_size * 5 )) {
			    cur_pat->p_local_size = 20 * cur_pat->p_io_size;
			    sprintf( msg_buf,
				    "Pattern %d '%s' locality size too small, using %ldk",
				    cur + 1, cur_pat->p_name,
				    (long)( cur_pat->p_local_size / 1024L ));
			    ior_warn( cfg, msg_buf );
			};
		    };

					    /* make space for uses */
		    cur_pat->p_local_uses = (HUGE *) malloc(
				( cur_pat->p_local_count + 2 )
				    * sizeof( HUGE ));
			
		    if ( cur_pat->p_local_uses == NULL ) {
			ior_error( cfg,
				"MALLOC failed for local uses in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -51 );
		    };
					    /* make space for sequentials */
		    cur_pat->p_local_seqs = (HUGE *) malloc(
				( cur_pat->p_local_count + 2 )
				    * sizeof( HUGE ));
		    if ( cur_pat->p_local_seqs == NULL ) {
			ior_error( cfg,
				"MALLOC failed for local seqs in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -52 );
		    };
					    /* make space for positions */
		    cur_pat->p_local_pos = (HUGE *) malloc(
				( cur_pat->p_local_count + 2 )
				    * sizeof( HUGE ));
		    if ( cur_pat->p_local_pos == NULL ) {
			ior_error( cfg,
				"MALLOC failed for local pos in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -53 );
		    };
					    /* make space for starts */
		    cur_pat->p_local_starts = (HUGE *) malloc(
				( cur_pat->p_local_count + 2 )
				    * sizeof( HUGE ));
		    if ( cur_pat->p_local_starts == NULL ) {
			ior_error( cfg,
				"MALLOC failed for local starts in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -54 );
		    };
					    /* make space for ends */
		    cur_pat->p_local_ends = (HUGE *) malloc(
				( cur_pat->p_local_count + 2 )
				    * sizeof( HUGE ));
		    if ( cur_pat->p_local_ends == NULL ) {
			ior_error( cfg,
				"MALLOC failed for local ends in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -55 );
		    };
		};

		if (( cur_pat->p_reuse_pct > 0 ) &&
			( cur_pat->p_history < 1 )) {
		    cur_pat->p_history = 10;
		    sprintf( msg_buf,
			    "Pattern %d '%s' reuse percent set, so history set to 10",
			    cur + 1, cur_pat->p_name );
		    ior_warn( cfg, msg_buf );
		};


		if ( cur_pat->p_history > 0 ) { /* prep for reuse */
          /* Allow 0% reuse even when history is enabled.
             * If a non-zero reuse value is below 1%, round it up to 1%.
             */
            if (( cur_pat->p_reuse_pct > 0 ) && ( cur_pat->p_reuse_pct < 1 )) {
                cur_pat->p_reuse_pct = 1;
                sprintf( msg_buf,
                    "Pattern %d '%s' history set, reuse < 1%% rounded up to 1%%",
                    cur + 1, cur_pat->p_name );
                ior_warn( cfg, msg_buf );
            };
			
			
				    /* make space for history */
		    cur_pat->p_hist_records = (HUGE *) malloc(
				( cur_pat->p_history + 2 ) * sizeof( HUGE ));
		    if ( cur_pat->p_hist_records == NULL ) {
			ior_error( cfg,
				"MALLOC failed for history records in 'ior_config'" );
			ior_cleanup( cfg );
			exit( -56 );
		    };

		};

		for ( i = 0; i < 100; i++ ) { /* set when to use history */
		    cur_pat->p_hist_use[ i ] =
			    ( cur_pat->p_reuse_pct >= i + 1 ) ? TRUE : FALSE;
		};

		sprintf( msg_buf, "Pattern %d '%s' is valid", cur + 1,
			cur_pat->p_name );
		ior_verbose( cfg, msg_buf );

		if ( max_pattern_io_size < cur_pat->p_io_size ) {
		    max_pattern_io_size = cur_pat->p_io_size;
		};
	    };
	};
    };
    if ( n_valid < 1 ) {		/* no patterns to use? */
	ior_error( cfg, "No valid patterns to use" );
	ior_log( cfg,
		"TRY: Pattern 1 = \"2k Random Read\"  io size 2KB  random  read 100% ;" );
	result = -2;
    } else {
	ior_log_pats( cfg );
    };
					/* note max pattern size if verbose */
    sprintf( msg_buf, "ior_read_config: maximum pattern I/O size is %s",
	    ior_size_to_ascii( cfg, max_pattern_io_size ));
    ior_verbose( cfg, msg_buf );

    fflush( cfg->c_log_file );		/* flush our files */
    fflush( cfg->c_perf_file );
    fflush( stdout );

    call_res = ior_read_tests( cfg );	/* read tests */
    if ( call_res != 0 ) {
	result = call_res;
    };
    for ( cur = 0, n_valid = 0; cur < cfg->c_ntest; cur++ ) {

	cur_test = &( cfg->c_tests[ cur ]);

	if ( cur_test->t_valid ) {

	    if ( cur_test->t_start_pct < 0 && cur_test->t_start < 0 ) {
		cur_test->t_start = 0;	/* if none set, use 0 */
	    };
	    if ( cur_test->t_size_pct == 0 ) {
		sprintf( msg_buf,
			"Test %d '%s' size percentage of 0%% is invalid",
			cur + 1, cur_test->t_name );
		ior_error( cfg, msg_buf );
		cur_test->t_valid = 0;
		cur_test->t_size_pct = 98 - cur_test->t_start_pct;
	    };
	    if ( cur_test->t_size_pct > 100 ) {
		sprintf( msg_buf,
			"Test %d '%s' size percentage of %.3f%% is > 100%%",
			cur + 1, cur_test->t_name, cur_test->t_size_pct );
		ior_error( cfg, msg_buf );
		cur_test->t_valid = 0;
		cur_test->t_size_pct = 98;
	    };
	    if (( cur_test->t_start_pct >= 0 ) &&
		    ( cur_test->t_size_pct > 0 )) {
		if ( cur_test->t_start_pct + cur_test->t_size_pct > 100 ) {
		    sprintf( msg_buf,
			    "Test %d '%s' total percentage of %.3f%% is > 100%%",
			    cur + 1, cur_test->t_name,
			    cur_test->t_start_pct + cur_test->t_size_pct );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		    cur_test->t_start_pct = 0;
		    cur_test->t_size_pct = 98;
		};
	    };

	    if (( cur_test->t_start >= 0 )
		    && ( cur_test->t_start % IOR_BLOCK_SIZE != 0 )) {
		cur_test->t_start =
			(( cur_test->t_start + IOR_BLOCK_SIZE - 1 ) /
			    IOR_BLOCK_SIZE ) *
			IOR_BLOCK_SIZE;

				    /* if size is real small, note change */
		if ( cur_test->t_start < 100 * IOR_BLOCK_SIZE ) {
		    sprintf( msg_buf,
			    "Test %d '%s' I/O start rounded up to %s",
			    cur + 1, cur_test->t_name,
			    ior_size_to_ascii( cfg, cur_test->t_start ));
		    ior_warn( cfg, msg_buf );
		};
	    };

	    if (( cur_test->t_size >= 0 )
		    && ( cur_test->t_size < 2 * max_pattern_io_size )) {
		sprintf( msg_buf, "Test %d '%s' area size too small (%s)",
			cur + 1, cur_test->t_name,
			ior_size_to_ascii( cfg, cur_test->t_size ));
		ior_error( cfg, msg_buf );
		cur_test->t_valid = 0;
	    } else if (( cur_test->t_size >= 0 )
		    && ( cur_test->t_size % IOR_BLOCK_SIZE != 0 )) {
		cur_test->t_size =
			( cur_test->t_size / IOR_BLOCK_SIZE ) *
			IOR_BLOCK_SIZE;

				    /* if size is real small, note change */
		if ( cur_test->t_size < 100 * IOR_BLOCK_SIZE ) {
		    sprintf( msg_buf,
			    "Test %d '%s' area size rounded down to %s",
			    cur + 1, cur_test->t_name,
			    ior_size_to_ascii( cfg, cur_test->t_size ));
		    ior_warn( cfg, msg_buf );
		};
	    };
				    /* note if skewed but not enough */
	    if (( cur_test->t_skew > 0 ) &&
		    ( cur_test->t_skew < IOR_SKEW_MIN )) {
		sprintf( msg_buf,
			"Test %d '%s' non-zero skew (%d%%) below minimum (%d%%) - SKEW ignored",
			cur + 1, cur_test->t_name,
			cur_test->t_skew, IOR_SKEW_MIN );
		ior_warn( cfg, msg_buf );
	    };
				    /* if skewed, validate skew parameters */
	    if ( cur_test->t_skew >= IOR_SKEW_MIN ) {
		if ( cur_test->t_skew > 99 ) {	/* invalid skew */
		    sprintf( msg_buf,
			    "Test %d '%s' skew (%d%%): Skew over 99%% invalid",
			    cur + 1, cur_test->t_name,
			    cur_test->t_skew );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		};
				    /* if global shift, add it now */
		if ( cfg->c_shift > 0 ) {
		    sprintf( msg_buf,
			    "Test %d '%s' shift (%d%%) adjusted by change shift parameter of %d%% (total now %d%%)",
			    cur + 1, cur_test->t_name,
			    cur_test->t_shift, cfg->c_shift,
			    cur_test->t_shift + cfg->c_shift );
		    ior_log( cfg, msg_buf );
		    cur_test->t_shift += cfg->c_shift;
		};

		if ( cur_test->t_shift < 0 ) {
		    sprintf( msg_buf,
			    "Test %d '%s' shift (%d%%): Negative shift invalid",
			    cur + 1, cur_test->t_name, cur_test->t_shift );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		};

		if ( cur_test->t_shift > 99 ) {
		    sprintf( msg_buf,
			    "Test %d '%s' shift (%d%%): Shift over 99%% invalid",
			    cur + 1, cur_test->t_name, cur_test->t_shift );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		};

		if (( cur_test->t_correlate < 1 ) ||
			( cur_test->t_correlate > 99 )) {
		    sprintf( msg_buf,
			    "Test %d '%s' correlation (%d%%) invalid: only 1%% to 99%% allowed",
			    cur + 1, cur_test->t_name, cur_test->t_correlate );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		};

		if (( cur_test->t_area < IOR_AREA_MIN ) ||
			( cur_test->t_area > IOR_AREA_MAX )) {
		    strcpy( tmp_buf, ior_size_to_ascii( cfg, IOR_AREA_MIN ));
		    strcpy( tmp_buf2, ior_size_to_ascii( cfg, IOR_AREA_MAX ));
		    sprintf( msg_buf,
			    "Test %d '%s' area (%s) invalid: only %s to %s allowed",
			    cur + 1, cur_test->t_name,
			    ior_size_to_ascii( cfg, cur_test->t_area ),
			    tmp_buf, tmp_buf2 );
		    ior_error( cfg, msg_buf );
		    cur_test->t_valid = 0;
		};
	    };
	};

	if ( cur_test->t_valid ) {
	    pct = 0;
	    for ( pat = 0; ( pat < cfg->c_npat ) && ( pct < 101 ); pat++ ) {
		if ( cfg->c_pats[ pat ].p_valid ) {
		    for ( i = cur_test->t_pat_pct[ pat ];
			    ( i > 0 ) && ( pct < 101 ); i--, pct++ ) {
			cur_test->t_patterns[ pct ] = pat;
		    };
		};
	    };

	    if ( pct < 100 ) {		/* if not all there, cancel test */
		sprintf( msg_buf,
			"Total percentage in test %d '%s' is less than 100%% (%d)",
			cur + 1, cur_test->t_name, pct );
		ior_error( cfg, msg_buf );

		cur_test->t_valid = 0;	/* this one is broken */
	    };

	    if ( pct > 100 ) {		/* if too many, cancel test */
					/* get real total of percents used */
		for ( pat = 0, pct = 0; pat < cfg->c_npat; pat++ ) {
		    if ( cfg->c_pats[ pat ].p_valid ) {
			pct += cur_test->t_pat_pct[ pat ];
		    };
		};

		sprintf( msg_buf,
			"Total percentage in test %d '%s' is MORE than 100%% (%d)",
			cur + 1, cur_test->t_name, pct );
		ior_error( cfg, msg_buf );

		cur_test->t_valid = 0;	/* this one is broken */
	    };
	};

	if ( cur_test->t_valid ) {
	    n_valid++;			/* another valid test */

	    sprintf( msg_buf, "Test %d '%s' is valid",
		    cur + 1, cur_test->t_name );
	    ior_verbose( cfg, msg_buf );

	    sprintf( msg_buf, "Test %d will run from %s to ",
		    cur + 1, ior_size_to_ascii( cfg, cur_test->t_start ));
	    strcat( msg_buf, ior_size_to_ascii( cfg, cur_test->t_end ));
	    strcat( msg_buf, " (size " );
	    strcat( msg_buf, ior_size_to_ascii( cfg, cur_test->t_size ));
	    strcat( msg_buf, ")" );
	    ior_debug( cfg, msg_buf );

				    /* check for targeted paterns OK */
	    for ( pat = 0; pat < cfg->c_npat; pat++ ) {

		cur_pat = &( cfg->c_pats[ pat ]);

		if ( cur_pat->p_valid ) {

		    if (( cur_pat->p_start_pct < 0 )
			    && ( cur_pat->p_start >= 0 )
			    && ( cur_test->t_start_pct < 0 )) {

			if ( cur_pat->p_start < cur_test->t_start ) {
			    sprintf( msg_buf,
				    "Pattern %d '%s' start too small for test %d '%s'",
				    pat + 1, cur_pat->p_name,
				    cur + 1, cur_test->t_name );
			    ior_error( cfg, msg_buf );
			};
		    };
		};
	    };

	};
    };
    if ( n_valid < 1 ) {		/* no tests to run? */
	ior_error( cfg, "No valid tests to run" );
	ior_log( cfg,
		"TRY: Test 1 = \"Trial Test 1\"  for 180 sec ignore 60 sec  100 iops  from 8KB  size 128MB  100% pat 1;" );
	result = -3;
    } else {
		/* IF we are using skew, find the largest area size */
	cfg->c_max_area = 0;		/* no skew areas (yet) */
					/* check each test */
	for ( cur = 0; cur < cfg->c_ntest; cur++ ) {

	    cur_test = &( cfg->c_tests[ cur ]);

	    if ( !cur_test->t_valid ) {
		continue;
	    };
					    /* note area if larger */
	    if ( cur_test->t_skew >= IOR_SKEW_MIN ) {
		if ( cur_test->t_area > cfg->c_max_area ) {
		    cfg->c_max_area = cur_test->t_area;
		};
	    };
	};
	if ( cfg->c_max_area > 0 ) {	/* note largest area */
	    sprintf( msg_buf, "skew testing active, largest area is %s",
		    ior_size_to_ascii( cfg, cfg->c_max_area ));
	    ior_warn( cfg, msg_buf );

	    ior_warn( cfg, "    - zones and sizes in patterns are ignored for tests with skew" );
	};

	for ( cur = 0; cur < cfg->c_ndev; cur++ ) {

	    cur_dev = &( cfg->c_devs[ cur ]); /* device to work on */

	    if ( !cur_dev->d_valid ) {
		continue;
	    };
				/* max skew area is minimun offset */
	    if ( cur_dev->d_offset < cfg->c_max_area ) {
		cur_dev->d_offset = cfg->c_max_area;
		sprintf( msg_buf,
			"NOTE: offset for device %d '%s' adjusted to largest skew area (%s)",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, (HUGE) cur_dev->d_offset ));
		ior_verbose( cfg, msg_buf );
	    };
				/* make sure we have enoug areas to skew */
	    if ( cur_dev->d_capacity < cfg->c_max_area * 1000 ) {
		strcpy( tmp_buf, ior_size_to_ascii( cfg, cfg->c_max_area ));
		strcpy( tmp_buf2, ior_size_to_ascii( cfg, cfg->c_max_area * 1000 ));
		sprintf( msg_buf,
			"Device %d '%s' capacity (%s) too small for skew test - needs 1000 * skew area (%s) = %s",
			cur + 1, cur_dev->d_name,
			ior_size_to_ascii( cfg, cur_dev->d_capacity ),
			tmp_buf, tmp_buf2 );
		ior_error( cfg, msg_buf );
		cur_dev->d_valid = 0;
	    };
	};

	for ( cur = 0; cur < cfg->c_npat; cur++ ) {

	    cur_pat = &( cfg->c_pats[ cur ]);

	    if ( !cur_pat->p_valid ) {
		continue;
	    };
					/* ensure I/Os fit skew area */
	    if (( cfg->c_max_area > 0 ) &&
		    ( cur_pat->p_io_size > ( cfg->c_max_area / 10 ))) {
		cur_pat->p_io_size = ( cfg->c_max_area / 10 + IOR_BLOCK_SIZE - 1 ) / IOR_BLOCK_SIZE;
		cur_pat->p_io_size *= IOR_BLOCK_SIZE;
		sprintf( msg_buf, "Pattern %d '%s' I/O size limited to 10%% of skew area (%s)",
			cur + 1, cur_pat->p_name,
			ior_size_to_ascii( cfg, cur_pat->p_io_size ));
		ior_warn( cfg, msg_buf );
	    };
	};


	fflush( cfg->c_log_file );	/* flush our files */
	fflush( cfg->c_perf_file );
	fflush( stdout );

	call_res = ior_read_iops( cfg ); /* read iops */
	if ( call_res != 0 ) {
	    result = call_res;
	};

	for ( cur = 0; cur < cfg->c_ntest; cur++ ) {

	    cur_test = &( cfg->c_tests[ cur ]);

	    if ( cur_test->t_valid &&
		    cfg->c_target_rate ) {
					/* note 100.0 as float for rouding */
		cur_test->t_iops *= cfg->c_target_rate / 100.0;
	    };
	};

	ior_log_tests( cfg );
    };

    ior_debug( cfg, "ior_read_config: <<-- Leaving code" );

    return( result );
}

/*
 * ior_skew_prep - prepare for using skewed layouts
 */
int	ior_skew_prep( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    int		group;			/* group we are updating */
    int		pat;			/* pattern we are copying */
    int		i;			/* loop index */

    ior_skew_list *cur_skew;		/* skew group being updated */
    ior_pattern *src_pat;		/* full pattern copied from */
    ior_skew_pat *tgt_pat;		/* skew pattern copied to */


    result = 0;				/* all OK so far */

    if ( cfg->c_max_area < 1 ) {	/* no skew? */
	ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_prep: no skew, so bounce" );

	return( result );
    };

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_prep: Entering code -->>" );

    for ( group = 0; group < IOR_SKEW_LISTS; group++ ) {
	cur_skew = &( cfg->c_skewed[ group ]);

	for ( pat = 0; pat < cfg->c_npat; pat++ ) {

	    src_pat = &( cfg->c_pats[ pat ]);
	    tgt_pat = &( cur_skew->s_pats[ pat ]);

	    if ( !src_pat->p_valid ) {
		tgt_pat->p_valid = FALSE;

		continue;
	    };

	    tgt_pat = &( cur_skew->s_pats[ pat ]);

	    tgt_pat->p_name = src_pat->p_name;
	    tgt_pat->p_io_size = src_pat->p_io_size;
	    tgt_pat->p_history = src_pat->p_history;
	    tgt_pat->p_max_seq = src_pat->p_max_seq;
	    tgt_pat->p_read_pct = src_pat->p_read_pct;
	    tgt_pat->p_reuse_pct = src_pat->p_reuse_pct;
	    tgt_pat->p_is_seq = src_pat->p_is_seq;

	    for ( i = 0; i < 100; i++ ) { /* set when to read */
		tgt_pat->p_read_use[ i ] =
			( tgt_pat->p_read_pct >= i + 1 )
			    ? IOR_READ : IOR_WRITE;
	    };

	    if ( tgt_pat->p_history > 0 ) {

		for ( i = 0; i < 100; i++ ) { /* set when to use history */
		    tgt_pat->p_hist_use[ i ] =
			    ( tgt_pat->p_reuse_pct >= i + 1 ) ?
				TRUE : FALSE;
		};

		tgt_pat->p_hist_records = (HUGE *) malloc(
			    ( tgt_pat->p_history + 2 ) * sizeof( HUGE ));
		if ( tgt_pat->p_hist_records == NULL ) {
		    ior_error( cfg,
			    "ior_skew_prep: MALLOC failed for history records" );
		    ior_cleanup( cfg );
		    exit( -101 );
		};

		tgt_pat->p_hist_areas = (ior_skew_area **) malloc(
			    ( tgt_pat->p_history + 2 ) * sizeof( ior_skew_area * ));
		if ( tgt_pat->p_hist_areas == NULL ) {
		    ior_error( cfg,
			    "ior_skew_prep: MALLOC failed for history area pointers" );
		    ior_cleanup( cfg );
		    exit( -102 );
		};

	    } else {
		tgt_pat->p_hist_records = NULL;
		tgt_pat->p_hist_areas = NULL;
	    };

	    tgt_pat->p_hist_active = 0;
	    tgt_pat->p_hist_next = 0;
	    tgt_pat->p_cur_seq = 0;

	    tgt_pat->p_valid = TRUE;
	};
    };

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_prep: <<-- Leaving code" );

    return( result );
}

/*
 * ior_prepare - prepare for running the tests
 */
int	ior_prepare( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    ior_device	*cur_dev;		/* device we are working on */
    ior_test	*cur_test;		/* current test */
    int		call_res;		/* result of a call */
    int		i;			/* file index */
    int		t;			/* test index */

    char	*cur_names[ 5 ] = {	/* name of current skew */
	"1st-", "2nd-", "3rd-"
    };
    static char *skew_names[ IOR_SKEW_LISTS + 1 ] = { /* names for the skew groups */
	"1", "2", "3", "4",
	"5+", "7+", "9+", "11+",
	"14+", "17+", "21+", "26+",
	"31+", "41+", "56+", "76+"
    };

    result = 0;				/* all OK so far */

    ior_debug( cfg, "ior_prepare: Entering code -->>" );

    if ( cfg->c_no_testing ) {		/* no prep if not testing */
	ior_debug( cfg,
		"ior_prepare: Bailing out - no testing flag set" );
	return( result );
    };
					/* try opening each device file */
    for ( i = 0; i < cfg->c_ndev; i++ ) {

	cur_dev = &( cfg->c_devs[ i ]);	/* note our device */

	if ( !cur_dev->d_valid ) { /* skip invalid files */
	    continue;
	};

	cfg->c_cur_dev = i;		/* track current file */

	sprintf( msg_buf, "Beginning preparations of file %d '%s'", i + 1,
		cur_dev->d_name );
	ior_verbose( cfg, msg_buf );
					/* test file open, create temp */
	call_res = ior_open_dev( cfg, i );
	if ( call_res != 0 ) {
	    result = call_res;
	};
		/* check file sizes, verify that tests are sizes OK */
	for ( t = 0; t <= cfg->c_ntest; t++ ) {
	    cur_test = &( cfg->c_tests[ t ]);

	    if ( cur_test->t_valid &&
		    ( cur_dev->d_offset + cur_dev->d_capacity
			< cur_test->t_end )) {
		sprintf( msg_buf,
			"%s %d '%s' is too short for test %d '%s'",
			"Capacity of device", i + 1,
			cur_dev->d_name, t + 1,
			cur_test->t_name );
		ior_error( cfg, msg_buf );
		sprintf( msg_buf, " = = Capacity is %s, end of test is ",
			ior_size_to_ascii( cfg,
				cur_dev->d_offset + cur_dev->d_capacity ));
		strcat( msg_buf,
			ior_size_to_ascii( cfg, cur_test->t_end ));
		strcat( msg_buf, " = =" );
		ior_error( cfg, msg_buf );
		result = -20;
		call_res = -20;
	    } else {
		call_res = 0;
	    };
	};
					/* if OK, check capacity */
	if (( cur_dev->d_fid > 0 ) && ( call_res != 0 )) {
	    call_res = ior_seek( cfg, cur_dev->d_capacity );
	    if ( call_res != 0 ) {
		result = call_res;
	    };
	};

	if ( cur_dev->d_fid > 0 ) {	/* if open . . . */
	    call_res = ior_close_dev( cfg, i ); /* close the file */
	    if ( call_res != 0 ) {
		result = call_res;
	    };
	};
    };

    if ( result == 0 ) {		/* prepare for any skew tests */
	result = ior_skew_prep( cfg );
    };

    if ( result == 0 ) {		/* testing ready to start */
	fprintf( cfg->c_perf_file, "test_number\ttest_name" );
	fprintf( cfg->c_perf_file, "\tdevice_num\tdevice_name" );
	fprintf( cfg->c_perf_file, "\ttotal_sec\tmeasured_sec" );
	fprintf( cfg->c_perf_file, "\treads\tKB_read\tread_resp" );
	fprintf( cfg->c_perf_file, "\twrites\tKB_written\twrite_resp" );
	fprintf( cfg->c_perf_file, "\ttotal_I/Os\ttotal_KB\ttotal_resp" );
	fprintf( cfg->c_perf_file, "\tI/Os_per_sec\tKB_per_sec\tdev_copy" );

					/* header for each skew group */
	if ( cfg->c_max_area > 0 ) {
					/* if DEBUG, all skew levels */
					/* NOTE: BREAKS using AWK to parse the results */
	    if ( cfg->c_debug_level >= IOR_DEBUG_MAJOR ) {
		for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
		    fprintf( cfg->c_perf_file,
			"\t%sRR\t%sRRrt\t%sSR\t%sSRrt\t%sRW\t%sRWrt\t%sSW\t%sSWrt",
			skew_names[ i ], skew_names[ i ],
			skew_names[ i ], skew_names[ i ],
			skew_names[ i ], skew_names[ i ],
			skew_names[ i ], skew_names[ i ] );
		};
					/* otherwise, the highlights */
	    } else {
		for ( i = 0; i < 3; i++ ) {
		    fprintf( cfg->c_perf_file,
			"\t%sRR\t%sRRrt\t%sSR\t%sSRrt\t%sRW\t%sRWrt\t%sSW\t%sSWrt",
			cur_names[ i ], cur_names[ i ],
			cur_names[ i ], cur_names[ i ],
			cur_names[ i ], cur_names[ i ],
			cur_names[ i ], cur_names[ i ]);
		};
	    };
	};

	fprintf( cfg->c_perf_file, "\n" );

#ifdef	IOR_ENGINEERING

	ior_log( cfg, "ior_prepare: ENGIEERING MODE is defined" );

	ior_eng_prep( cfg );

#endif

    };

    ior_debug( cfg, "ior_prepare: <<-- Leaving code" );

    return( result );
}

/*
 * ior_odds_pick - pick an item from the odds list, based on 
 *
 */
int	ior_odds_pick( ior_config  *cfg, ior_odds *odds )
/* ior_config	*cfg;			 our configuration */
{
    HUGE	pick;		/* pick from the possible odds */
    int		chosen;		/* selected item from list */
    int		i;
    int		done;

    ior_debug( cfg, "ior_odds_pick: Entering code -->> " );

    pick = ior_rand( cfg ) % odds->o_odds_count;

    for ( i = 0, done = FALSE;
	    ( i < odds->o_items_count ) && !done; i++ ) {

	sprintf( msg_buf, "Pick %lld, item %d (id %d), odds from %ld to %ld",
		(long long) pick, i, odds->o_odds[ i ].i_id,
		odds->o_odds[ i ].i_odds_start,
		odds->o_odds[ i ].i_odds_end );
	ior_debug_l( cfg, IOR_DEBUG_ALL, msg_buf );

	if ( odds->o_odds[ i ].i_odds_end >= pick ) {
	    done = TRUE;
	    chosen = odds->o_odds[ i ].i_id;
	};
    };

    if ( !done ) {		/* what? */
	ior_warn( cfg, "ior_odds_pick: failed to select an item, using LAST in list" );
	chosen = odds->o_items_count - 1;
    };

    sprintf( msg_buf, "ior_odds_pick: <<-- Leaving code, chose item %d from odds pick %lld",
	    chosen, (long long) pick );
    ior_debug( cfg, msg_buf );

    return( chosen );
}


/*
 * ior_area - add or move an area on a list
 *
 */
int	ior_area( ior_config  *cfg, int to_head,
	    ior_skew_area *area, ior_skew_list *list )
/* ior_config	*cfg;			 our configuration */
{
    sprintf( msg_buf, "ior_area: Entering code -->> area %ld move %s of skew list %d",
	area->a_id, to_head ? "to head" : "to tail", list->s_id );
    ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

    if ( area->a_list ) {		/* pull from old list */

	/* SHOULD NOT NEED TO, BUT...   ****/
	/*   May want to check for only one area in list */

	ior_debug_l( cfg, IOR_DEBUG_ALL,
		"ior_area: removing area from old list" );

	if ( area->a_list->s_areas == area ) {
	    area->a_list->s_areas = area->a_next;
	};

	area->a_prev->a_next = area->a_next;
	area->a_next->a_prev = area->a_prev;

	area->a_list->s_area_current--;
    };

    if ( list->s_areas ) {		/* add to current list */

	ior_debug_l( cfg, IOR_DEBUG_ALL,
		"ior_area: adding area to new list" );

	area->a_next = list->s_areas;
	area->a_prev = area->a_next->a_prev;
	area->a_prev->a_next = area;
	area->a_next->a_prev = area;

	area->a_list = list;

	if ( to_head ) {		/* update head pointer? */
	    list->s_areas = area;
	};
    } else {				/* start a clean list */

	ior_debug_l( cfg, IOR_DEBUG_ALL,
		"ior_area: adding area to EMPTY new list" );

	list->s_areas = area;
	area->a_prev = area;
	area->a_next = area;

	area->a_list = list;
    };

    list->s_area_current++;

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_area: <<-- Leaving code" );

    return( 0 );
}

/*
 * ior_skew_check_next - be sure next group is available
 *
 */
int	ior_skew_check_next( ior_config  *cfg, 
	    int *group_ptr, int *direction_ptr )
/* ior_config	*cfg;			 our configuration */
{
    ior_skew_list *cur_skew;

    sprintf( msg_buf, "ior_skew_check_next: Entering code -->> group %d, direction %d",
	    *group_ptr, *direction_ptr );
    ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

    cur_skew = &( cfg->c_skewed[ *group_ptr ]);

    if ( cur_skew->s_area_current >=	/* only go over target count by 5% */
	    ( cur_skew->s_area_goal * 1.05 )) {
	if ( *direction_ptr ) {
	    if ( *group_ptr >= ( IOR_SKEW_LISTS - 1 )) {
		*direction_ptr = FALSE;
		( *group_ptr )--;

	    } else {
		( *group_ptr )++;
	    };
	} else {		/* going down */
	    if ( *group_ptr <=0 ) {
		*direction_ptr = TRUE;
		( *group_ptr )++;

	    } else {
		( *group_ptr )--;
	    };
	};

	return( ior_skew_check_next( cfg,
		group_ptr, direction_ptr ));
    };

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_check_next: <<-- Leaving code" );

    return( 0 );
}

/*
 * ior_skew_set - set skew for the current test
 *
 *    The skew size divides the target areas into 16 buckets, each
 *    of which get the defined percentage of the areas (1-25%).
 *    The areas that can have the highest I/O ratios have the
 *    smallest number of areas in them.
 *
 *    The odds are pre-calculated based on the skew level set for
 *    the test.  We select the one 
 */
int	ior_skew_set( ior_config  *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    int		i;
    int		next;
    int		n_odds;
    long	odds_total;
    long	shift_count;		/* how many areas to shift */
    long	hot_group_remain;	/* # remaining from hot group */
    long	med_group_remain;	/* # remaining from medium group */
    long	cool_group_remain;	/* # remaining from cool group */
    int		shift_hot_group;	/* hottest group to pull from */
    int		shift_med_group;	/* medium group to pull from */
    int		shift_cool_group;	/* coldest group to pull from */
    ior_skew_list *hot_skew;		/* skew list for hottest areas */
    ior_skew_area *hot_area;		/* target hot area */
    ior_skew_list *med_skew;		/* skew list for medium areas */
    ior_skew_area *med_area;		/* target medium area */
    ior_skew_list *cool_skew;		/* skew list for coldest areas */
    ior_skew_area *cool_area;		/* target cold area */

    ior_test	*cur_test;
    ior_skew_list *cur_skew;
    ior_skew_area *cur_area;
    float	area_targets;
    long 	nareas;
    long	c_area;			/* area we are loading */
    HUGE	location;
    int		group;			/* skew group we are adding to */
    int		direction;		/* 1 is going up, 0 going down */
    int		overall_full;		/* how much have we filled overall */
    int		group_full;		/* how full is this group */
    int		correlate;		/* our updated correlation */

    int		skew_current;		/* current skew capacity being accounted for */
    int		skew_target;		/* target skew group capacity */
    int		skew_group;		/* current skew group being accounted for */

static ior_odds_item select_items[ IOR_SKEW_LISTS + 2 ];
static ior_odds	select_odds;

					/* areas to activate */
    static ior_skew_area the_areas[ IOR_AREA_GROUPING + 2 ];

/* skew_size - the percentage of capacity in each of our skew odds selection buckets */
static long skew_size[ IOR_SKEW_LISTS + 1 ] = {
	1, 1, 1, 1, 2, 2, 2, 3, 3, 4, 5, 5, 10, 15, 20, 25, 0
	/* CAREFUL!  If these are changed at all, check the */
	/*   shift code below - it is designed for these values */
};
/* skew_odds has the odds grouped by skew level, totalling 100000 iops (total odds) per level */
static long skew_odds[ 25 ][ IOR_SKEW_LISTS + 2 ] = {
	{ 0 },
	{ 50, 10588, 10546, 10522, 10504, 20961, 20906, 20856, 31195, 31092, 41301, 51382, 51116, 101448, 150249, 196820, 240515, 0 },
	{ 55, 14612, 14454, 14319, 14194, 28028, 27563, 27113, 39846, 38883, 50393, 60738, 58331, 109829, 148992, 172604, 180101, 0 },
	{ 60, 20506, 20110, 19753, 19412, 37843, 36582, 35371, 50880, 48389, 60858, 70576, 64930, 114702, 139923, 139713, 120452, 0 },
	{ 65, 28269, 27453, 26704, 25988, 49924, 47325, 44871, 62989, 58170, 70703, 78471, 68746, 113002, 122269, 103258, 71859, 0 },
	{ 70, 38867, 37291, 35834, 34452, 64997, 60134, 55646, 75791, 67488, 78634, 82661, 68158, 102568, 95843, 66040, 35595, 0 },
	{ 75, 54104, 51053, 48250, 45623, 83965, 75139, 67255, 87901, 74464, 81903, 79956, 60698, 81130, 62362, 33005, 13192, 0 },
	{ 80, 78330, 71985, 66258, 61017, 107981, 91658, 77823, 95300, 74606, 74941, 65142, 43451, 48521, 28076, 10828, 4082, 0 },
	{ 83, 105311, 93933, 83896, 74964, 126883, 101394, 81053, 92175, 65954, 59794, 45628, 26364, 24433, 11088, 4277, 2853, 0 },
	{ 85, 121441, 106358, 93257, 81802, 134744, 103767, 79943, 86907, 58864, 50156, 35403, 18808, 15810, 6710, 3228, 2802, 0 },
	{ 87, 159548, 133495, 111820, 93703, 144386, 101516, 71433, 69600, 41278, 30382, 18003, 8111, 6225, 3635, 3333, 3534, 0 },
	{ 89, 190632, 153380, 123540, 99549, 144940, 94281, 61420, 54602, 29015, 19055, 10061, 4313, 3869, 3477, 3789, 4078, 0 },
	{ 90, 217905, 169160, 131457, 102206, 141353, 85662, 52043, 42645, 20608, 12392, 6195, 2839, 3267, 3666, 4140, 4462, 0 },
	{ 91, 250445, 186081, 138389, 102975, 133767, 74327, 41469, 30828, 13359, 7396, 3730, 2032, 2941, 3641, 4148, 4471, 0 },
	{ 92, 291044, 204161, 143343, 100704, 120615, 59858, 29930, 19737, 7597, 4060, 2392, 1674, 2799, 3585, 4090, 4409, 0 },
	{ 93, 341517, 222020, 144462, 94072, 101359, 43384, 18855, 10821, 3813, 2268, 1793, 1502, 2643, 3408, 3890, 4193, 0 },
	{ 94, 400299, 236645, 140020, 82935, 78463, 27970, 10294, 5180, 1874, 1446, 1434, 1279, 2273, 2933, 3347, 3608, 0 },
	{ 95, 514694, 241733, 113782, 53768, 37974, 9356, 2965, 2057, 1488, 1737, 1942, 1759, 3129, 4039, 4609, 4969, 0 },
	{ 96, 615959, 227109, 84025, 31344, 16680, 3183, 1258, 1346, 1168, 1400, 1569, 1422, 2529, 3265, 3726, 4016, 0 },
	{ 97, 744064, 178895, 43378, 10844, 4098, 1081, 815, 1076, 961, 1155, 1294, 1173, 2086, 2693, 3073, 3313, 0 },
	{ 98, 894500, 85460, 8462, 1098, 643, 482, 427, 571, 510, 613, 687, 622, 1107, 1429, 1631, 1758, 0 },
	{ 99, 985613, 7774, 281, 195, 332, 284, 252, 337, 301, 362, 405, 367, 653, 843, 962, 1037, 0 },
	{ 0 },
	{ 0 },
	{ 0 },
};
/* skew_info has information on the skew data - for x% of drive capacity, we drive y% of I/O */
static long skew_info[ 25 ][ 12 ] = {
	{ 0 },
	{ 50, 300, 2700, 7000, 320, 2790, 6890, 0 },
	{ 55, 300, 2700, 7000, 430, 3450, 6120, 0 },
	{ 60, 300, 2700, 7000, 600, 4250, 5150, 0 },
	{ 65, 300, 2700, 7000, 820, 5070, 4100, 0 },
	{ 70, 300, 2700, 7000, 1120, 5880, 3000, 0 },
	{ 75, 300, 2700, 7000, 1530, 6570, 1900, 0 },
	{ 80, 300, 2700, 7000, 2170, 6920, 920, 0 },
	{ 83, 300, 2700, 7000, 2830, 6740, 430, 0 },
	{ 85, 300, 2700, 7000, 3210, 6500, 290, 0 },
	{ 87, 300, 2700, 7000, 4050, 5780, 170, 0 },
	{ 89, 300, 2700, 7000, 4680, 5170, 150, 0 },
	{ 90, 300, 2700, 7000, 5190, 4660, 160, 0 },
	{ 91, 300, 2700, 7000, 5750, 4100, 150, 0 },
	{ 92, 300, 2700, 7000, 6390, 3470, 150, 0 },
	{ 93, 300, 2700, 7000, 7080, 2780, 140, 0 },
	{ 94, 300, 2700, 7000, 7770, 2110, 120, 0 },
	{ 95, 300, 2700, 7000, 8700, 1130, 170, 0 },
	{ 96, 300, 2700, 7000, 9270, 590, 140, 0 },
	{ 97, 300, 2700, 7000, 9660, 220, 110, 0 },
	{ 98, 300, 2700, 7000, 9880, 60, 60, 0 },
	{ 99, 300, 2700, 7000, 9940, 30, 30, 0 },
	{ 0 },
	{ 0 },
	{ 0 },
};
/* correlation next item odds */
static long corr_odds[ IOR_CORRELATE_ODDS + 2 ][ IOR_SKEW_LISTS + 3 ] = {
	{   0, 0, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, },
	{  10, 0, 1200, 1150, 1100, 1050, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1050, 1100, 1150, 1200, },
	{  20, 0, 1500, 1400, 1200, 1100, 1050, 1000, 1000, 1000, 1000, 1000, 1050, 1100, 1200, 1400, 1500, },
	{  35, 0, 2500, 2000, 1500, 1200, 1100, 1000, 1000, 1000, 1000, 1000, 1100, 1200, 1500, 2000, 2500, },
	{  50, 0, 4000, 3000, 2500, 2000, 1500, 1000, 1000, 1000, 1000, 1000, 1500, 2000, 2500, 3000, 4000, },
	{  65, 0, 5000, 3500, 2500, 2000, 1500, 1000,  800,  800,  800, 1000, 1500, 2000, 2500, 3500, 5000, },
	{  80, 0, 6000, 4500, 3000, 2500, 1500, 1000,  800,  800,  800, 1000, 1500, 2500, 3000, 4500, 6000, },
	{  90, 0, 7000, 5000, 3500, 2000, 1000,  500,  500,  500,  500,  500, 1000, 2000, 3500, 5000, 7000, },
	{  95, 0, 8000, 6000, 3500, 2000, 1000,  500,  500,  500,  500,  500, 1000, 2000, 3500, 6000, 8000, },
	{  98, 0, 9000, 7000, 4000, 2000, 1000,  500,  500,  500,  500,  500, 1000, 2000, 4000, 7000, 9000, },
	{ 100, 0, 9999, 5000, 3000, 1000,  500,  500,  500,  500,  500,  500,  500, 1000, 3000, 5000, 9999, },
	{ 0 },
};

    cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);
    if ( cur_test->t_skew < IOR_SKEW_MIN ) { /* no skew, so we bail */
	ior_debug_l( cfg, IOR_DEBUG_MINOR, "ior_skew_set: No skew, so nothing to do" );

	return( -1 );
    };

    result = 0;				/* all OK so far */

    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_set: Entering code -->>" );

    cfg->c_odds.o_odds = cfg->c_odds_i; /* link up odds items */

	    /* set the odds based on the skew - not ALL values present */
    for ( n_odds = 1;
	    ( n_odds < 25 ) &&
		( skew_odds[ n_odds + 1 ][ 0 ] <= cur_test->t_skew );
	    n_odds++ ) {
	/* the work is the search.... */
    };
					/* make skew match exactly */
    cur_test->t_skew = skew_odds[ n_odds ][ 0 ];

    sprintf( msg_buf, "setting odds from skew %d",
	    cur_test->t_skew );
    ior_verbose( cfg, msg_buf );

    select_odds.o_odds = select_items;	/* point to our list of odds */
    select_odds.o_items_count = IOR_SKEW_LISTS;
    for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
	select_items[ i ].i_id = i;
	select_items[ i ].i_id_ptr = NULL;
    };

					/* COPY the odds data */
    for ( i = 0, odds_total = 0; i < IOR_SKEW_LISTS; i++ ) {
	cfg->c_odds_i[ i ].i_id = i;
	cfg->c_odds_i[ i ].i_odds_start = odds_total;
	cfg->c_odds_i[ i ].i_odds_count = skew_odds[ n_odds ][ i + 1 ];
	odds_total += cfg->c_odds_i[ i ].i_odds_count;
	cfg->c_odds_i[ i ].i_odds_end = odds_total -
		( cfg->c_odds_i[ i ].i_odds_count > 0 ? 1 : 0 );

	sprintf( msg_buf, "    skew group %d (%ld%% of capacity) odds from %ld to %ld (count %ld)",
		i, skew_size[ i ],
		cfg->c_odds_i[ i ].i_odds_start,
		cfg->c_odds_i[ i ].i_odds_end,
		cfg->c_odds_i[ i ].i_odds_count );
	ior_verbose( cfg, msg_buf );
    };
    cfg->c_odds.o_items_count = IOR_SKEW_LISTS;
    cfg->c_odds.o_odds_count = odds_total;

    skew_current = 0;			/* no current capacity */
    skew_group = 0;			/* no groups accounted for */

    for ( i = 0; i < 3; i++ ) {		/* note skew details */
	cfg->c_skew_capacities[ i ] =
		skew_info[ n_odds ][ i + 1 ] / 100.0;
	cfg->c_skew_workloads[ i ] =
		skew_info[ n_odds ][ i + 4 ] / 100.0;

	skew_target = cfg->c_skew_capacities[ i ];
	cfg->c_skew_group_count[ i ] = 0;

	while ( skew_current < skew_target ) {
	    skew_current += skew_size[ skew_group++ ];
	    ( cfg->c_skew_group_count[ i ])++;
	};
    };

	/*** now set up the areas - each time, as area size can change */

    cfg->c_area = cur_test->t_area;	/* note active area size */

    nareas = cfg->c_max_dev_size / cfg->c_area;
    if ( nareas > IOR_AREA_GROUPING ) {	/* if more, areas get reused */
	nareas = IOR_AREA_GROUPING;
    };
    cfg->c_num_areas = nareas;		/* save total area count */
    cfg->c_areas = &( the_areas[ 0 ]);

    area_targets = nareas / 100.0;
    for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
	cur_skew = &( cfg->c_skewed[ i ]);

	cur_skew->s_id = i;

		/* zero out the lists so we can reuse them */
	cur_skew->s_areas = NULL;

	cur_skew->s_area_current = 0;
	cur_skew->s_area_goal =		/* scale # for this group */
		area_targets * skew_size[ i ];
    };


	/* NOTE that using the same seed gets the same skew every time */
    ior_random_seed( cfg, cur_test->t_seed ); /* MAKE the numbers match */


    group = ior_rand( cfg ) % IOR_SKEW_LISTS; /* pick starting list */
    direction = ior_rand( cfg ) % 1;	/* heading up or down */

    sprintf( msg_buf, "ior_skew_set: Starting area build (%ld areas)",
	    nareas );
    ior_debug_l( cfg, IOR_DEBUG_MINOR, msg_buf );

    for ( c_area = 0, location = cfg->c_area;
	    c_area < nareas; c_area++ ) {
	cur_skew = &( cfg->c_skewed[ group ]);

	sprintf( msg_buf, "ior_skew_set: adding area %ld to group %d (now %ld of %ld areas)",
		c_area, group, 
		cur_skew->s_area_current,
		cur_skew->s_area_goal );
	ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

	cur_area = &( the_areas[ c_area ]);
	cur_area->a_id = c_area;
	cur_area->a_start = location;
	cur_area->a_size = cfg->c_area;
	location += cfg->c_area;
	cur_area->a_end = location;	/* really -1, but compares are easier */

	cur_area->a_prev = NULL;	/* force no links */
	cur_area->a_next = NULL;
	cur_area->a_list = NULL;
					/* add to tail of list */
	ior_area( cfg, IOR_AREA_TAIL, cur_area, cur_skew );


	/* now the BIG challenge - where to put the NEXT area */

	overall_full = ( c_area * 100 ) / nareas; /* % of overall done */
	group_full = ( cur_skew->s_area_current * 100 ) /
		cur_skew->s_area_goal;

		/* bias to/away from group based on full ratios */
	correlate = cur_test->t_correlate *
		(( overall_full * 1.0 ) / group_full );
	if ( correlate > 98 ) {
	    correlate = 98;
	};

					/* if corellation matches, stay here */
	if (( ior_rand( cfg ) % 100 ) < correlate ) {
	    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_set: correlate says stay" );

	    ior_skew_check_next( cfg, &group, &direction );

	    continue; /*** ON to next area ***/
	};
					/* chance of changing direction */
					/*  ONLY used when overflowing... */
	if (( ior_rand( cfg ) % 100 ) >= correlate ) {
	    direction = !direction;
	};

	/* USE corr_odds based on non-deformed skew AND # volumes in the group */
	for ( n_odds = 1;
		( n_odds < IOR_CORRELATE_ODDS ) &&
		    ( corr_odds[ n_odds + 1 ][ 0 ] <= cur_test->t_correlate );
		n_odds++ ) {
	    /* the work is the search.... */
	};
		/* combine correlation odds with skew size (group size) */
		/*   ODDS of current group are 0 in corr_odds table */
	for ( i = 0; i < IOR_SKEW_LISTS; i++ ) {
	    next = ( i + group ) % IOR_SKEW_LISTS;
	    select_items[ next ].i_odds_count =
		corr_odds[ n_odds ][ i ] * skew_size[ next ];

	    sprintf( msg_buf, "Base %d, item %d, odds count %ld",
		    i, next, select_items[ next ].i_odds_count );
	    ior_debug_l( cfg, IOR_DEBUG_ALL, msg_buf );
	};
		/* total up the counts for odds picking */
	for ( i = 0, odds_total = 0; i < IOR_SKEW_LISTS; i++ ) {
	    select_items[ i ].i_odds_start = odds_total;
	    odds_total += select_items[ i ].i_odds_count;
	    select_items[ i ].i_odds_end = odds_total -
		( select_items[ i ].i_odds_count > 0 ? 1 : 0 );

	    sprintf( msg_buf, "Item %d, odds start %ld / count %ld / end %ld",
		    i, select_items[ i ].i_odds_start,
		    select_items[ i ].i_odds_count,
		    select_items[ i ].i_odds_end );
	    ior_debug_l( cfg, IOR_DEBUG_ALL, msg_buf );
	};
	select_odds.o_odds_count = odds_total;

		/* use the odds selector to pick the next group */
	group = ior_odds_pick( cfg, &select_odds );

	ior_skew_check_next( cfg, &group, &direction );
    };

	/* now we shift the capacity around if requested */
	/*   These will be the first in the lists, NOT randomly picked */
    if ( cur_test->t_shift ) {

	/*  this is POOR coding practis, but will get the shift */
	/*  that is needed - AS LONG AS the skew_size[] dats is */
	/*  not changed - else it may be GARBAGE ****/

	shift_hot_group = 0;		/* start from first group */
	hot_skew = &( cfg->c_skewed[ shift_hot_group ]);
	hot_group_remain = hot_skew->s_area_current;
	shift_med_group = 12;		/* start from 13th group */
	med_skew = &( cfg->c_skewed[ shift_med_group ]);
	med_group_remain = med_skew->s_area_current;
	shift_cool_group = 15; /* start from last group */
	cool_skew = &( cfg->c_skewed[ shift_cool_group ]);
	cool_group_remain = cool_skew->s_area_current;

	for ( shift_count = (( nareas * cur_test->t_shift ) / 100 );
		shift_count > 0; shift_count -= 3 ) {

	    hot_area = hot_skew->s_areas;
	    med_area = med_skew->s_areas;
	    cool_area = cool_skew->s_areas;

	    sprintf( msg_buf, "skew shift: hot area %ld (group %d), medium area %ld (group %d), cool  area %ld (group %d) - %ld more to go",
		hot_area->a_id, shift_hot_group,
		med_area->a_id, shift_med_group,
		cool_area->a_id, shift_cool_group,
		(long)( shift_count - 3 ));
	    ior_debug_l( cfg, IOR_DEBUG_SMALL, msg_buf );

	    ior_area( cfg, IOR_AREA_TAIL, hot_area, cool_skew );
	    ior_area( cfg, IOR_AREA_TAIL, med_area, hot_skew );

			/* if groups have met, skip this move */
	    if ( shift_med_group != shift_cool_group ) {
		ior_area( cfg, IOR_AREA_TAIL, cool_area, med_skew );
	    };

	    if ( --hot_group_remain < 1 ) {
		hot_skew = &( cfg->c_skewed[ ++shift_hot_group ]);
		hot_group_remain = hot_skew->s_area_current;
	    };

	    if ( --med_group_remain < 1 ) {
		med_skew = &( cfg->c_skewed[ ++shift_med_group ]);
		med_group_remain = med_skew->s_area_current;
	    };

	    if ( --cool_group_remain < 1 ) {
		cool_skew = &( cfg->c_skewed[ --shift_cool_group ]);
		cool_group_remain = cool_skew->s_area_current;
	    };


	    /* back when it was only hot and cold, this worked */
	    /* now this should never happen,...
	    if ( shift_hot_group == shift_cool_group ) {

		sprintf( msg_buf, "shift resulted in areas moving in the same group - stopped with %ld to shift",
		    shift_count );
		ior_warn( cfg, msg_buf );

		shift_count = 0;
	    };
	       SO this is left out  ****/


	};
    };


    /* the areas are randomized in the skew lists witin each device test */


    ior_debug_l( cfg, IOR_DEBUG_SMALL, "ior_skew_set: <<-- Leaving code" );

    return( result );
};


/*
 * ior_run_tests - run the tests on the devices
 */
int	ior_run_tests( ior_config  *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    int		done;			/* done with all devices? */
    int		pattern;		/* pattern being logged */
    ior_test	*cur_test;		/* working test */
    ior_device	*cur_dev;		/* current device */
    ior_clock	cur_time;		/* current time */
    char	cur_date[ 40 ];		/* current date string */
    int		p_pid;			/* process ID of this parent process */
    FILE	*perf_file;		/* performance data of a process */
    char	perf_name[ 60 ];	/* name of the performance file */
    char	perf_data[ 1024 ];	/* process performance data */
    int		retry_needed;		/* need to retry? */
    int		retry_count;		/* have we re-run before? */

    result = 0;				/* all OK so far */

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_tests: Entering code -->>" );

    signal( SIGINT, ior_signal );	/* handle signals */
    signal( SIGTERM, ior_signal );
    signal( SIGSEGV, ior_signal );

    retry_count = 0;			/* no retries yet */

    p_pid = getpid();			/* remember our process ID */

    for ( cfg->c_cur_test = 0;
	    cfg->c_cur_test < cfg->c_ntest && cfg->c_errors == 0;
	    cfg->c_cur_test++ ) {

	cur_test = &( cfg->c_tests[ cfg->c_cur_test ]);

	if ( !cur_test->t_valid ) {	/* skip invalid tests */
	    continue;
	};

	ior_skew_set( cfg );		/* set up skew performance data */

	if ( cur_test->t_iops > 0 ) {	/* slow to target I/O rate */

					/* iops per second per active device */
	    cfg->c_target_resp =
		(long int)(( 1000000.0 * cfg->c_adev )/ cur_test->t_iops );

	    cfg->c_target_sec = cfg->c_target_resp / 1000000.0; /* and in sec.  */

	} else {
	    cfg->c_target_resp = 0;
	    cfg->c_target_sec = 0;
	};

	ior_log( cfg, "\n" );

#ifdef	IOR_ENGINEERING

	ior_log( cfg, "ior_run_tests: ENGIEERING MODE is defined\n" );

		/* clear terminal buffer before script starts */
	fflush( stdout );

	ior_eng_pre_test( cfg );

#endif

	if ( cfg->c_tests[ cfg->c_cur_test ].t_pause > 0 ) {
	    sprintf( msg_buf,
		    "\nPausing %s before starting test %d . . . .",
		    ior_time_to_ascii( cfg,
			    cfg->c_tests[ cfg->c_cur_test ].t_pause ),
		    cfg->c_cur_test + 1 );
	    ior_log( cfg, msg_buf );

	    fflush( stdout );		/* flush terminal and log */
	    if ( cfg->c_log_file > (FILE *) 0 ) {
		fflush( cfg->c_log_file );
	    };

	    if ( cfg->c_no_testing ) {
		ior_log( cfg, "\t(testing disabled - no pause)" );
	    } else {
		ior_sleep( cfg, cfg->c_tests[ cfg->c_cur_test ].t_pause );
	    };
	};

	ior_log( cfg, "" );		/* note start of test */
	sprintf( msg_buf, "\tBeginning test %d '%s':",
		cfg->c_cur_test + 1, cur_test->t_name );
	ior_log( cfg, msg_buf );
	sprintf( msg_buf, "\t\t    Ignore: %s",
		ior_time_to_ascii( cfg, cur_test->t_ignore ));
	ior_log( cfg, msg_buf );
	sprintf( msg_buf, "\t\t    Duration: %s",
		ior_time_to_ascii( cfg, cur_test->t_duration ));
	ior_log( cfg, msg_buf );

	if ( cur_test->t_skew > 0 ) {	/* note any active skew */
	    sprintf( msg_buf, "\t\t    Sub-LUN I/O skew: %d%%",
		    cur_test->t_skew );
	    ior_log( cfg, msg_buf );
	    sprintf( msg_buf, "\t\t        -> First %.0f%% of capacity drives %4.1f%% of I/O",
		    cfg->c_skew_capacities[ 0 ],
		    cfg->c_skew_workloads[ 0 ]);
	    ior_log( cfg, msg_buf );
	    sprintf( msg_buf, "\t\t        -> Next %.0f%% of capacity drives %4.1f%% of I/O",
		    cfg->c_skew_capacities[ 1 ],
		    cfg->c_skew_workloads[ 1 ]);
	    ior_log( cfg, msg_buf );
	    sprintf( msg_buf, "\t\t        -> Last %.0f%% of capacity drives %4.1f%% of I/O",
		    cfg->c_skew_capacities[ 2 ],
		    cfg->c_skew_workloads[ 2 ]);
	    ior_log( cfg, msg_buf );
	    sprintf( msg_buf, "\t\t        Skew area: %s",
		    ior_size_to_ascii( cfg, cur_test->t_area ));
	    ior_log( cfg, msg_buf );
	    sprintf( msg_buf, "\t\t        Skew correlation: %d%%",
		    cur_test->t_correlate );
	    ior_log( cfg, msg_buf );
	    if ( cur_test->t_shift > 0 ) {
		sprintf( msg_buf, "\t\t        Skew shift: %d%%",
			cur_test->t_shift );
		ior_log( cfg, msg_buf );
	    };
	};

	if ( cur_test->t_iops > 0 ) {
	    sprintf( msg_buf, "\t\t    I/Os per Second: %ld",
		    cur_test->t_iops );
	} else {
	    sprintf( msg_buf, "\t\t    I/Os per Second: Not limited" );
	};
	ior_log( cfg, msg_buf );
					/* note contents of test */
	for ( pattern = 0; pattern < cfg->c_npat; pattern++ ) {
	    if ( cur_test->t_pat_pct[ pattern ] > 0 ) {
		sprintf( msg_buf, "\t\t%3d%% pattern %d '%s'",
			cur_test->t_pat_pct[ pattern ], pattern + 1,
			cfg->c_pats[ pattern ].p_name );
		ior_log( cfg, msg_buf );
	    };
	};

	cfg->c_reads = 0;		/* start all counts clean */
	cfg->c_writes = 0;
	cfg->c_blocks_read = 0;
	cfg->c_blocks_written = 0;

	ior_sleep( cfg, 1 );		/* get to start of a new second */

	cfg->c_start_time = ior_get_time( cfg );
	ior_date_string( cfg, cfg->c_start_time, cur_date );

	for ( cfg->c_cur_dev = 0, cfg->c_cur_adev = 0;
		( cfg->c_cur_dev < cfg->c_ndev ) &&
		    ( cfg->c_errors == 0 );
		/*** Increments below ***/ ) {

	    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

	    if ( !cur_dev->d_valid ) {	/* skip invalid devices */
		cfg->c_cur_dev++;	/* moving to next active device */
		continue;
	    };

	    sprintf( msg_buf,
		    "Test %d starting, file '%s', device %d copy %d, at %s",
		    cfg->c_cur_test + 1, cur_dev->d_name,
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1, cur_date );
	    ior_log( cfg, msg_buf );

	    if ( cfg->c_no_testing ) {
		ior_log( cfg, "Testing disabled - no test run" );

		cfg->c_cur_dev++;	/* moving to next active device */
		continue;
	    };

	    cfg->c_is_active++;		/* multiple processes are live */

	    cur_dev->d_is_active++;	/* device is now active */

	    fflush( cfg->c_log_file );	/* flush our files */
	    fflush( cfg->c_perf_file );
	    fflush( stdout );
	    fflush( stderr );		/* just in case */

	    switch( cur_dev->d_procs[ cfg->c_cur_adev ] = fork()) {
	    case -1:			/* fork error - GIVE UP */
		perror( "Child fork" );
		ior_error( cfg, "Unable to fork child process - killing child processes and ABORTING" );

		result = -1;
		ior_signal_kids( cfg, SIGKILL );
		ior_cleanup( cfg );
		exit( result );

		/* WE NEVER GET HERE - program done */
		break;

	    case 0:			/* in child */

		signal( SIGINT, SIG_DFL ); /* back to defaults */
		signal( SIGTERM, SIG_DFL );
		signal( SIGSEGV, SIG_DFL );

		ior_randomize( cfg ); /* randomize our results */

    /*  Tried using file locks for the child processes, and letting	*/
    /*  them all write to the same file.  Since restarts are desired,	*/
    /*  this code makes them each write their performance data to a	*/
    /*  separate file.  These are read after successful completion and	*/
    /*  added to the real performance log.				*/

		sprintf( perf_name, PROC_PERF_FILE,
			cfg->c_perf_dir, p_pid, cfg->c_cur_dev,
			cfg->c_cur_adev );
		sprintf( msg_buf,
			"Performance file base is '%s'", perf_name );
		ior_debug_l( cfg, IOR_DEBUG_MAJOR, msg_buf );
		if (( cfg->c_perf_file = fopen( perf_name, "w" ))
			== NULL ) {
		    perror( perf_name );
		    ior_error( cfg, "Can't open process performance file" );

		    result = -1 ;

		} else {

		    result = ior_run_dev_test( cfg ); /* do the real work */

		};

		exit( result );		/* and the child exits */

	    default:			/* in parent */
		break;
	    };
					/*** NOT done in for() stmt ***/
	    cfg->c_cur_adev++;		/* moving to next device copy */
	    if ( cur_dev->d_count <= cfg->c_cur_adev ) {
		cfg->c_cur_dev++;	/* moving to next active device */
		cfg->c_cur_adev = 0;
	    };
	};

	/* All devices should now be running */

	retry_needed = 0;		/* assume no retry */
	done = 0;			/* waiting for kids */
	while ( !done ) {

	    ior_sleep( cfg, 10 );	/* let tests run a while */

	    ior_debug_l( cfg, IOR_DEBUG_MINOR, "Checking for child status" );

	    done = 1;			/* assume done, fix later */

	    for ( cfg->c_cur_dev = 0, cfg->c_cur_adev = 0;
		    cfg->c_cur_dev < cfg->c_ndev; ) {

		sprintf( msg_buf,
			"  Checking device %d copy %d . . .",
			cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
		ior_debug_l( cfg, IOR_DEBUG_ALL, msg_buf );

		cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

					/* skip invalid and inactive devices */
		if ( !cur_dev->d_valid || !cur_dev->d_is_active ) {

		    cfg->c_cur_dev++;	/* moving to next active device */
		    cfg->c_cur_adev = 0; /* first active copy of new target */

		    ior_debug_l( cfg, IOR_DEBUG_ALL, "    Not active/valid, moving on" );

		    continue;
		};

					/* check the process status */
		result = ior_proc_check( cfg );

		if ( cur_dev->d_is_active ) {
		    done = 0;		/* not done yet */
		};

		cfg->c_cur_adev++;		/* moving to next device copy */
		if ( cur_dev->d_count <= cfg->c_cur_adev ) {

		    cfg->c_cur_dev++;	/* moving to next active device */
		    cfg->c_cur_adev = 0;
		};
	    };

	    if ( !done ) {		/* watch for errant process */
		cur_time = ior_get_time( cfg );
		if (( cur_time - cfg->c_start_time ) >
			( cur_test->t_duration + IOR_OVER_MAX )) {
		    ior_warn( cfg, "Processes running over time limit" );
		    ior_signal_kids( cfg, SIGKILL );

		    retry_needed = 1;	/* we need to retry */
		};
					/* sleep longer if not near done */
		if (( cur_time - cfg->c_start_time ) <
			( cur_test->t_duration - 30 )) {
		    ior_sleep( cfg, 20 ); /* sleep long and check again */
		} else {
		    ior_sleep( cfg, 1 ); /* sleep and check again */
		};
	    };
	};

	cfg->c_is_active = 0;		/* multiple processes are done */

	if ( retry_needed ) {		/* invalid run - try again */
	    retry_count++;

	    if ( retry_count > 3 ) {	/* looks hopless - give in */
					/* NOTE - adds to error count */
		ior_error( cfg, "Giving up - Too many retries" );
	    } else {
		cfg->c_cur_test--;	/* back up one test */
		ior_debug_l( cfg, IOR_DEBUG_MAJOR, "Errors on test, retry" );
	    };

	} else {			/* valid run - save the stats */

	    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "Test completed cleanly" );

	    retry_count = 0;		/* not repeatting this one */

	    for ( cfg->c_cur_dev = 0, cfg->c_cur_adev = 0;
		    ( cfg->c_cur_dev < cfg->c_ndev );
		    /*** Increments below ***/ ) {

		cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

					/* skip no test/invalid devices */
		if ( cfg->c_no_testing || !cur_dev->d_valid ) {

		    cfg->c_cur_dev++;	/* moving to next active device */

		    continue;
		};
					/* read one line result from test */
		sprintf( perf_name, PROC_PERF_FILE,
			cfg->c_perf_dir, p_pid, cfg->c_cur_dev,
			cfg->c_cur_adev );

		sprintf( msg_buf, "Collecting performace data from '%s'",
			perf_name );
		ior_debug_l( cfg, IOR_DEBUG_MAJOR, msg_buf );

		perf_file = fopen( perf_name, "r" );
		fgets( perf_data, 1024, perf_file );
		fputs( perf_data, cfg->c_perf_file );
		fclose( perf_file );
		unlink( perf_name );	/* delete test result file */

					/*** NOT done in for() stmt ***/
		cfg->c_cur_adev++;	/* moving to next device copy */
		if ( cur_dev->d_count <= cfg->c_cur_adev ) {
		    cfg->c_cur_dev++;	/* moving to next active device */
		    cfg->c_cur_adev = 0;
		};
	    };

	    fflush( cfg->c_perf_file );	/* flush our results */
	};

    };

    if ( cfg->c_errors ) {		/* we are dead */
	ior_warn( cfg, "Testing aborted due to errors" );
    };

    ior_debug_l( cfg, IOR_DEBUG_MAJOR, "ior_run_tests: <<-- Leaving code" );

    return( result );
}

/*
 * ior_proc_check - check the status of a given process
 */
int	ior_proc_check( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    ior_device	*cur_dev;		/* current device */
    ior_clock	cur_time;		/* current time */
    char	cur_date[ 40 ];		/* current date string */
    int		pid;			/* process ID we see */
    int		exit_status;		/* how did process end */

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    sprintf( msg_buf,
	    "ior_proc_check: Entering code -- proc %ld, device %d copy %d",
	    cur_dev->d_procs[ cfg->c_cur_adev ],
	    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1 );
    ior_debug( cfg, msg_buf );

					/* skip inactive copies */
    if ( cur_dev->d_procs[ cfg->c_cur_adev ] < 1 ) {
	return( result );
    };
					/* get current process status */
    pid = waitpid( cur_dev->d_procs[ cfg->c_cur_adev ],
	    &exit_status, WNOHANG );

    if ( pid < 0 ) {			/* error on the process */
	perror( cur_dev->d_name ); /* note the error */

	sprintf( msg_buf,
		"Process %ld died testing device %s (copy %d)",
		cur_dev->d_procs[ cfg->c_cur_adev ],
		cur_dev->d_name, cfg->c_cur_adev + 1 );
	ior_error( cfg, msg_buf );

					/* forget completed process */
	cur_dev->d_procs[ cfg->c_cur_adev ] = 0;
	cur_dev->d_is_active--;		/* one more no longer active */

    } else if ( pid > 0 ) {		/* done running */

	if ( WIFEXITED( exit_status ) &&
		WEXITSTATUS( exit_status ) != 0 ) {
	    sprintf( msg_buf,
		    "Test %d, file '%s', device %d copy %d, died with status %d",
		    cfg->c_cur_test + 1,
		    cfg->c_devs[ cfg->c_cur_dev ].d_name,
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		    IOR_EXIT_STATUS( exit_status ));
	    ior_error( cfg, msg_buf );
	} else {
	    cur_time = ior_get_time( cfg );
	    ior_date_string( cfg, cur_time, cur_date );
	    sprintf( msg_buf,
		    "Test %d finished, file '%s', device %d copy %d, at %s",
		    cfg->c_cur_test + 1,
		    cfg->c_devs[ cfg->c_cur_dev ].d_name,
		    cfg->c_cur_dev + 1, cfg->c_cur_adev + 1,
		    cur_date );
	    ior_log( cfg, msg_buf );
	};
					/* forget completed process */
	cur_dev->d_procs[ cfg->c_cur_adev ] = 0;
	cur_dev->d_is_active--; /* one more no longer active */
    };

    /* NOTE if pid returned was 0, process is still running */
    /*     For those we just wait and check again */

    ior_debug( cfg, "ior_proc_check: <<-- Leaving code" );

    return( result );
}

/*
 * ior_cleanup - perform post-testing house cleaning
 */
int	ior_cleanup( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */
    int		cur_res;		/* result of current operation */
    int		dev;			/* device we are checking */

    ior_debug( cfg, "ior_cleanup: Entering code -->>" );

    result = 0;				/* all OK so far */

#ifdef	IOR_ENGINEERING

    ior_log( cfg, "ior_cleanup: ENGIEERING MODE is defined" );

    ior_eng_clean( cfg );

#endif

    ior_debug( cfg, "Starting file close" );

					/* close open devices - just in case */
    for ( dev = 0; dev < cfg->c_ndev; dev++ ) {
	if ( cfg->c_devs[ dev ].d_fid > -1 ) {
	    cur_res = ior_close_dev( cfg, dev );
	    if ( cur_res != 0 ) {
		result = cur_res;
	    };
	};
    };

    if ( cfg->c_perf_file > (FILE *) 0 ) { /* close the performance file */
	if ( fclose( cfg->c_perf_file ) != 0 ) {
	    cfg->c_perf_file = (FILE *) 0;
	    perror( cfg->c_perf_name );
	    ior_error( cfg, "Close of performance file failed" );

	    result = -2;
	};
	cfg->c_perf_file = (FILE *) 0;
    };

    if ( cfg->c_log_file > (FILE *) 0 ) { /* close the log file */
	if ( fclose( cfg->c_log_file ) != 0 ) {
	    cfg->c_log_file = (FILE *) 0;
	    perror( cfg->c_log_name );
	    ior_error( cfg, "Close of log file failed" );
	    result = -3;
	};
	cfg->c_log_file = (FILE *) 0;
    };

    ior_debug( cfg, "ior_cleanup: <<-- Leaving code" );

    return( result );
}

/*
 * ior_usage - note usage of iorate
 */
int	ior_usage( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    cfg->c_silent = 0;			/* spread the word */

    ior_msg( cfg, "USAGE",
	    "iorate [-alnsuv] [-d[<d_level]] [-c<shift>] [-r<rate>] [-i<iops_file>]\r\n\t[-f<dev_file>] [-p<pat_file>] [-t<test_file>] [-o<outbase>]\r\n\t[--threads=<n>] [--scale_threads_by=<n> --scale_threads_count=<n>]" );

	/* only to stderr, we want to be a bit more helpful */
    fprintf( stderr, "    Where:\n" );
    fprintf( stderr, "\ta - allow short reads (do not abort when reads do not return all data)\n" );
    fprintf( stderr, "\tl - show limits on sizes for this version of iorate\n" );
    fprintf( stderr, "\tn - no testing (read inputs and get ready but no I/O)\n" );
    fprintf( stderr, "\ts - silent (minimal output)\n" );
    fprintf( stderr, "\tu - use direct I/O (bypassing buffers)\n" );
    fprintf( stderr, "\tv - verbose (LOTS of output about setup and progress)\n" );
    fprintf( stderr, "\td<d_level> - turn on debugging output (to d_level)\n" );
    fprintf( stderr, "\tc<shift> - change (increase) skew shift by <shift>%%\n" );
    fprintf( stderr, "\tr<rate> - scale test target iops to <rate>%%\n" );
    fprintf( stderr, "\ti<iops_file> - file to read for target iops per test\n" );
    fprintf( stderr, "\tf<dev_file> - alternate device file to devices.ior\n" );
    fprintf( stderr, "\tp<pat_file> - alternate pattern file to patterns.ior\n" );
    fprintf( stderr, "\tt<test_file> - alternate test file to tests.ior\n" );
    fprintf( stderr, "\to<outbase> - base name to use on outpur files (can include directory names)\n" );
    fprintf( stderr, "\t--threads=<n> - override device copy count (threads) for all devices\n" );
    fprintf( stderr, "\t--scale_threads_by=<n> - add <n> threads to all devices for each additional run\n" );
    fprintf( stderr, "\t--scale_threads_count=<n> - number of additional runs to perform with scaled threads\n" );

    fflush( stderr );

    return( result );
}

/*
 * ior_error - note error
 */
int	ior_error( ior_config *cfg,char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 error to print */
{
    cfg->c_errors++;			/* mark that we have seen an error */

    return( ior_msg( cfg, "ERROR", msg ));
}

/*
 * ior_warn - note warning
 */
int	ior_warn( ior_config *cfg,char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 warning to print */
{
    return( ior_msg( cfg, "WARNING", msg ));
}

/*
 * ior_msg - note message
 */
int	ior_msg( ior_config *cfg, char *msg_type, char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg_type;		 message prefix */
/* char		*msg;			 message to print */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( msg_type && *msg_type ) {
	fprintf( stderr, "%s: %s: %s\n", cfg->c_program, msg_type, msg );

        sprintf( log_buf, "%s: %s\n", msg_type, msg);
    } else {
	fprintf( stderr, "%s: %s\n", cfg->c_program, msg );

        sprintf( log_buf, "%s\n", msg);
    };

    result = ior_write_log( cfg, log_buf );

    return( result );
}

/*
 * ior_verbose - print verbose messages if desired
 */
int	ior_verbose( ior_config *cfg, char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 message to print */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( cfg->c_verbose ) {
	sprintf( log_buf, "%s\n", msg );
	fprintf( stdout, "%s", log_buf );
	result = ior_write_log( cfg, log_buf );
    };

    return( result );
}

/*
 * ior_debug_l - print debug messages at a givel level if desired
 */
int	ior_debug_l( ior_config *cfg, int level, char *msg )
/* ior_config	*cfg;			our configuration */
/* int		level;			level of the emessage */
/* char		*msg;			message to print */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( cfg->c_debug_level < level ) {	/* not at this level, so skip */
	return( 1 );
    };

    if ( cfg->c_debug ) {		/* if debugging . . . */
	result = ior_log( cfg, msg );	/*   then log the information */
    };

    return( result );
}

/*
 * ior_debug - print debug messages if desired
 */
int	ior_debug( ior_config *cfg, char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 message to print */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( cfg->c_debug ) {		/* if debugging . . . */
	result = ior_log( cfg, msg );	/*   then log the information */
    };

    return( result );
}

/*
 * ior_log - log information to the log file
 */
int	ior_log( ior_config *cfg, char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 message for the log */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    sprintf( log_buf, "%s\n", msg );

    if ( !cfg->c_silent ) {
	fprintf( stdout, "%s", log_buf );
    };

    result = ior_write_log( cfg, log_buf );

    return( result );
}

/*
 * ior_write_log - actually write data to the log file
 */
int	ior_write_log( ior_config *cfg, char *msg )
/* ior_config	*cfg;			 our configuration */
/* char		*msg;			 message */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( cfg->c_log_file > (FILE *) 0 ) {
	if ( cfg->c_is_active ) {	/* saftey if forked processes */
	    ior_set_lock( cfg );
	};
					/* print the message */
	fprintf( cfg->c_log_file, "%s", msg );

	if ( cfg->c_is_active ) {	/* saftey if forked processes */
	    fflush( cfg->c_log_file );
	    ior_clear_lock( cfg );
	};
    };

    return( result );
}

/*
 * ior_strdup - duplicate a string
 */
char	*ior_strdup(ior_config *cfg, char *str )
/* ior_config	*cfg;			 our configuration */
/* char		*str;			 string to duplicate */
{
    char	*result;		/* our result string */

    ior_debug( cfg, "ior_strdup: Entering code -->>" );

					/* make space for the copy */
    result = (char *) malloc( strlen( str ) + 2 );
    if ( result == NULL ) {
	ior_error( cfg, "MALLOC failed in 'ior_strdup'" );
	ior_cleanup( cfg );
	exit( -20 );
    };

    strcpy( result, str );		/* copy the string */

    ior_debug( cfg, "ior_strdup: <<-- Leaving code" );

    return( result );
}

/*
 * ior_set_write - build the pattern that all writes will use
 */
int	ior_set_write( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		i;			/* byte counters */

    ior_debug( cfg, "ior_set_write: Entering code -->>" );

    result = 0;

#ifdef	NO_RAND_WRITE
    memset( cfg->c_read_buf, '^', IOR_MAX_IO_SIZE + 2048 );

#else
					/* set start buffer with line of text */
    sprintf( (char *) ( cfg->c_write_buf ), "**** Start of Block ****" );

					/* fill to top of buffer */
    for ( i = 24; i < IOR_MAX_IO_SIZE + 2047; i++ ) {
	cfg->c_write_buf[ i ] = ior_rand( cfg );
    };
					/* set the last position to \0 */
    cfg->c_write_buf[ IOR_MAX_IO_SIZE + 2047 ] = '\0';

#endif

    ior_debug( cfg, "ior_set_write: <<-- Leaving code" );

    return( result );
}

/*
 * ior_signal_kids - send a signal to all child processes
 */
int	ior_signal_kids( ior_config *cfg, int sig )
/* ior_config	*cfg;			 our configuration */
/* int		sig;			 signal to send */
{
    int		result;			/* final return code */
    int		dev;			/* device we are looking at */
    int		copy;			/* device we are looking at */
    int		pid;			/* process we are signaling */
    ior_device	*cur_dev;		/* current device */
    char	p_msg_buf[ 256 ];	/* local message buffer */

    result = 0;				/* all OK so far */

    for ( dev = 0; dev < cfg->c_ndev; dev++ ) {
	cur_dev = &( cfg->c_devs[ dev ]);

	if( cur_dev->d_valid && cur_dev->d_is_active ) {
	    for ( copy = 0; copy <= cur_dev->d_count; copy++ ) {

		pid = cur_dev->d_procs[ copy ];
		if ( pid == 0 ) {	/* make sure we really are running */
		    continue;
		};

		if ( sig == SIGKILL ) {
		    sprintf( p_msg_buf,
			    "Killing child process %d (testing device %d, copy %d, file '%s')",
			    pid, dev + 1, copy + 1, cur_dev->d_name );
		    ior_warn( cfg, p_msg_buf );
		};

		if ( kill( pid, sig ) != 0 ) {
		    sprintf( p_msg_buf, "%d", pid );
		    perror( p_msg_buf );
		    ior_error( cfg, "Attempt to signal child process failed" );
		    cfg->c_errors++;
		};
	    };
	};
    };

    return( result );
}

/*
 * ior_signal - signal handling routine
 */
void	ior_signal(int sig)
/*int	sig;*/
{
    switch ( sig ) {			/* process the signal */
    case SIGSEGV:
	signal_config->c_is_active = 0;	/* no need to lock log */
	ior_log( signal_config,
		"Caught segmentation violation signal, aborting . .  ." );
	ior_signal_kids( signal_config, SIGKILL );
	ior_cleanup( signal_config );
	exit( -20 );
	break;

    case SIGINT:
    case SIGTERM:
	signal_config->c_is_active = 0;	/* no need to lock log */
	ior_log( signal_config,
		"Caught termination signal, aborting . .  ." );
	ior_signal_kids( signal_config, SIGKILL );
	ior_cleanup( signal_config );
	exit( -21 );
	break;
    };
}
