/**************************************************************************
 *
 *  ior_mach.c - the IORATE machine specific routines
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_mach.c,v 3.7 2011/11/03 15:27:25 westiv Exp westiv $";

/*
 * We load fcntl for AIX early, or bad things happen
 */
#if	defined( _AIX )
#include <fcntl.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>


#if !defined( _AIX )
#include <fcntl.h>
#endif
/*
 * Solaris needs ior_mach.h to be after the above or
 *     llseek() returns 4-byte values
 *  -- Specifically this seems to be sys/types.h
 */

#include "iorate.h"

/*
 * Default: enabled (set -DIOR_USE_PREAD_PWRITE=0 to disable).
 * FIX: Cygwin raw devices fail with pread/pwrite ("Illegal seek"),
 *      so force legacy lseek+read/write method on Cygwin.
 * FIX: AIX raw devices do NOT support pread/pwrite; must use lseek+read/write.
 */
#ifndef IOR_USE_PREAD_PWRITE
#ifdef __CYGWIN__
#define IOR_USE_PREAD_PWRITE 0
#elif defined(_AIX)
#define IOR_USE_PREAD_PWRITE 0
#else
#define IOR_USE_PREAD_PWRITE 1
#endif
#endif


/*
 * File locking portability:
 * - Some platforms (notably Cygwin) do not provide flock64/F_SETLK64.
 * - When _FILE_OFFSET_BITS=64 is set, struct flock uses 64-bit off_t anyway.
 */
#if defined(IOR_LARGE_FILES) && defined(F_SETLK64) && !defined(__CYGWIN__)
typedef struct flock64 ior_flock_t;
#define IOR_SET_LOCK_FLAG F_SETLK64
#else
typedef struct flock  ior_flock_t;
#define IOR_SET_LOCK_FLAG F_SETLK
#endif

int	errno;				/* define global error number */

extern int ior_dev_lock( ior_config *cfg, long dev );
extern int ior_dev_unlock( ior_config *cfg, long dev );
extern int ior_time_usec( ior_config *cfg, long *sec, long *usec );

/*
 * ior_open_dev - open a device for access
 */
int	ior_open_dev( ior_config *cfg, int dev )
/* ior_config	*cfg; our configuration */
/* int	dev; which device to open */
{
    int	result; /* final return code */
    int	err; /* file error we saw */
    int	open_flags; /* how to open file */
    ior_device	*cur_dev; /* our device */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    sprintf( msg_buf, "ior_open_dev: Opening file %d '%s'", (int) dev + 1, cur_dev->d_name);
    ior_debug( cfg, msg_buf );

    if ( cur_dev->d_fid > -1 ) {
	    sprintf( msg_buf, "Attempt to open file %d '%s' - already open",
		dev + 1, cur_dev->d_name );
	    ior_error( cfg, msg_buf );
	    result = -1;
    } else {
	    open_flags = ( cur_dev->d_read_only ? IOR_OPEN_RD : IOR_OPEN_RDWR )
		| ( cur_dev->d_is_async ? IOR_OPEN_ASYNC : IOR_OPEN_ASYNC );
#if defined(_AIX)
	    /* On AIX, do NOT use O_DIRECT for raw devices; it can cause EINVAL. */
	    /* If device name starts with /dev/r, assume raw and skip O_DIRECT. */
	    if (cfg->c_direct_io && strncmp(cur_dev->d_name, "/dev/r", 6) != 0) {
		    open_flags |= IOR_DIRECT_IO;
	    }
#else
	    if ( cfg->c_direct_io ) {
		    open_flags |= IOR_DIRECT_IO;
	    }
#endif
#ifdef __CYGWIN__
    open_flags |= O_BINARY;
    if (open_flags & O_DIRECT) {
        open_flags &= ~O_DIRECT;
        ior_debug(cfg, "ior_open_dev: Forced removal of O_DIRECT for Cygwin compatibility");
    }
#endif
	    sprintf( msg_buf, "    -> file flags are %d", open_flags );
	    ior_debug( cfg, msg_buf );
	    cur_dev->d_fid = open( cur_dev->d_name, open_flags );
	    if ( cur_dev->d_fid <= 0 ) {
		    cur_dev->d_fid = -1;
		    err = errno;
		    perror( cur_dev->d_name );
		    sprintf( msg_buf, "Attempt to open file %d '%s' failed",
			    dev + 1, cur_dev->d_name );
		    ior_error( cfg, msg_buf );
		    sprintf( msg_buf, "    -> Error number was %d", err );
		    ior_debug( cfg, msg_buf );
		    result = -2;
	    } else {
		    if ( cur_dev->d_capacity < 1 ) {
			    result = ior_get_capacity( cfg, dev );
		    };
	    };
	    result = ior_dev_lock( cfg, dev );
    };
    cfg->c_pos = -10000;
    return( result );
}

/*
 * ior_close_dev - close a device
 */
int	ior_close_dev( ior_config *cfg, int dev )
/* ior_config	*cfg; our configuration */
/* int	dev; which device to close */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    sprintf( msg_buf, "Closing file %d '%s'", dev + 1, cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

    if ( cur_dev->d_fid < 0 ) { /* not open? */
	sprintf( msg_buf, "Attempt to close file %d '%s' - not open",
		(int) dev + 1, cur_dev->d_name );
	ior_error( cfg, msg_buf );
	result = -1;
    } else {				/* close the file */

	ior_dev_unlock( cfg, dev );	/* remove lock if needed */

	result = close( cur_dev->d_fid );
	if ( result < 0 ) {		/* close error? */
	    perror( cur_dev->d_name );
	    ior_error( cfg, "Error in file close" );
	};
    };

    cfg->c_pos = -1;			/* be sure no valid position */
    cur_dev->d_fid = -1;		/* make sure it is not used again */

    return( result );
}

/*
 * ior_read - do a read from the target device
 */
int	ior_read( ior_config *cfg, long io_size, double *io_resp )
/* ior_config	*cfg; our configuration */
/* long		io_size; size of this read */
/* double	*io_resp; response time seen */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    long	bytes_read; /* size read */
    long	tollerate; /* size to tollerate being off by */
    long	start_sec; /* starting seconds */
    long	start_usec; /* starting micro seconds */
    long	end_sec; /* ending seconds */
    long	end_usec; /* ending micro seconds */
    double	resp_time; /* overall response time */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( cfg->c_verbose ) {
        sprintf( msg_buf,
	        "Reading %ldk bytes from file %d.%d '%s' (from %ldk to %ldk)",
	        (long)( io_size / 1024 ), cfg->c_cur_dev + 1,
	        cfg->c_cur_adev + 1, cur_dev->d_name,
	        (long)( cfg->c_pos / 1024L ),
	        (long)(( cfg->c_pos + io_size - 1 ) / 1024L));
        ior_verbose( cfg, msg_buf );
    }

    					/* do the read */
    ior_time_usec( cfg, &start_sec, &start_usec );
#if IOR_USE_PREAD_PWRITE
    {
        off_t file_off = (off_t)( cfg->c_pos + cur_dev->d_offset );
        bytes_read = pread( cur_dev->d_fid, cfg->c_read_buf, io_size, file_off );
    }
#else
    bytes_read = read( cur_dev->d_fid, cfg->c_read_buf, io_size );
#endif
    ior_time_usec( cfg, &end_sec, &end_usec );
					/* check for short read to tollerate */
    if (( bytes_read != io_size ) && ( cfg->c_tollerate_short_reads )) {
	tollerate = io_size > 8192 ? io_size / 10 : 100;
	if ( bytes_read > io_size - tollerate ) {
	    ior_verbose( cfg, "Bytes read was short, but tollerable" );
	    bytes_read = io_size;
	};
    };
    if ( bytes_read != io_size ) {	/* something is broken */
	result = -2;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"Read of %ldk bytes to file %d %s'%s' returned %ld",
		(long)( io_size / 1024L ), cfg->c_cur_dev + 1, msg,
		cur_dev->d_name, (long)( bytes_read ));
	ior_error( cfg, msg_buf );
    };

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    cfg->c_read_time_msecs += resp_time;

    if ( cfg->c_shared_stats ) {
        long total_usec = (end_sec - start_sec) * 1000000 + (end_usec - start_usec);
        cfg->c_shared_stats[cfg->c_my_index].reads++;
        cfg->c_shared_stats[cfg->c_my_index].bytes_read += bytes_read;
        cfg->c_shared_stats[cfg->c_my_index].read_usec += total_usec;
    }

    if ( io_resp != NULL ) {
	*io_resp = resp_time;
    };

#ifdef	IOR_ENGINEERING
    ior_eng_read( cfg, io_size, bytes_read, resp_time );
#endif

    if ( result != 0 ) { /* we had an error */
	cfg->c_pos = -1; /* force seek for next I/O */
	cfg->c_errors++; /* note that we had an error */
    } else {
	cfg->c_pos += io_size; /* update our position */
    };

    return( result );
}

/*
 * ior_write - do write to the target device
 */
static void ior_fill_compressible_buf( ior_config *cfg, BYTE *buf, long io_size, HUGE file_off )
{
    long off;
    int i;
    int chunk_size = 4 * 1024;
    double ratio_adj = cfg->c_compressible_ratio * 1.09;

    for ( off = 0; off < io_size; off += chunk_size ) {
        int cur_chunk = (int) (( io_size - off < chunk_size ) ? ( io_size - off ) : chunk_size);
        HUGE chunk_index = (HUGE) (( file_off + (HUGE) off ) / chunk_size);
        BYTE fill_ch = (BYTE) ( 1 + ( (int) ( chunk_index % 255 ) ) );
        int base_len = (int) ( cur_chunk / ratio_adj );
        unsigned int seed = (unsigned int) ( chunk_index ^ ( chunk_index >> 32 ) ^ 0xA5A5A5A5u );
        if ( seed == 0 ) seed = 1u;
        if ( base_len < 1 ) base_len = 1;

        /* Write 4 bytes at a time from 32-bit PRNG (4x fewer iterations) */
        int base_aligned = base_len & ~3;
        for ( i = 0; i < base_aligned; i += 4 ) {
            seed ^= seed << 13;
            seed ^= seed >> 17;
            seed ^= seed << 5;
            memcpy( buf + off + i, &seed, 4 );
        }
        for ( ; i < base_len; i++ ) {
            seed ^= seed << 13;
            seed ^= seed >> 17;
            seed ^= seed << 5;
            buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
        }
        /* Use SIMD-optimized memset for compressible fill portion */
        memset( buf + off + base_len, fill_ch, cur_chunk - base_len );
    }
}

/*
 * ior_fill_dedup_buf - fill a write buffer with dedupable data
 *
 * Divides the I/O into dedup_block_size chunks.  For a dedup ratio of X:1,
 * every X consecutive dedup blocks share the same content (determined by a
 * unique_id derived from the absolute block index).  The unique_id is simply
 * abs_block / dedup_ratio, so each group of X blocks shares the same seed
 * and thus identical byte content.  Different groups get different seeds.
 *
 * When compressible_ratio is also > 1.0, each unique block is filled with a
 * compressible pattern (partial random + repeating fill byte) so the data is
 * simultaneously dedupable AND compressible.
 */

static void ior_fill_dedup_buf( ior_config *cfg, BYTE *buf, long io_size, HUGE file_off )
{
    long dedup_bs = cfg->c_dedup_block_size;
    long off;
    int  i;
    int  do_compress = ( cfg->c_compressible_ratio > 1.0 );
    double ratio_adj = do_compress ? ( cfg->c_compressible_ratio * 1.09 ) : 0.0;

    for ( off = 0; off < io_size; off += dedup_bs ) {
        long cur_chunk = (long) (( io_size - off < dedup_bs ) ? ( io_size - off ) : dedup_bs);
        HUGE abs_block = (HUGE) (( file_off + (HUGE) off ) / dedup_bs);

        /* Map groups of dedup_ratio consecutive blocks to the same unique_id */
        HUGE unique_id = abs_block / (HUGE) cfg->c_dedup_ratio;

        /*
         * Embed the 8-byte unique_id as the first bytes of each block.
         * This guarantees blocks with different unique_ids are never
         * byte-identical, even at 96TB (25B+ blocks, 6B+ unique groups)
         * where a 32-bit PRNG seed would collide.
         */
        int hdr_len = 8;
        if ( hdr_len > cur_chunk ) hdr_len = (int) cur_chunk;
        memcpy( buf + off, &unique_id, hdr_len );

        /* Deterministic PRNG seed from unique_id for remaining bytes */
        unsigned int seed = (unsigned int) ( (unsigned long) unique_id * 2654435761u + 0x12345678u );
        seed ^= (unsigned int) ( unique_id >> 32 );
        if ( seed == 0 ) seed = 1u;

        if ( do_compress ) {
            /* Compressible + dedupable: random portion after header, then fill */
            int base_len = (int) ( cur_chunk / ratio_adj );
            BYTE fill_ch = (BYTE) ( 1 + ( (int) ( unique_id % 255 ) ) );
            if ( base_len < hdr_len + 1 ) base_len = hdr_len + 1;
            /* Write 4 bytes at a time from 32-bit PRNG (4x fewer iterations) */
            int base_aligned = hdr_len + (( base_len - hdr_len ) & ~3);
            for ( i = hdr_len; i < base_aligned; i += 4 ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                memcpy( buf + off + i, &seed, 4 );
            }
            for ( ; i < base_len; i++ ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
            }
            /* Use SIMD-optimized memset for compressible fill portion */
            memset( buf + off + base_len, fill_ch, cur_chunk - base_len );
        } else {
            /* Dedup only: PRNG fill after header, 4 bytes at a time */
            int end_aligned = hdr_len + (( (int) cur_chunk - hdr_len ) & ~3);
            for ( i = hdr_len; i < end_aligned; i += 4 ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                memcpy( buf + off + i, &seed, 4 );
            }
            for ( ; i < (int) cur_chunk; i++ ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
            }
        }
    }
}

int	ior_write( ior_config *cfg, long io_size, double *io_resp )
/* ior_config	*cfg; our configuration */
/* long		io_size; size of this write */
/* double	*io_resp; response time seen */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    long	bytes_written; /* size written */
    BYTE	*write_buf; /* selected write buffer */
    long	start_sec; /* starting seconds */
    long	start_usec; /* starting micro seconds */
    long	end_sec; /* ending seconds */
    long	end_usec; /* ending micro seconds */
    double	resp_time; /* overall response time */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    write_buf = cfg->c_write_buf;
    if ( ( cfg->c_compressible_ratio > 1.0 || cfg->c_dedup_ratio > 1.0 )
            && cfg->c_cur_pat >= 0
            && cfg->c_cur_pat < IOR_MAX_PATTERNS + 2
            && cfg->c_write_bufs[ cfg->c_cur_pat ] != NULL ) {
        write_buf = cfg->c_write_bufs[ cfg->c_cur_pat ];
    }

    /* Fill write buffer: dedup takes priority (handles compression internally) */
    if ( cfg->c_dedup_ratio > 1.0 ) {
        HUGE file_off = (HUGE) ( cfg->c_pos + cur_dev->d_offset );
        ior_fill_dedup_buf( cfg, write_buf, io_size, file_off );
    } else if ( cfg->c_compressible_ratio > 1.0 ) {
        HUGE file_off = (HUGE) ( cfg->c_pos + cur_dev->d_offset );
        ior_fill_compressible_buf( cfg, write_buf, io_size, file_off );
    }

    if ( cfg->c_verbose ) {
        sprintf( msg_buf,
	        "Writing %ldk bytes to file %d.%d '%s' (from %ldk to %ldk)",
	        (long)( io_size / 1024 ), cfg->c_cur_dev + 1,
	        cfg->c_cur_adev + 1, cur_dev->d_name,
	        (long)( cfg->c_pos / 1024L ),
	        (long)(( cfg->c_pos + io_size ) / 1024L));
        ior_verbose( cfg, msg_buf );
    }

    					/* do the write */
    ior_time_usec( cfg, &start_sec, &start_usec );
#if IOR_USE_PREAD_PWRITE
    {
        off_t file_off = (off_t)( cfg->c_pos + cur_dev->d_offset );
        bytes_written = pwrite( cur_dev->d_fid, write_buf, io_size, file_off );
    }
#else
    bytes_written = write( cur_dev->d_fid, write_buf, io_size );
#endif
    ior_time_usec( cfg, &end_sec, &end_usec );
    if ( bytes_written != io_size ) {	/* something is broken */
	result = -2;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"Write of %ldk bytes to file %d %s'%s' returned %ld",
		(long)( io_size / 1024L ), cfg->c_cur_dev + 1, msg,
		cur_dev->d_name, (long)( bytes_written ));
	ior_error( cfg, msg_buf );
    };

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    cfg->c_write_time_msecs += resp_time;

    if ( cfg->c_shared_stats ) {
        long total_usec = (end_sec - start_sec) * 1000000 + (end_usec - start_usec);
        cfg->c_shared_stats[cfg->c_my_index].writes++;
        cfg->c_shared_stats[cfg->c_my_index].bytes_written += bytes_written;
        cfg->c_shared_stats[cfg->c_my_index].write_usec += total_usec;
    }

    if ( io_resp != NULL ) {
	*io_resp = resp_time;
    };

#ifdef	IOR_ENGINEERING
    ior_eng_write( cfg, io_size, bytes_written, resp_time );
#endif

    if ( result != 0 ) {		/* we had an error */
	cfg->c_pos = -1;		/* force seek for next I/O */
	cfg->c_errors++;		/* note that we had an error */
    } else {
	cfg->c_pos += io_size;		/* update our position */
    };

    return( result );
}

/*
 * ior_seek - seek to a new position in the target file
 */
int	ior_seek( ior_config *cfg, HUGE pos )
/* ior_config	*cfg; our configuration */
/* HUGE		pos; position to seek to */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    HUGE	target; /* pos we wanted to go to */
    HUGE	new_pos; /* pos we seeked to */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    target = pos + cur_dev->d_offset;

#if IOR_USE_PREAD_PWRITE
    /*
     * When using pread/pwrite, we do not need to move the shared file position
     * for normal test I/O. Keep the real seek for the capacity check.
     */
    if ( pos != cur_dev->d_capacity ) {
        cfg->c_pos = pos;
        return( 0 );
    }
#endif


    sprintf( msg_buf, "ior_seek: Seeking from %ldk to %ldk in file %d.%d '%s'",
	    (long)(( cfg->c_pos + cur_dev->d_offset )/ 1024L ),
	    (long)( target / 1024L ), cfg->c_cur_dev + 1,
	    cfg->c_cur_adev + 1, cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

					/* do the seek */
    new_pos = IOR_SEEK( cur_dev->d_fid,
		    target, IOR_SEEK_SET );
    /* NOTE: checking for real position is broken with llseek on Sun, */
    /*       and always returns small (positive) values for good.     */
    /*       Since this is only true for SPARC Solaris, we skip that. */
    if ( new_pos < 0 ) {		/* OOPS - something is broken */
	result = -1;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf, "Seek from %ldk to %ldk in file %d %s'%s' FAILED",
		(long)( cfg->c_pos / 1024L ), (long)( pos / 1024L ),
		cfg->c_cur_dev + 1, msg, cur_dev->d_name);
	ior_error( cfg, msg_buf );

		    /** Some platforms don't give good data from llseek **/
#if	!defined(SOLARIS_SPARC) && !defined(HPUX)

		    /** debug code courtesy of Don Fike -
			make sure we succeeded at our seek **/
    } else if ( new_pos < target ) {
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"ior_seek: Seek new position %ldk < Seek set position %ldk in file %d %s'%s'",
		(long)( new_pos / 1024L ),
		(long)( target / 1024L ),
		cfg->c_cur_dev + 1, msg, cur_dev->d_name );
	ior_warn( cfg, msg_buf );
#endif
    };

    if ( result != 0 ) {		/* we had an error */
	cfg->c_pos = -1;		/* force seek for next I/O */
	cfg->c_errors++;		/* note that we had an error */
    } else {
	cfg->c_pos = pos;		/* update our position */
    };

    return( result );
}

#define	IOR_LOCK_READ		F_RDLCK
#define	IOR_LOCK_WRITE		F_WRLCK
#define	IOR_LOCK_REMOVE		F_UNLCK

/*
 * ior_dev_lock - lock the target device if set
 */
int	ior_dev_lock( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; target device to check/lock */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

#if	defined(IOR_LARGE_FILES) && defined(HPUX)
    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( cur_dev->d_lock ) {
	    ior_warn( cfg, "ior_dev_lock: large file locks not available on HP-UX (ignored)");
    };	

#else
    ior_flock_t d_lock;		/* lock command to run */

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( !cur_dev->d_lock ) {
	sprintf( msg_buf, "No locking for file %d '%s'",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_verbose( cfg, msg_buf );

	return( result );
    };

    if ( cur_dev->d_fid < 0 ) {		/* not open? */
	sprintf( msg_buf, "Attempt to lock file %d '%s' - not open",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_error( cfg, msg_buf );

	return( -1 );
    };
					/* configure the lock to set */
    d_lock.l_type = cur_dev->d_read_only ? IOR_LOCK_READ : IOR_LOCK_WRITE;
    d_lock.l_start = cur_dev->d_offset;	/* use device offset */
    d_lock.l_len = cur_dev->d_capacity;	/* -- and capacity */
    d_lock.l_whence = IOR_SEEK_SET;

    result = fcntl( cur_dev->d_fid, IOR_SET_LOCK_FLAG, &d_lock );

    if ( result != 0 ) {		/* we had an error */
	perror( cur_dev->d_name );
	sprintf( msg_buf, "Lock of file %d '%s' from %ldk to %ldk FAILED",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_error( cfg, msg_buf );
    } else {
	sprintf( msg_buf, "Locked file %d '%s' from %ldk to %ldk",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_verbose( cfg, msg_buf );
    };
#endif

    return( result );
}


/*
 * ior_dev_unlock - unlock the target device if set
 */
int	ior_dev_unlock( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; target device to check/unlock */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

#if	defined(IOR_LARGE_FILES) && defined(HPUX)
    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( cur_dev->d_lock ) {
	    ior_warn( cfg, "ior_dev_unlock: large file locks not available on HP-UX (ignored)");
    };	

#else
    ior_flock_t d_lock;		/* lock command to run */

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( !cur_dev->d_lock ) {
	sprintf( msg_buf, "No locking for file %d '%s'",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_verbose( cfg, msg_buf );

	return( result );
    };

    if ( cur_dev->d_fid < 0 ) {		/* not open? */
	sprintf( msg_buf, "Attempt to unlock file %d '%s' - not open",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_error( cfg, msg_buf );

	return( -1 );
    };

    d_lock.l_type = IOR_LOCK_REMOVE;	/* configure the lock to set */
    d_lock.l_start = cur_dev->d_offset;	/* use device offset */
    d_lock.l_len = cur_dev->d_capacity;	/* -- and capacity */
    d_lock.l_whence = IOR_SEEK_SET;

    result = fcntl( cur_dev->d_fid, IOR_SET_LOCK_FLAG, &d_lock );

    if ( result != 0 ) {		/* we had an error */
	perror( cur_dev->d_name );
	sprintf( msg_buf, "Unlock of file %d '%s' from %ldk to %ldk FAILED",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_error( cfg, msg_buf );
    } else {
	sprintf( msg_buf, "Unlocked file %d '%s' from %ldk to %ldk",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_verbose( cfg, msg_buf );
    };
#endif

    return( result );
}

/*
 * ior_get_capacity - find capacity for an open device
 */
int	ior_get_capacity( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; which device to check */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    HUGE	pos; /* current test position */
    HUGE	incr; /* next increment to try */
    HUGE	seek_status; /* did we seek OK? */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    sprintf( msg_buf, "Determining size of file %ld '%s'", dev + 1,
	    cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

    if ( cur_dev->d_fid > -1 ) {	/* are we ready? */
	ior_error( cfg, "File not open in 'ior_get_capacity'" );
	return( -1 );
    };

    pos = 0;				/* start at beginning */
					/* try half the maximum size */
    incr = ( IOR_MAX_SEEK / ( 2 * IOR_BLOCK_SIZE )) * IOR_BLOCK_SIZE;
    while ( incr > IOR_BLOCK_SIZE ) {
	seek_status = IOR_SEEK( cur_dev->d_fid, pos + incr, IOR_SEEK_SET );
	if ( seek_status == pos + incr ) {
	    pos += incr;
	};
	incr /= 2;			/* half this seek for next time */
    };

    if ( pos < 0 ) {		/*  - or WRAP */
	pos = IOR_MAX_SEEK;
    };
					/* record the capacity */
    cur_dev->d_capacity = pos - cur_dev->d_offset;

    cfg->c_pos = -1;			/* force seek for next I/O */

    return( result );
}

/*
 * ior_rand - generate a nice, large random number
 */
HUGE	ior_rand( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    HUGE	result; /* final return code */

    result = RAND();

    return( result );
}

/*
 * ior_random_seed - set up the random number generator with the given seed
 */
int	ior_random_seed( ior_config *cfg, long seed )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

    sprintf( msg_buf, "ior_random_seed: setting seed to %ld", seed );
    ior_debug( cfg, msg_buf );

    SEED( seed );			/* fix random generation */

    return( result );
}

/*
 * ior_randomize - set up the random number generator
 */
int	ior_randomize( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */
    long	seed; /* seed to use */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0; /* all OK so far */

    seed = ior_get_time( cfg );		/* get time as seed */

    seed += getpid();			/* add process ID */

    ior_random_seed( cfg, seed );	/* fix random generation */

    ior_debug( cfg, "ior_randomize: random number generation randomized" );

    return( result );
}

/*
 * ior_get_time - get current time in seconds
 */
long	ior_get_time(ior_config *cfg)
/* ior_config	*cfg; our configuration */
{
    long	result; /* final return code */

    struct timeval tp;

    if ( gettimeofday( &tp, 0 ) == -1 ) {
	result = -1;
    } else {
	result = tp.tv_sec;
    };

    return( result );
}

/*
 * ior_date_string - convert seconds to a date string
 */
int	ior_date_string( ior_config *cfg, ior_clock clk, char *str )
/* ior_config	*cfg; our configuration */
/* ior_clock	clk; clock for the date */
/* char		*str; string for our date */
{
    int	result; /* final return code */
    struct tm *local_time; /* dissected local time */

    result = 0; /* all OK so far */

    local_time = (struct tm *) localtime((time_t *)( &clk )); /* get time details */
    strftime( str, 26, "%a %b %d %Y %H:%M:%S", local_time );
    str[ 24 ] = '\0';

    return( result );
}

/*
 * ior_sleep - rough sleep in seconds
 */
int	ior_sleep( ior_config *cfg, int sec )
/* ior_config	*cfg; our configuration */
/* int		sec; how long to sleep */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

    sleep( sec );			/* sleep for requested time */

    return( result );
}

#ifdef	USE_LOCK_CODE
static BYTE	ior_have_locked = 0;
#endif

/*
 * ior_set_lock - lock for file access
 */
int	ior_set_lock( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

	/* Using these advisory UNIX file locks was a fine idea, but it	*/
	/* doesn't work out in the real world.  By using these locks to	*/
	/* control output to the performance file, we wound up with a	*/
	/* number of the testing processes hanging after completion,	*/
	/* with no performance data written.  To ensure that this	*/
	/* problem does not spread, these locks are being disabled	*/
	/* here.							*/
	/* This was seen on Solaris, AIX, and HP-UX systems.  Testing	*/
	/* on other platforms did not report the problem, but were not	*/
	/* used as often and may simply have not come across it.  The	*/
	/* problem appears more often as the device count increases.	*/

#ifdef	USE_LOCK_CODE
    if ( !cfg->c_is_active ) {		/* not active - no leed to lock */
	return( 0 );
    };

    if ( ior_have_locked ) {		/* process already has a lock! */
	return( -1 );
    };
					/* get exclusive file lock */
    result = lockf( fileno( cfg->c_log_file ), F_LOCK, 64L );

    if ( result == 0 ) {
	ior_have_locked = 1;		/* lock set */
    } else {				/* if not, there isn't much we can do */
	perror( cfg->c_log_name );
	ior_error( cfg, "LOCK failed to set" );
    };
#endif

    return( result );
}

/*
 * ior_clear_lock - lock for file access
 */
int	ior_clear_lock( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

	/* See above note on use of file locking code. */

#ifdef	USE_LOCK_CODE
    if ( !cfg->c_is_active ) {		/* not active - no leed to unlock */
	return( 0 );
    };

    if ( !ior_have_locked ) {		/* process doesn't have a lock! */
	return( -1 );
    };
					/* release exclusive file lock */
    result = lockf( fileno( cfg->c_log_file ), F_ULOCK, 64L );

    if ( result == 0 ) {
	ior_have_locked = 0;		/* lock released */
    } else {				/* if not, there isn't much we can do */
	perror( cfg->c_log_name );
	ior_error( cfg, "LOCK failed to release" );
    };
#endif

    return( result );
}

/*
 * ior_time_usec - get the time to a very fine level
 */
int	ior_time_usec( ior_config *cfg, long *sec, long *usec )
/* ior_config	*cfg; our configuration */
/* long		*sec; pointer to time in sec */
/* long		*usec; pointer to time in usec */
{
    int	result; /* final return code */
    struct timeval tp;			/* time pointer */

    result = 0; /* all OK so far */

					/* get the current time */
    if ( gettimeofday( &tp, (struct timezone *) NULL ) < 0 ) {
	result = -1;
	*sec = 0;
	*usec = 0;
    } else {
	*sec = tp.tv_sec;		/* recored the time */
	*usec = tp.tv_usec;
    };

    return( result );
}

/*
 * ior_sleep_usec - go to sleep to a very fine level
 */
int	ior_sleep_usec( ior_config *cfg, long usec )
/* ior_config	*cfg; our configuration */
/* long   		usec;			 time to sleep in usec */
{
    long   	sec;			/* sleep time in seconds */
    int		result;			/* final return code */

    struct timeval selectTimeout;	/* actual time to sleep */

    result = 0;				/* all OK so far */

    sec = usec / 1000000;
    usec = usec % 1000000;

    selectTimeout.tv_sec = sec;
    selectTimeout.tv_usec = usec;

    result = select(0, NULL, NULL, NULL, &selectTimeout);

    if ( result < 0 && errno == EINTR ) {
	result = 0;
    }

    return( result );
}