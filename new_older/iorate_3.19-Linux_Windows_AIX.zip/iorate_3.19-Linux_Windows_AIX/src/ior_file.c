/**************************************************************************
 *
 *  ior_file.c - the IORATE command file handling routines
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_file.c,v 3.6 2011/06/24 08:44:01 westiv Exp westiv $";


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iorate.h"

/*
 * ior_read_devs - read devices file
 */
int	ior_read_devs( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */

    result = ior_parse_prep( cfg, cfg->c_dev_name );

    if ( result == 0 ) {
	result = yyparse();
    };

    return( result );
}

/*
 * ior_read_pats - read patterns file
 */
int	ior_read_pats( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */

    result = ior_parse_prep( cfg, cfg->c_pat_name );

    if ( result == 0 ) {
	result = yyparse();
    };

    return( result );
}

/*
 * ior_read_tests - read tests file
 */
int	ior_read_tests( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */

    result = ior_parse_prep( cfg, cfg->c_test_name );

    if ( result == 0 ) {
	result = yyparse();
    };

    return( result );
}

/*
 * ior_read_iops - read target iops file
 */
int	ior_read_iops( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    if ( cfg->c_iops_name
	    && cfg->c_iops_name[ 0 ] != '\0' ) { /* only if not NULL */

	result = ior_parse_prep( cfg, cfg->c_iops_name );

	if ( result == 0 ) {

	    result = yyparse();
	};
    } else {
	ior_debug( cfg, "ior_read_iops: no IOPS file specified, skipping..." );
    };

    return( result );
}

/*
 * ior_log_devs - writes devices file info to the log
 */
int	ior_log_devs( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		dev;			/* the dev we are in */
    ior_device	*cur_dev;		/* direct reference to our dev */
    char	tmp_buf[ 80 ];		/* small string buffer */

    result = 0;				/* all OK so far */

    sprintf( msg_buf,
	    "\n- - - - - - Log of Devices Data from '%s'- - - - - -\n",
	    cfg->c_dev_name );
    ior_log( cfg, msg_buf );

    for ( dev = 0; dev < cfg->c_ndev; dev++ ) {

	cur_dev = &( cfg->c_devs[ dev ]);

	if ( cur_dev->d_valid ) {
	    sprintf( msg_buf, "Device %d = \"%s\"  offset %s",
		    dev + 1, cur_dev->d_name,
		    ior_size_to_ascii( cfg, cur_dev->d_offset ));
	    if ( cur_dev->d_count > 1 ) {
		sprintf( tmp_buf, " count %d", cur_dev->d_count );
		strcat( msg_buf, tmp_buf );
	    };
	    sprintf( tmp_buf, " capacity %s ",
		    ior_size_to_ascii( cfg, cur_dev->d_capacity ));
	    strcat( msg_buf, tmp_buf );
	    sprintf( tmp_buf, " block size %s%s%s%s%s%s ;",
		    ior_size_to_ascii( cfg, (HUGE) cur_dev->d_block_size ),
		    cur_dev->d_is_temp ? "  temp" : "",
		    cur_dev->d_create ? "  create" : "",
		    cur_dev->d_is_async ? "  async" : "",
		    cur_dev->d_read_only ? "  read only" : "",
		    cur_dev->d_lock ? "  lock" : "" );
	    strcat( msg_buf, tmp_buf );
	    ior_log( cfg, msg_buf );
	} else {
	    sprintf( msg_buf,
		    "\t\t# device %d is not valid", dev + 1 );
	    ior_log( cfg, msg_buf );
	};
    };

    sprintf( msg_buf,
	    "\n- - - - - - End of Devices Data - - - - - -\n" );
    ior_log( cfg, msg_buf );

    return( result );
}

/*
 * ior_log_pats - write patterns file data to the log
 */
int	ior_log_pats( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		pat;			/* the pattern we are in */
    char	suffix[ 100 ];		/* space for pattern targeting */
    ior_pattern	*cur_pat;		/* direct reference to our pattern */

    result = 0;				/* all OK so far */

    sprintf( msg_buf,
	    "\n- - - - - - Log of Pattern Data from '%s'- - - - - -\n",
	    cfg->c_pat_name );
    ior_log( cfg, msg_buf );

    for ( pat = 0; pat < cfg->c_npat; pat++ ) {

	cur_pat = &( cfg->c_pats[ pat ]);

	if ( cur_pat->p_valid ) {
	    sprintf( msg_buf,
		    "Pattern %d = \"%s\"  io size %s  read %.0f%%  %s",
		    pat + 1, cur_pat->p_name,
		    ior_size_to_ascii( cfg, (HUGE) cur_pat->p_io_size ),
		    cur_pat->p_read_pct,
		    cur_pat->p_is_seq ? "sequential" : "random");

				/* note any limit on sequential reads */
	    if (( cur_pat->p_is_seq ) && ( cur_pat->p_max_seq > 0 )) {
		sprintf( suffix, "  max seq %d",
			(int)( cur_pat->p_max_seq ));
		strcat( msg_buf, suffix );
	    };
	    ior_log( cfg, msg_buf );

			    /* now we add any pattern sizing information */
	    if ( cur_pat->p_start_pct > 0 ) {
		sprintf( msg_buf, "\tfrom %.3f%%", cur_pat->p_start_pct );
	    } else if ( cur_pat->p_start >= 0 ) {
		sprintf( msg_buf, "\tfrom %s",
			ior_size_to_ascii( cfg, cur_pat->p_start ));
	    } else {
		strcpy( msg_buf, "\t" );	/* clear the buffer */
	    };

	    if (( cur_pat->p_size_pct > 0 ) &&
		    ( cur_pat->p_size_pct < 99.999 )) {
		sprintf( suffix, " size %.3f%%", cur_pat->p_size_pct );
		strcat( msg_buf, suffix );
	    } else if ( cur_pat->p_size > 0 ) {
		sprintf( suffix, " size %s",
			ior_size_to_ascii( cfg, cur_pat->p_size ));
		strcat( msg_buf, suffix );
	    };

			/* now we add any pattern locality information */
	    if ( cur_pat->p_local_pct > 0 ) {
		sprintf( suffix, "\tzone %.3f%%", cur_pat->p_local_pct );
		strcat( msg_buf, suffix );
	    } else if ( cur_pat->p_local_size > 0 ) {
		sprintf( suffix, "\tzone %s",
			ior_size_to_ascii( cfg, cur_pat->p_local_size ));
		strcat( msg_buf, suffix );
	    };
	    if ( cur_pat->p_local_count >= 0 ) {
		sprintf( suffix, " count %ld", (long)( cur_pat->p_local_count ));
		strcat( msg_buf, suffix );
	    };			/* these limits are HUGE */
	    if ( cur_pat->p_local_limit >= 0 ) {
#ifdef	IOR_LARGE_FILES
		sprintf( suffix, " limit %llu", (long long unsigned)( cur_pat->p_local_limit ));
#else
		sprintf( suffix, " limit %lu", (long unsigned)( cur_pat->p_local_limit ));
#endif
		strcat( msg_buf, suffix );
	    };

	    if ( cur_pat->p_reuse_pct > 0 ) {
		sprintf( suffix, "\treuse %.3f%%", cur_pat->p_reuse_pct );
		strcat( msg_buf, suffix );
	    };

	    if ( cur_pat->p_history >= 0 ) {
		sprintf( suffix, " history %ld", cur_pat->p_history );
		strcat( msg_buf, suffix );
	    };

	    strcat( msg_buf, " ;" );
	    ior_log( cfg, msg_buf );

	} else {
	    sprintf( msg_buf,
		    "\t\t# pattern %d is not valid", pat + 1 );
	    ior_log( cfg, msg_buf );
	};
    };

    sprintf( msg_buf,
	    "\n- - - - - - End of Pattern Data - - - - - -\n" );
    ior_log( cfg, msg_buf );

    return( result );
}

/*
 * ior_log_tests - write tests file data to the log
 */
int	ior_log_tests( ior_config *cfg )
/* ior_config	*cfg;			our configuration */
{
    int		result;			/* final return code */
    int		test;			/* the test we are in */
    ior_test	*cur_test;		/* direct reference to our test */
    int		pat;			/* test pattern being examined */
    char	tmp_buf[ 80 ];		/* temporary text buffer */

    result = 0;				/* all OK so far */

    sprintf( msg_buf,
	    "\n- - - - - - Log of Tests Data from '%s'- - - - - -\n",
	    cfg->c_test_name );
    ior_log( cfg, msg_buf );

    for ( test = 0; test < cfg->c_ntest; test++ ) {

	cur_test = &( cfg->c_tests[ test ]);

	if ( cur_test->t_valid ) {
	    sprintf( msg_buf, "Test %d = \"%s\"",
		    test + 1, cur_test->t_name );
	    if ( cur_test->t_pause > 0 ) {
		sprintf( tmp_buf, " pause %s",
			ior_time_to_ascii( cfg, cur_test->t_pause ));
		strcat( msg_buf, tmp_buf );
	    };

	    sprintf( tmp_buf, " for %s",
		    ior_time_to_ascii( cfg, cur_test->t_duration ));
	    strcat( msg_buf, tmp_buf );

	    if ( cur_test->t_ignore > 0 ) {
		sprintf( tmp_buf, " ignore %s",
			ior_time_to_ascii( cfg, cur_test->t_ignore ));
		strcat( msg_buf, tmp_buf );
	    };
	    ior_log( cfg, msg_buf );

	    sprintf( msg_buf, "\t%d iops", (int) cur_test->t_iops);
	    if ( cur_test->t_start_pct >= 0 ) {
		sprintf( tmp_buf, " from %.3f%%", cur_test->t_start_pct );
		strcat( msg_buf, tmp_buf );
	    } else if ( cur_test->t_start > 0 ) {
		sprintf( tmp_buf, " from %s",
			ior_size_to_ascii( cfg, cur_test->t_start ));
		strcat( msg_buf, tmp_buf );
	    };
	    if ( cur_test->t_size_pct >= 0 ) {
		sprintf( tmp_buf, " size %.3f%%", cur_test->t_size_pct );
		strcat( msg_buf, tmp_buf );
	    } else if ( cur_test->t_size > 0 ) {
		sprintf( tmp_buf, " size %s",
			ior_size_to_ascii( cfg, (HUGE) cur_test->t_size ));
		strcat( msg_buf, tmp_buf );
	    };
	    ior_log( cfg, msg_buf );

	    if ( cur_test->t_skew >= IOR_SKEW_MIN ) {
		sprintf( msg_buf, "\tskew %d%%\t area %s\tcorrelate %d%%\tseed %ld\tshift %d%%",
			cur_test->t_skew,
			ior_size_to_ascii( cfg, (HUGE) cur_test->t_area ),
			cur_test->t_correlate, cur_test->t_seed,
			cur_test->t_shift );
		ior_log( cfg, msg_buf );
	    };

	    strcpy( msg_buf, "\t" );		/* empty the message string */
	    for ( pat = 0; pat < cfg->c_npat; pat++ ) {
		if ( cfg->c_pats[ pat ].p_valid &&
			( cur_test->t_pat_pct[ pat ] > 0 )) {
		    sprintf( tmp_buf, "%d%% pat %d, ", 
			cur_test->t_pat_pct[ pat ], pat + 1 );
		    strcat( msg_buf, tmp_buf );
		};
	    };
	    strcat( msg_buf, ";" );
	    ior_log( cfg, msg_buf );
	} else {
	    sprintf( msg_buf,
		    "\t\t# test %d is not valid", test + 1 );
	    ior_log( cfg, msg_buf );
	};
    };

    sprintf( msg_buf,
	    "\n- - - - - - End of Tests Data - - - - - -\n" );
    ior_log( cfg, msg_buf );

    return( result );
}

/* for sizing printout, step up by 1KB increments and alter the name */
#define IOR_SIZE_STEP			1024
#define	IOR_MAX_SIZE_STEPS		5
static char ior_size_names[ IOR_MAX_SIZE_STEPS + 2 ][ 12 ] = {
    "B", "KB", "MB", "GB", "TB", "PB", "BAD SIZE"
};

/*
 * ior_size_to_ascii - convert a size to an ASCII string
 *
 * Returns pointer to a static string
 */
char	*ior_size_to_ascii( ior_config *cfg, HUGE c_size )
/* ior_config	*cfg;			our configuration */
/* HUGE		c_size;			the size to print */
{
    static char	result[ 256 ];		/* string to return */
    int		size_steps;		/* number of steps we have done */
    char	tmp_buf[ 1024 ];	/* debug buffer */

    result[ 0 ] = '\0';			/* NULL out our string */
    size_steps = 0;			/* no steps done yet */

#ifdef	IOR_LARGE_FILES
    sprintf( tmp_buf, "ior_size_to_ascii: %lld bytes is '", (long long) c_size );
#else
    sprintf( tmp_buf, "ior_size_to_ascii: %ld bytes is '", (long) c_size );
#endif

					/* while steps left and valid */
    while (( size_steps < IOR_MAX_SIZE_STEPS ) &&
	    ( c_size >= IOR_SIZE_STEP ) &&
	    ( c_size % IOR_SIZE_STEP == 0 )) {
	c_size /= IOR_SIZE_STEP;
	size_steps++;
    };
					/* use float if too large */
    if (( size_steps < IOR_MAX_SIZE_STEPS ) &&
	    ( c_size > IOR_SIZE_STEP )) {
	sprintf( result, "%.2f%s",
		(float)( c_size / (float) IOR_SIZE_STEP ),
		ior_size_names[ size_steps + 1 ]);
    } else {
	sprintf( result, "%ld%s", (long) c_size, ior_size_names[ size_steps ]);
    };

    strcat( tmp_buf, result );		/* note our result */
    strcat( tmp_buf, "'" );
    ior_debug_l( cfg, IOR_DEBUG_ALL, tmp_buf ); /* log size debugging */

    return( result );
}

/* for time printout, step up from sec to min to hour */
#define IOR_TIME_STEP			60
#define	IOR_MAX_TIME_STEPS		2
static char ior_time_names[ IOR_MAX_TIME_STEPS + 2 ][ 12 ] = {
    "sec", "min", "hour", "BAD TIME"
};

/*
 * ior_time_to_ascii - convert a time (sec) to an ASCII string
 *
 * Returns pointer to a static string
 */
char	*ior_time_to_ascii( ior_config *cfg, long t_time )
/* ior_config	*cfg;			 our configuration */
/* long		t_time;			 the time to print */
{
    static char	result[ 128 ];		/* string to return */
    int		time_steps;		/* number of steps we have done */
    char	tmp_buf[ 80 ];		/* debug buffer */

    result[ 0 ] = '\0';			/* NULL out our string */
    time_steps = 0;			/* no steps done yet */

    sprintf( tmp_buf, "ior_time_to_ascii: %ld sec is '", t_time );

					/* while steps left and valid */
    while (( time_steps < IOR_MAX_TIME_STEPS ) &&
	    ( t_time >= IOR_TIME_STEP ) &&
	    ( t_time % IOR_TIME_STEP == 0 )) {
	t_time /= IOR_TIME_STEP;
	time_steps++;
    };

    sprintf( result, "%ld %s", t_time, ior_time_names[ time_steps ]);

    strcat( tmp_buf, result );		/* note our result */
    strcat( tmp_buf, "'" );
    ior_debug( cfg, tmp_buf );		/* log time if debugging */

    return( result );
}

