/**************************************************************************
 *
 *  ior_mach.h - Machine specific information for IORATE
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

/*
 * $Header: /home/westiv/iorate/RCS/ior_mach.h,v 3.3 2011/11/03 15:49:44 westiv Exp westiv $
 */

/*
 *  Defines for machine specific stuff
 *
 *  Once we are sure of the OS, we define anything special for large files
 *  access and such.
 */

#ifndef	IOR_MACH_INCLUDE
#define	IOR_MACH_INCLUDE

#define	IOR_BLOCK_SIZE		(512L)
#define	IOR_MIN_POS		(8*1024L)

#define	BYTE			unsigned char

/*
 * If there is no long long support, forget large files
 */
#ifdef	_NO_LONGLONG
#define IOR_NO_LARGE_FILES
#ifdef	IOR_LARGE_FILES
#undef	IOR_LARGE_FILES
#endif
#endif

/*
 * Set up defines for large files support
 *
 * Since we always want this, set it ON by default
 */
#if	!defined( IOR_NO_LARGE_FILES ) && !defined( IOR_LARGE_FILES )
#define	IOR_LARGE_FILES
#endif

#if	!defined( IOR_LARGE_FILES ) && !defined( _LARGE_FILES )
#define _LARGE_FILES
#endif


/************************  OS is HP-UX?  ************************/
/*
 * check for several possible HP-UX defines - we use HPUX to check
 */
#ifdef	_HPUX
#define	HPUX
#endif
#ifdef	HP_UX
#define	HPUX
#endif
#ifdef	hpux
#define	HPUX
#endif
#ifdef	_hpux
#define	HPUX
#endif
#ifdef	_INCLUDE_HPUX_SOURCE
#define	HPUX
#endif
#ifdef	_HPUX_SOURCE
#define	HPUX
#endif

#if	defined( HPUX )
/* NOTE - HP-UX does not support I/Os smaller than 1 KB */
#ifdef	IOR_BLOCK_SIZE
#undef	IOR_BLOCK_SIZE
#endif
#define	IOR_BLOCK_SIZE		(1024L)
#include <fcntl.h>

#ifdef	IOR_LARGE_FILES
#define	HUGE			long long
#define	IOR_SEEK		lseek64
#define	IOR_MAX_SEEK		(HUGE)(4398046511104LL)	/* 4 TB */

#endif
#endif




/************************  OS is Solaris?  ************************/
#ifdef	sun
#ifdef	__i386

#define	SOLARISx86
/*** unistd.h does not come in by default on Solaris x86 ***/
#include <unistd.h>

#else
#define	SOLARIS_SPARC
#endif

#ifdef	IOR_LARGE_FILES
#define	HUGE			offset_t
#define	IOR_SEEK		llseek
#define	IOR_MAX_SEEK		(HUGE)(4398046511104LL)	/* 4 TB */
#define	IOR_LG_FILE_OPEN	O_LARGEFILE
#endif
#endif


/************************  OS is AIX?  ************************/

#if	defined( _AIX )
/* NOTE - AIX does not support I/Os smaller than 4 KB for raw devices */
#ifdef	IOR_BLOCK_SIZE
#undef	IOR_BLOCK_SIZE
#endif
#define	IOR_BLOCK_SIZE		(4096L)

/* Enable buffer alignment for AIX raw device I/O */
#define	SWAB_ALIGN_OFFSET       2
#define	ROUND_UP_OFFSET(X, M) ((M) - 1 - (((X) + (M) - 1) % (M)))
#define	PTR_ALIGN(PTR, M) ((unsigned char *)(((size_t)(PTR) + ((M) - 1)) & ~((M) - 1)))

#ifdef	IOR_LARGE_FILES
#define	HUGE			offset_t
#define	IOR_SEEK		llseek
#define	IOR_MAX_SEEK		(HUGE)(96LL * 1024 * 1024 * 1024 * 1024)  /* 96 TB */
#endif
#endif


/************************  OS is LINUX?  ************************/
/*
 * Since RedHat uses their own version, check for it
 */
#ifdef	__linux__
#define	_LINUX_
#endif

#ifdef	_LINUX_
#define	SWAB_ALIGN_OFFSET       2
#define	ROUND_UP_OFFSET(X, M) ((M) - 1 - (((X) + (M) - 1) % (M)))
#define	PTR_ALIGN(PTR, M) ((PTR) + ROUND_UP_OFFSET ((char *)(PTR) - (char *)0, (M)))

#include <unistd.h>

#ifdef	IOR_LARGE_FILES
/*
 * Some LINUX large files need more defined.
 * WARNING: these PROBABLY have to be defined in the makefile for
 *    this to work, since some other headers need to see them and
 *    they may be included before we get here.
 */
#ifndef  _LARGEFILE64_SOURCE
#define _LARGEFILE64_SOURCE
#endif
#ifndef __USE_LARGEFILE64
#define __USE_LARGEFILE64
#endif
#ifdef _FILE_OFFSET_BITS
#undef _FILE_OFFSET_BITS
#endif
#define _FILE_OFFSET_BITS	64

/* Linux, large files */
#define	HUGE			__off64_t
#define	IOR_SEEK		lseek64
/* 96 TiB = 96 * 1024^4 bytes */
#define	IOR_MAX_SEEK		(HUGE)(96LL * 1024 * 1024 * 1024 * 1024)  /* 96 TB */
#define	IOR_LG_FILE_OPEN	O_LARGEFILE

#endif
#endif


/************************  OS is Cygwin?  ************************/
/*
 * CYGWIN - UNIX tools for Windows
 */
#ifdef  __CYGWIN__
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

/* Cygwin needs explicit Binary Mode for raw seeking */
#ifndef O_BINARY
#define O_BINARY 0x10000
#endif

#define RAND            random
#define SEED(seed)      (srandom(seed))
#define IOR_BINARY      O_BINARY

/* 
 * Enable Pointer Alignment for Cygwin (copied from Linux block) 
 * This fixes "Illegal seek" caused by unaligned memory buffers on raw devices
 */
#define	SWAB_ALIGN_OFFSET       2
#define	ROUND_UP_OFFSET(X, M) ((M) - 1 - (((X) + (M) - 1) % (M)))
/* Use size_t casting to avoid 64-bit pointer truncation warnings */
#define	PTR_ALIGN(PTR, M) ((unsigned char *)(((size_t)(PTR) + ((M) - 1)) & ~((M) - 1)))

#ifdef  IOR_LARGE_FILES
/* Cygwin supports 64-bit off_t when built with -D_FILE_OFFSET_BITS=64 */
#define HUGE            off_t
#define IOR_SEEK        lseek
#define IOR_MAX_SEEK    ((HUGE)(96ULL * 1024ULL * 1024ULL * 1024ULL * 1024ULL))  /* 96 TiB */
#else
#define HUGE            long
#define IOR_SEEK        lseek
#define IOR_MAX_SEEK    (HUGE)(2147482624LL)        /* ~2 GB */
#endif
#endif


/************************  OS is unknown?  ************************/
/*
 * OK, not a known type, or did not set up large file support
 *  so we use 32 bit defaults
 */
#ifndef	IOR_SEEK
#define	HUGE			off_t
#define	IOR_SEEK		lseek
#define	IOR_MAX_SEEK		(HUGE)(2147482624LL)		/* ~2 GB */
#endif

#ifndef	RAND
#define	RAND			lrand48
#define	SEED(seed)		(srand48(seed))
#endif


/************************  General Definitions  ************************/
/*
 * Get time definitions
 */
#if	defined( __SGI__ ) || defined( _LINUX_ ) || defined( __CYGWIN__ )
#include <sys/time.h>
#else
#include <time.h>
#endif

/*
 * We already loaded fcntl for AIX in ior_mach.c - don't load it twice
 */
#if	!defined( _AIX )
#include <fcntl.h>
#endif

/*
 * process exit status
 */
#if	defined( _AIX ) || defined( HPUX ) || defined( __CYGWIN__ )
#include <sys/wait.h>
#else
#include <wait.h>
#endif
#define	IOR_VALID_EXIT		(4096)
#define	IOR_DID_EXIT(stat)	(stat&IOR_VALID_EXIT)
#define	IOR_EXIT_STATUS(stat)	(stat^IOR_VALID_EXIT)

/*
 * Define binary file open mode (only real for Windows code)
 */
#ifndef	IOR_BINARY
#define	IOR_BINARY		0
#endif

/*
 * file open modes - not all currently used
 */
#ifndef	IOR_LG_FILE_OPEN
#define	IOR_LG_FILE_OPEN	0
#endif
#define	IOR_OPEN_RD		(O_RDONLY|IOR_BINARY|IOR_LG_FILE_OPEN)
#define	IOR_OPEN_RDWR		(O_RDWR|IOR_BINARY|IOR_LG_FILE_OPEN)
#define	IOR_OPEN_SYNC		(O_SYNC|IOR_BINARY|IOR_LG_FILE_OPEN)
#define	IOR_OPEN_ASYNC		(IOR_BINARY|IOR_LG_FILE_OPEN)
#define	IOR_DIRECT_IO		(O_DIRECT)

/*
 * define seek locations
 */

#define	IOR_SEEK_SET		0
#define	IOR_SEEK_END		2

#define HUGE_BYTES		(int)(sizeof(HUGE))

#define	YYSTYPE			HUGE /* force YACC type */

typedef	long	ior_clock;


#endif