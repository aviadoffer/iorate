/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "ior_pars.y"

/**************************************************************************
 *
 * Yes, the shift/reduce errors from YACC/bison are expected.  It comes
 * from allowing flexible formulas to be used for number data entry, rather
 * than fixed input syntax.  This is a desired result.
 *
 *************************************************************************/

/**************************************************************************
 *
 *  ior_pars.y - the parser for iorate
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_pars.y,v 3.7 2011/11/03 11:13:29 westiv Exp westiv $";

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include "iorate.h"


#define	IOR_PCT_BASE	10000.0		/* we pass HUGE, so add some digits */

static ior_config *parse_cfg;		/* config we are parsing for */
static ior_device *parse_dev;		/* device we have parsed */
static ior_device cur_dev;		/* device we are parsing */
static ior_pattern *parse_pat;		/* pattern we have parsed */
static ior_pattern cur_pat;		/* pattern we are parsing */
static ior_test	*parse_test;		/* test we have successfully parsed */
static ior_test	cur_test;		/* test we are parsing */
static int parse_cur_pat;		/* current pattern */
static int parse_pat_pct[ IOR_MAX_PATTERNS + 2 ]; /* pattern allocation */
static HUGE ior_n_size;			/* size we read */
static char *name;			/* name of our item */

extern int yyerror( char *s );


#line 135 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    IOR_L_NUMBER = 258,            /* IOR_L_NUMBER  */
    IOR_L_STRING = 259,            /* IOR_L_STRING  */
    IOR_L_STRING_WITH_NEWLINE = 260, /* IOR_L_STRING_WITH_NEWLINE  */
    IOR_L_KB = 261,                /* IOR_L_KB  */
    IOR_L_MB = 262,                /* IOR_L_MB  */
    IOR_L_GB = 263,                /* IOR_L_GB  */
    IOR_L_TB = 264,                /* IOR_L_TB  */
    IOR_L_PB = 265,                /* IOR_L_PB  */
    IOR_L_SECONDS = 266,           /* IOR_L_SECONDS  */
    IOR_L_MINUTES = 267,           /* IOR_L_MINUTES  */
    IOR_L_HOURS = 268,             /* IOR_L_HOURS  */
    IOR_L_DEVICE = 269,            /* IOR_L_DEVICE  */
    IOR_L_PATTERN = 270,           /* IOR_L_PATTERN  */
    IOR_L_TEST = 271,              /* IOR_L_TEST  */
    IOR_L_SEQUENTIAL = 272,        /* IOR_L_SEQUENTIAL  */
    IOR_L_RANDOM = 273,            /* IOR_L_RANDOM  */
    IOR_L_CAPACITY = 274,          /* IOR_L_CAPACITY  */
    IOR_L_MAXIMUM = 275,           /* IOR_L_MAXIMUM  */
    IOR_L_IGNORE = 276,            /* IOR_L_IGNORE  */
    IOR_L_OFFSET = 277,            /* IOR_L_OFFSET  */
    IOR_L_BLOCK = 278,             /* IOR_L_BLOCK  */
    IOR_L_ACCESS_KEY = 279,        /* IOR_L_ACCESS_KEY  */
    IOR_L_SECRET_KEY = 280,        /* IOR_L_SECRET_KEY  */
    IOR_L_BUCKET = 281,            /* IOR_L_BUCKET  */
    IOR_L_PUT = 282,               /* IOR_L_PUT  */
    IOR_L_GET = 283,               /* IOR_L_GET  */
    IOR_L_ENUM = 284,              /* IOR_L_ENUM  */
    IOR_L_IOPS = 285,              /* IOR_L_IOPS  */
    IOR_L_WRITE = 286,             /* IOR_L_WRITE  */
    IOR_L_READ = 287,              /* IOR_L_READ  */
    IOR_L_UNMAP = 288,             /* IOR_L_UNMAP  */
    IOR_L_SIZE = 289,              /* IOR_L_SIZE  */
    IOR_L_PAUSE = 290,             /* IOR_L_PAUSE  */
    IOR_L_FROM = 291,              /* IOR_L_FROM  */
    IOR_L_FOR = 292,               /* IOR_L_FOR  */
    IOR_L_IO = 293,                /* IOR_L_IO  */
    IOR_L_TARGET = 294,            /* IOR_L_TARGET  */
    IOR_L_AT = 295,                /* IOR_L_AT  */
    IOR_L_ONLY = 296,              /* IOR_L_ONLY  */
    IOR_L_TEMP = 297,              /* IOR_L_TEMP  */
    IOR_L_CREATE = 298,            /* IOR_L_CREATE  */
    IOR_L_LOCK = 299,              /* IOR_L_LOCK  */
    IOR_L_ZONE = 300,              /* IOR_L_ZONE  */
    IOR_L_HISTORY = 301,           /* IOR_L_HISTORY  */
    IOR_L_REUSE = 302,             /* IOR_L_REUSE  */
    IOR_L_COUNT = 303,             /* IOR_L_COUNT  */
    IOR_L_LIMIT = 304,             /* IOR_L_LIMIT  */
    IOR_L_COPY = 305,              /* IOR_L_COPY  */
    IOR_L_SKEW = 306,              /* IOR_L_SKEW  */
    IOR_L_SEED = 307,              /* IOR_L_SEED  */
    IOR_L_CORRELATE = 308,         /* IOR_L_CORRELATE  */
    IOR_L_AREA = 309,              /* IOR_L_AREA  */
    IOR_L_SHIFT = 310,             /* IOR_L_SHIFT  */
    IOR_L_META = 311,              /* IOR_L_META  */
    IOR_L_STAT = 312,              /* IOR_L_STAT  */
    IOR_L_OPENCLOSE = 313,         /* IOR_L_OPENCLOSE  */
    IOR_L_READDIR = 314,           /* IOR_L_READDIR  */
    IOR_L_UNKNOWN = 315,           /* IOR_L_UNKNOWN  */
    CAPACITY = 316                 /* CAPACITY  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_IOR_L_NUMBER = 3,               /* IOR_L_NUMBER  */
  YYSYMBOL_IOR_L_STRING = 4,               /* IOR_L_STRING  */
  YYSYMBOL_IOR_L_STRING_WITH_NEWLINE = 5,  /* IOR_L_STRING_WITH_NEWLINE  */
  YYSYMBOL_IOR_L_KB = 6,                   /* IOR_L_KB  */
  YYSYMBOL_IOR_L_MB = 7,                   /* IOR_L_MB  */
  YYSYMBOL_IOR_L_GB = 8,                   /* IOR_L_GB  */
  YYSYMBOL_IOR_L_TB = 9,                   /* IOR_L_TB  */
  YYSYMBOL_IOR_L_PB = 10,                  /* IOR_L_PB  */
  YYSYMBOL_IOR_L_SECONDS = 11,             /* IOR_L_SECONDS  */
  YYSYMBOL_IOR_L_MINUTES = 12,             /* IOR_L_MINUTES  */
  YYSYMBOL_IOR_L_HOURS = 13,               /* IOR_L_HOURS  */
  YYSYMBOL_IOR_L_DEVICE = 14,              /* IOR_L_DEVICE  */
  YYSYMBOL_IOR_L_PATTERN = 15,             /* IOR_L_PATTERN  */
  YYSYMBOL_IOR_L_TEST = 16,                /* IOR_L_TEST  */
  YYSYMBOL_IOR_L_SEQUENTIAL = 17,          /* IOR_L_SEQUENTIAL  */
  YYSYMBOL_IOR_L_RANDOM = 18,              /* IOR_L_RANDOM  */
  YYSYMBOL_IOR_L_CAPACITY = 19,            /* IOR_L_CAPACITY  */
  YYSYMBOL_IOR_L_MAXIMUM = 20,             /* IOR_L_MAXIMUM  */
  YYSYMBOL_IOR_L_IGNORE = 21,              /* IOR_L_IGNORE  */
  YYSYMBOL_IOR_L_OFFSET = 22,              /* IOR_L_OFFSET  */
  YYSYMBOL_IOR_L_BLOCK = 23,               /* IOR_L_BLOCK  */
  YYSYMBOL_IOR_L_ACCESS_KEY = 24,          /* IOR_L_ACCESS_KEY  */
  YYSYMBOL_IOR_L_SECRET_KEY = 25,          /* IOR_L_SECRET_KEY  */
  YYSYMBOL_IOR_L_BUCKET = 26,              /* IOR_L_BUCKET  */
  YYSYMBOL_IOR_L_PUT = 27,                 /* IOR_L_PUT  */
  YYSYMBOL_IOR_L_GET = 28,                 /* IOR_L_GET  */
  YYSYMBOL_IOR_L_ENUM = 29,                /* IOR_L_ENUM  */
  YYSYMBOL_IOR_L_IOPS = 30,                /* IOR_L_IOPS  */
  YYSYMBOL_IOR_L_WRITE = 31,               /* IOR_L_WRITE  */
  YYSYMBOL_IOR_L_READ = 32,                /* IOR_L_READ  */
  YYSYMBOL_IOR_L_UNMAP = 33,               /* IOR_L_UNMAP  */
  YYSYMBOL_IOR_L_SIZE = 34,                /* IOR_L_SIZE  */
  YYSYMBOL_IOR_L_PAUSE = 35,               /* IOR_L_PAUSE  */
  YYSYMBOL_IOR_L_FROM = 36,                /* IOR_L_FROM  */
  YYSYMBOL_IOR_L_FOR = 37,                 /* IOR_L_FOR  */
  YYSYMBOL_IOR_L_IO = 38,                  /* IOR_L_IO  */
  YYSYMBOL_IOR_L_TARGET = 39,              /* IOR_L_TARGET  */
  YYSYMBOL_IOR_L_AT = 40,                  /* IOR_L_AT  */
  YYSYMBOL_IOR_L_ONLY = 41,                /* IOR_L_ONLY  */
  YYSYMBOL_IOR_L_TEMP = 42,                /* IOR_L_TEMP  */
  YYSYMBOL_IOR_L_CREATE = 43,              /* IOR_L_CREATE  */
  YYSYMBOL_IOR_L_LOCK = 44,                /* IOR_L_LOCK  */
  YYSYMBOL_IOR_L_ZONE = 45,                /* IOR_L_ZONE  */
  YYSYMBOL_IOR_L_HISTORY = 46,             /* IOR_L_HISTORY  */
  YYSYMBOL_IOR_L_REUSE = 47,               /* IOR_L_REUSE  */
  YYSYMBOL_IOR_L_COUNT = 48,               /* IOR_L_COUNT  */
  YYSYMBOL_IOR_L_LIMIT = 49,               /* IOR_L_LIMIT  */
  YYSYMBOL_IOR_L_COPY = 50,                /* IOR_L_COPY  */
  YYSYMBOL_IOR_L_SKEW = 51,                /* IOR_L_SKEW  */
  YYSYMBOL_IOR_L_SEED = 52,                /* IOR_L_SEED  */
  YYSYMBOL_IOR_L_CORRELATE = 53,           /* IOR_L_CORRELATE  */
  YYSYMBOL_IOR_L_AREA = 54,                /* IOR_L_AREA  */
  YYSYMBOL_IOR_L_SHIFT = 55,               /* IOR_L_SHIFT  */
  YYSYMBOL_IOR_L_META = 56,                /* IOR_L_META  */
  YYSYMBOL_IOR_L_STAT = 57,                /* IOR_L_STAT  */
  YYSYMBOL_IOR_L_OPENCLOSE = 58,           /* IOR_L_OPENCLOSE  */
  YYSYMBOL_IOR_L_READDIR = 59,             /* IOR_L_READDIR  */
  YYSYMBOL_IOR_L_UNKNOWN = 60,             /* IOR_L_UNKNOWN  */
  YYSYMBOL_61_ = 61,                       /* '='  */
  YYSYMBOL_62_ = 62,                       /* '%'  */
  YYSYMBOL_63_ = 63,                       /* '@'  */
  YYSYMBOL_64_ = 64,                       /* ','  */
  YYSYMBOL_65_ = 65,                       /* '+'  */
  YYSYMBOL_66_ = 66,                       /* '-'  */
  YYSYMBOL_67_ = 67,                       /* '*'  */
  YYSYMBOL_68_ = 68,                       /* '/'  */
  YYSYMBOL_69_ = 69,                       /* '('  */
  YYSYMBOL_70_ = 70,                       /* ')'  */
  YYSYMBOL_71_ = 71,                       /* ';'  */
  YYSYMBOL_CAPACITY = 72,                  /* CAPACITY  */
  YYSYMBOL_YYACCEPT = 73,                  /* $accept  */
  YYSYMBOL_config = 74,                    /* config  */
  YYSYMBOL_file_lines = 75,                /* file_lines  */
  YYSYMBOL_file_line = 76,                 /* file_line  */
  YYSYMBOL_dev_line = 77,                  /* dev_line  */
  YYSYMBOL_pat_line = 78,                  /* pat_line  */
  YYSYMBOL_test_line = 79,                 /* test_line  */
  YYSYMBOL_iops_line = 80,                 /* iops_line  */
  YYSYMBOL_dev_args = 81,                  /* dev_args  */
  YYSYMBOL_dev_arg = 82,                   /* dev_arg  */
  YYSYMBOL_pat_args = 83,                  /* pat_args  */
  YYSYMBOL_pat_arg = 84,                   /* pat_arg  */
  YYSYMBOL_test_args = 85,                 /* test_args  */
  YYSYMBOL_test_arg = 86,                  /* test_arg  */
  YYSYMBOL_pat_pct = 87,                   /* pat_pct  */
  YYSYMBOL_time = 88,                      /* time  */
  YYSYMBOL_size = 89,                      /* size  */
  YYSYMBOL_pct = 90,                       /* pct  */
  YYSYMBOL_opt_number = 91,                /* opt_number  */
  YYSYMBOL_number = 92,                    /* number  */
  YYSYMBOL_expr = 93,                      /* expr  */
  YYSYMBOL_name = 94,                      /* name  */
  YYSYMBOL_comma = 95                      /* comma  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  22
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   286

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  73
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  23
/* YYNRULES -- Number of rules.  */
#define YYNRULES  99
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  161

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   316


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    62,     2,     2,
      69,    70,    67,    65,    64,    66,     2,    68,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    71,
       2,    61,     2,     2,    63,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    72
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   148,   148,   153,   154,   157,   158,   159,   160,   161,
     170,   231,   302,   383,   423,   424,   427,   429,   431,   433,
     435,   437,   439,   441,   443,   445,   447,   449,   451,   453,
     457,   458,   461,   463,   465,   467,   469,   471,   473,   475,
     477,   479,   481,   483,   485,   487,   489,   491,   493,   495,
     497,   499,   501,   503,   505,   507,   509,   511,   513,   517,
     518,   521,   522,   524,   526,   528,   530,   532,   534,   536,
     538,   540,   542,   544,   546,   550,   577,   581,   586,   590,
     593,   596,   602,   605,   607,   609,   611,   613,   619,   622,
     626,   630,   635,   641,   644,   647,   651,   653,   663,   664
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "IOR_L_NUMBER",
  "IOR_L_STRING", "IOR_L_STRING_WITH_NEWLINE", "IOR_L_KB", "IOR_L_MB",
  "IOR_L_GB", "IOR_L_TB", "IOR_L_PB", "IOR_L_SECONDS", "IOR_L_MINUTES",
  "IOR_L_HOURS", "IOR_L_DEVICE", "IOR_L_PATTERN", "IOR_L_TEST",
  "IOR_L_SEQUENTIAL", "IOR_L_RANDOM", "IOR_L_CAPACITY", "IOR_L_MAXIMUM",
  "IOR_L_IGNORE", "IOR_L_OFFSET", "IOR_L_BLOCK", "IOR_L_ACCESS_KEY",
  "IOR_L_SECRET_KEY", "IOR_L_BUCKET", "IOR_L_PUT", "IOR_L_GET",
  "IOR_L_ENUM", "IOR_L_IOPS", "IOR_L_WRITE", "IOR_L_READ", "IOR_L_UNMAP",
  "IOR_L_SIZE", "IOR_L_PAUSE", "IOR_L_FROM", "IOR_L_FOR", "IOR_L_IO",
  "IOR_L_TARGET", "IOR_L_AT", "IOR_L_ONLY", "IOR_L_TEMP", "IOR_L_CREATE",
  "IOR_L_LOCK", "IOR_L_ZONE", "IOR_L_HISTORY", "IOR_L_REUSE",
  "IOR_L_COUNT", "IOR_L_LIMIT", "IOR_L_COPY", "IOR_L_SKEW", "IOR_L_SEED",
  "IOR_L_CORRELATE", "IOR_L_AREA", "IOR_L_SHIFT", "IOR_L_META",
  "IOR_L_STAT", "IOR_L_OPENCLOSE", "IOR_L_READDIR", "IOR_L_UNKNOWN", "'='",
  "'%'", "'@'", "','", "'+'", "'-'", "'*'", "'/'", "'('", "')'", "';'",
  "CAPACITY", "$accept", "config", "file_lines", "file_line", "dev_line",
  "pat_line", "test_line", "iops_line", "dev_args", "dev_arg", "pat_args",
  "pat_arg", "test_args", "test_arg", "pat_pct", "time", "size", "pct",
  "opt_number", "number", "expr", "name", "comma", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-93)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-3)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     106,   -67,     4,     4,     4,    -8,    17,    15,   -93,   -93,
     -93,   -93,   -93,   -93,   -93,     4,   -52,   -93,   160,   -42,
     -41,     4,   -93,   -93,    91,     9,   -93,   -93,   -93,   -93,
     -93,   -93,   -93,   -93,     4,     4,     4,     4,     9,     9,
     -19,   -93,   -93,   -93,   -93,   168,   168,   176,   176,   -93,
     -93,     4,   215,   174,     7,    -5,     4,     4,     3,     9,
       9,     9,   -14,   -93,   -93,   -93,     4,     4,   -93,   -93,
       4,   -93,     5,   -93,   -93,   -93,     4,     4,   -93,     4,
       4,     1,     4,     4,     4,     4,     4,   -93,   -93,   -93,
     -93,   -93,   -93,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,   -93,   -93,   -93,    21,    16,   131,   -32,
     -93,   160,   -93,     4,   -93,   -93,   -93,   -93,   -93,   -93,
     -93,   -93,     4,   -93,   131,   -93,   -93,   -93,   131,   -93,
     -93,     4,   -93,   -93,   -93,   -93,   -93,   -93,   -93,   160,
     -93,   -93,   -93,   -93,   -93,   -93,   -93,   -93,   -93,   -93,
     -93,     4,   -93,   -93,   -93,   -93,   -93,   -93,   -17,   -93,
     -93
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,    80,     0,    80,     0,     0,     0,     3,     5,
       6,     7,     8,     9,    82,     0,     0,    79,    81,     0,
       0,     0,     1,     4,     0,     0,    88,    89,    90,    91,
      92,    93,    94,    95,     0,     0,     0,     0,     0,     0,
       0,    87,    96,    97,    15,    83,    84,    85,    86,    31,
      60,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    25,    27,    28,    29,     0,     0,    10,    14,
      43,    42,     0,    32,    33,    34,    46,    44,    48,     0,
       0,     0,     0,     0,     0,     0,     0,    36,    37,    38,
      39,    11,    30,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    12,    59,    61,     0,     0,    81,     0,
      20,    77,    19,     0,    22,    16,    17,    18,    26,    23,
      24,    41,     0,    47,     0,    45,    57,    58,    77,    55,
      56,     0,    49,    50,    54,    53,    51,    52,    64,    76,
      68,    69,    62,    66,    67,    63,    70,    71,    73,    74,
      72,     0,    65,    78,    13,    21,    40,    35,    98,    99,
      75
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -93,   -93,   -93,    43,   -93,   -93,   -93,   -93,   -93,   -93,
     -93,   -93,   -93,   -93,   -93,   -92,   -56,   172,    48,    -3,
      34,   -27,   -93
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     6,     7,     8,     9,    10,    11,    12,    52,    69,
      53,    92,    54,   104,   105,   138,   110,   106,    16,    17,
      18,    44,   160
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      19,   112,   114,   142,    13,   145,    14,    14,    21,    25,
      14,    49,    50,    42,    43,    -2,     1,    22,    40,    38,
      39,    51,   122,   126,   129,   109,   132,   118,    93,     2,
       3,     4,   115,   116,   117,   131,   151,   113,   140,   154,
     143,    94,    95,    96,    97,   149,   152,   159,    55,    24,
      23,   107,    20,     0,     5,     0,     0,   155,    98,    99,
     100,   101,   102,   119,   120,     0,     0,   121,    45,    46,
      47,    48,    15,    15,     0,   157,    15,     0,   103,     0,
     134,     0,   136,   137,     0,     0,     0,     0,   108,     0,
     111,   111,   111,     0,     0,     0,   147,    26,    27,    28,
      29,    30,    31,    32,    33,     0,     0,     1,     0,     0,
     124,   124,     0,   128,   128,     0,   128,     0,   124,   156,
       2,     3,     4,     0,     0,     0,     0,   139,   128,   139,
     128,   139,   124,     0,   124,   111,   124,    26,    27,    28,
      29,    30,    31,    32,    33,     5,     0,   111,   158,     0,
       0,     0,     0,     0,     0,     0,    34,    35,    36,    37,
       0,    41,     0,     0,     0,   111,    26,    27,    28,    29,
      30,    31,    32,    33,    26,    27,    28,    29,    30,    31,
      32,    33,    26,    27,    28,    29,    30,    31,    32,    33,
       0,    70,    71,   153,    72,     0,    34,    35,    36,    37,
       0,    73,    74,    75,     0,    76,    77,    78,    79,     0,
      80,     0,    81,     0,     0,     0,     0,     0,     0,    82,
      83,    84,    85,    86,     0,    34,    35,    36,    37,     0,
      87,    88,    89,    90,    56,    36,    37,    57,    58,    59,
      60,    61,     0,     0,     0,    91,     0,    62,   123,   125,
       0,   127,   130,     0,   133,     0,   135,    63,    64,    65,
       0,     0,     0,    66,     0,    67,   141,     0,   144,     0,
     146,     0,   148,     0,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    68
};

static const yytype_int16 yycheck[] =
{
       3,    57,    58,    95,    71,    97,     3,     3,    16,    61,
       3,    38,    39,     4,     5,     0,     1,     0,    21,    61,
      61,    40,    17,    79,    80,    30,    82,    41,    21,    14,
      15,    16,    59,    60,    61,    34,    15,    34,    94,    71,
      96,    34,    35,    36,    37,   101,    30,    64,    51,    15,
       7,    54,     4,    -1,    39,    -1,    -1,   113,    51,    52,
      53,    54,    55,    66,    67,    -1,    -1,    70,    34,    35,
      36,    37,    69,    69,    -1,   131,    69,    -1,    71,    -1,
      83,    -1,    85,    86,    -1,    -1,    -1,    -1,    54,    -1,
      56,    57,    58,    -1,    -1,    -1,    99,     6,     7,     8,
       9,    10,    11,    12,    13,    -1,    -1,     1,    -1,    -1,
      76,    77,    -1,    79,    80,    -1,    82,    -1,    84,   122,
      14,    15,    16,    -1,    -1,    -1,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,   102,     6,     7,     8,
       9,    10,    11,    12,    13,    39,    -1,   113,   151,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,
      -1,    70,    -1,    -1,    -1,   131,     6,     7,     8,     9,
      10,    11,    12,    13,     6,     7,     8,     9,    10,    11,
      12,    13,     6,     7,     8,     9,    10,    11,    12,    13,
      -1,    17,    18,    62,    20,    -1,    65,    66,    67,    68,
      -1,    27,    28,    29,    -1,    31,    32,    33,    34,    -1,
      36,    -1,    38,    -1,    -1,    -1,    -1,    -1,    -1,    45,
      46,    47,    48,    49,    -1,    65,    66,    67,    68,    -1,
      56,    57,    58,    59,    19,    67,    68,    22,    23,    24,
      25,    26,    -1,    -1,    -1,    71,    -1,    32,    76,    77,
      -1,    79,    80,    -1,    82,    -1,    84,    42,    43,    44,
      -1,    -1,    -1,    48,    -1,    50,    94,    -1,    96,    -1,
      98,    -1,   100,    -1,   102,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    71
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     1,    14,    15,    16,    39,    74,    75,    76,    77,
      78,    79,    80,    71,     3,    69,    91,    92,    93,    92,
      91,    16,     0,    76,    93,    61,     6,     7,     8,     9,
      10,    11,    12,    13,    65,    66,    67,    68,    61,    61,
      92,    70,     4,     5,    94,    93,    93,    93,    93,    94,
      94,    40,    81,    83,    85,    92,    19,    22,    23,    24,
      25,    26,    32,    42,    43,    44,    48,    50,    71,    82,
      17,    18,    20,    27,    28,    29,    31,    32,    33,    34,
      36,    38,    45,    46,    47,    48,    49,    56,    57,    58,
      59,    71,    84,    21,    34,    35,    36,    37,    51,    52,
      53,    54,    55,    71,    86,    87,    90,    92,    93,    30,
      89,    93,    89,    34,    89,    94,    94,    94,    41,    92,
      92,    92,    17,    90,    93,    90,    89,    90,    93,    89,
      90,    34,    89,    90,    92,    90,    92,    92,    88,    93,
      89,    90,    88,    89,    90,    88,    90,    92,    90,    89,
      90,    15,    30,    62,    71,    89,    92,    89,    92,    64,
      95
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    73,    74,    75,    75,    76,    76,    76,    76,    76,
      77,    78,    79,    80,    81,    81,    82,    82,    82,    82,
      82,    82,    82,    82,    82,    82,    82,    82,    82,    82,
      83,    83,    84,    84,    84,    84,    84,    84,    84,    84,
      84,    84,    84,    84,    84,    84,    84,    84,    84,    84,
      84,    84,    84,    84,    84,    84,    84,    84,    84,    85,
      85,    86,    86,    86,    86,    86,    86,    86,    86,    86,
      86,    86,    86,    86,    86,    87,    88,    89,    90,    91,
      91,    92,    93,    93,    93,    93,    93,    93,    93,    93,
      93,    93,    93,    93,    93,    93,    94,    94,    95,    95
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     2,     1,     1,     1,     1,     2,
       6,     6,     6,     7,     2,     0,     2,     2,     2,     2,
       2,     3,     2,     2,     2,     1,     2,     1,     1,     1,
       2,     0,     1,     1,     1,     3,     1,     1,     1,     1,
       3,     2,     1,     1,     1,     2,     1,     2,     1,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       0,     1,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     4,     1,     1,     2,     1,
       0,     1,     1,     3,     3,     3,     3,     3,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     1,     0,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* config: file_lines  */
#line 149 "ior_pars.y"
            { ior_debug( parse_cfg, "parsed a valid config" );
	    return( 0 ); }
#line 1460 "y.tab.c"
    break;

  case 9: /* file_line: error ';'  */
#line 162 "ior_pars.y"
            {
		ior_parse_dev_clear( parse_cfg ); /* clean up any input */
		ior_parse_pat_clear( parse_cfg );
		ior_parse_test_clear( parse_cfg );
		yyerrok;
	    }
#line 1471 "y.tab.c"
    break;

  case 10: /* dev_line: IOR_L_DEVICE opt_number '=' name dev_args ';'  */
#line 171 "ior_pars.y"
            {
		name = (char *)((long)( yyvsp[-2] ));
		sprintf( msg_buf, "parsed DEV: %d = %s %dk %dk %dk",
			(int) yyvsp[-4], name,
			(int)( cur_dev.d_offset / 1024 ),
			(int)( cur_dev.d_capacity / 1024 ),
			(int)( cur_dev.d_block_size / 1024 ));
		ior_debug( parse_cfg, msg_buf );

		if ( yyvsp[-4] == -1 ) {	/* create a device ID */
		    yyvsp[-4] = ++parse_cfg->c_ndev;
		};

		if (( yyvsp[-4] < 1 ) || ( yyvsp[-4] > IOR_MAX_DEVICES )) {
		    sprintf( msg_buf, "%s: %d: Invalid device number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) yyvsp[-4] );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_ndev < yyvsp[-4] ) {
			parse_cfg->c_ndev = yyvsp[-4];
		    };

		    parse_dev = &( parse_cfg->c_devs[ yyvsp[-4] - 1 ]);

		    if ( parse_dev->d_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of device %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) yyvsp[-4], parse_dev->d_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_dev->d_name );
		    };

		    parse_dev->d_name = name;
		    parse_dev->d_valid = 1; /* mark as valid */

		    parse_dev->d_offset = cur_dev.d_offset;
		    parse_dev->d_capacity = cur_dev.d_capacity;
		    parse_dev->d_block_size = cur_dev.d_block_size;
		    parse_dev->d_is_async = cur_dev.d_is_async;
		    parse_dev->d_read_only = cur_dev.d_read_only;
		    parse_dev->d_is_temp = cur_dev.d_is_temp;
		    parse_dev->d_create = cur_dev.d_create;
		    parse_dev->d_lock = cur_dev.d_lock;
		    parse_dev->d_count = cur_dev.d_count;
                    parse_dev->d_fid = -1;
                    parse_dev->d_is_s3 = cur_dev.d_is_s3;
                    parse_dev->d_access_key = cur_dev.d_access_key;
                    parse_dev->d_secret_key = cur_dev.d_secret_key;
                    parse_dev->d_bucket = cur_dev.d_bucket;

                    ior_debug( parse_cfg, "parsed a valid device" );
		};
					/* clear out parsing data area */
		ior_parse_dev_clear( parse_cfg );
	    }
#line 1533 "y.tab.c"
    break;

  case 11: /* pat_line: IOR_L_PATTERN number '=' name pat_args ';'  */
#line 232 "ior_pars.y"
            {
		name = (char *)((long)( yyvsp[-2] ));
		sprintf( msg_buf,
			"parsed PAT: %d = %s %dK %d %d %d%% %dK %d%% %dK %d%% %dK %d%% %d %d %d %d%%",
			(int) yyvsp[-4], name,
			(int)( cur_pat.p_io_size / 1024 ),
			(int) cur_pat.p_max_seq,
			(int) cur_pat.p_is_seq,
			(int) cur_pat.p_read_pct,
			(int)( cur_pat.p_start / 1024 ),
			(int) cur_pat.p_start_pct,
			(int)( cur_pat.p_size / 1024 ),
			(int) cur_pat.p_size_pct,
		    	(int)( cur_pat.p_local_size / 1024 ),
		    	(int) cur_pat.p_local_pct,
		    	(int) cur_pat.p_local_count,
		    	(int) cur_pat.p_local_limit,
		    	(int) cur_pat.p_history,
		    	(int) cur_pat.p_reuse_pct );
		ior_debug( parse_cfg, msg_buf );
		if (( yyvsp[-4] < 1 ) || ( yyvsp[-4] > IOR_MAX_PATTERNS )) {
		    sprintf( msg_buf, "%s: %d: Invalid pattern number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) yyvsp[-4] );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_npat < yyvsp[-4] ) {
			parse_cfg->c_npat = yyvsp[-4];
		    };

		    parse_pat = &( parse_cfg->c_pats[ yyvsp[-4] - 1 ]);

		    if ( parse_pat->p_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of pattern %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) yyvsp[-4], parse_pat->p_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_pat->p_name );
		    };

		    parse_pat->p_name = name;
		    parse_pat->p_end = -1; /* know where the end is */
		    parse_pat->p_valid = 1; /* mark as valid */

		    parse_pat->p_io_size = cur_pat.p_io_size;
        parse_pat->p_io_size_set = cur_pat.p_io_size_set;
		    parse_pat->p_max_seq = cur_pat.p_max_seq;
		    parse_pat->p_is_seq = cur_pat.p_is_seq;
		    parse_pat->p_read_pct = cur_pat.p_read_pct;
		    parse_pat->p_is_unmap = cur_pat.p_is_unmap;
        parse_pat->p_is_s3 = cur_pat.p_is_s3;
        parse_pat->p_s3_mode = cur_pat.p_s3_mode;
		    parse_pat->p_start = cur_pat.p_start;
		    parse_pat->p_start_pct = cur_pat.p_start_pct;
		    parse_pat->p_size = cur_pat.p_size;
		    parse_pat->p_size_pct = cur_pat.p_size_pct;
		    parse_pat->p_local_size = cur_pat.p_local_size;
		    parse_pat->p_local_pct = cur_pat.p_local_pct;
		    parse_pat->p_local_count = cur_pat.p_local_count;
		    parse_pat->p_local_limit = cur_pat.p_local_limit;
		    parse_pat->p_history = cur_pat.p_history;
		    parse_pat->p_reuse_pct = cur_pat.p_reuse_pct;
		    parse_pat->p_is_meta = cur_pat.p_is_meta;
		    parse_pat->p_meta_mode = cur_pat.p_meta_mode;

		    ior_debug( parse_cfg, "parsed a valid pattern" );
		};
					/* clear out parsing data area */
		ior_parse_pat_clear( parse_cfg );
	    }
#line 1606 "y.tab.c"
    break;

  case 12: /* test_line: IOR_L_TEST opt_number '=' name test_args ';'  */
#line 303 "ior_pars.y"
            {
		name = (char *)((long)( yyvsp[-2] ));
		sprintf( msg_buf, "parsed TEST: %d = %s %d %d %d %d %dk %dk",
			(int) yyvsp[-4], name,
			(int) cur_test.t_pause,
			(int) cur_test.t_duration,
			(int) cur_test.t_ignore,
			(int) cur_test.t_iops,
			(int)( cur_test.t_start / 1024 ),
			(int)( cur_test.t_size / 1024 ));
		ior_debug( parse_cfg, msg_buf );
		sprintf( msg_buf, "    TEST : skew %d%%, seed %d, shift %d%%, cor %d%%, area %dk",
			(int) cur_test.t_skew,
			(int) cur_test.t_seed,
			(int) cur_test.t_shift,
			(int) cur_test.t_correlate,
			(int)( cur_test.t_area / 1024 ));
		ior_debug( parse_cfg, msg_buf );

		if ( yyvsp[-4] == -1 ) {	/* create a test ID */
		    yyvsp[-4] = ++parse_cfg->c_ntest;
		};

		if (( yyvsp[-4] < 1 ) || ( yyvsp[-4] > IOR_MAX_TESTS )) {
		    sprintf( msg_buf, "%s: %d: Invalid test number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) yyvsp[-4] );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_ntest < yyvsp[-4] ) {
			parse_cfg->c_ntest = yyvsp[-4];
		    };

		    parse_test = &( parse_cfg->c_tests[ yyvsp[-4] - 1 ]);

		    if ( parse_test->t_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of test %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) yyvsp[-4], parse_test->t_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_test->t_name );
		    };

		    parse_test->t_name = name;
		    parse_test->t_valid = 1; /* mark as valid */

		    parse_test->t_pause = cur_test.t_pause;
		    parse_test->t_duration = cur_test.t_duration;
		    parse_test->t_ignore = cur_test.t_ignore;
		    parse_test->t_iops = cur_test.t_iops;
		    parse_test->t_start = cur_test.t_start;
		    parse_test->t_start_pct = cur_test.t_start_pct;
		    parse_test->t_size = cur_test.t_size;
		    parse_test->t_size_pct = cur_test.t_size_pct;

		    parse_test->t_skew = cur_test.t_skew;
		    parse_test->t_seed = cur_test.t_seed;
		    parse_test->t_shift = cur_test.t_shift;
		    parse_test->t_correlate = cur_test.t_correlate;
		    parse_test->t_area = cur_test.t_area;

					/* save pattern percentages */
		    for ( parse_cur_pat = 0;
			    parse_cur_pat < IOR_MAX_PATTERNS;
			    parse_cur_pat++ ) {

					/* save current pattern percent */
			parse_test->t_pat_pct[ parse_cur_pat ] =
				parse_pat_pct[ parse_cur_pat ];
		    };

		    ior_debug( parse_cfg, "parsed a valid test" );
		};

					/* clear out parsing data area */
		ior_parse_test_clear( parse_cfg );
	    }
#line 1689 "y.tab.c"
    break;

  case 13: /* iops_line: IOR_L_TARGET IOR_L_TEST number IOR_L_AT number IOR_L_IOPS ';'  */
#line 384 "ior_pars.y"
            {
		sprintf( msg_buf, "parsed IOPS: Test %d @ %d",
			(int) yyvsp[-4], (int) yyvsp[-2] );
		ior_debug( parse_cfg, msg_buf );
		if (( yyvsp[-4] < 1 ) || ( yyvsp[-4] > IOR_MAX_TESTS )) {
		    sprintf( msg_buf, "%s: %d: Invalid test number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) yyvsp[-4] );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    parse_test = &( parse_cfg->c_tests[ yyvsp[-4] - 1 ]);

		    if ( !parse_test->t_valid ) {
			sprintf( msg_buf,
				"%s: %d: iops for invalid test (%d)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) yyvsp[-4] );
			ior_warn( parse_cfg, msg_buf );
		    } else {
			if ( yyvsp[-2] < 0 ) {
			    sprintf( msg_buf,
				    "Invalid iops target (%d) for test %d (ignored)",
				    (int) yyvsp[-2], (int)( yyvsp[-4] + 1 ));
			    ior_warn( parse_cfg, msg_buf );
			} else {
			    if ( parse_test->t_iops > 0 ) {
				sprintf( msg_buf, "IOPS for test %d previously set to %ld",
					(int)( yyvsp[-4] + 1 ), parse_test->t_iops );
				ior_debug( parse_cfg, msg_buf );
			    };
			    parse_test->t_iops = yyvsp[-2];
			};
		    };

		    ior_debug( parse_cfg, "parsed a valid iops" );
		};
	    }
#line 1731 "y.tab.c"
    break;

  case 16: /* dev_arg: IOR_L_ACCESS_KEY name  */
#line 428 "ior_pars.y"
            { cur_dev.d_access_key = (char *)((long) yyvsp[0]); cur_dev.d_is_s3 = 1; }
#line 1737 "y.tab.c"
    break;

  case 17: /* dev_arg: IOR_L_SECRET_KEY name  */
#line 430 "ior_pars.y"
            { cur_dev.d_secret_key = (char *)((long) yyvsp[0]); }
#line 1743 "y.tab.c"
    break;

  case 18: /* dev_arg: IOR_L_BUCKET name  */
#line 432 "ior_pars.y"
            { cur_dev.d_bucket = (char *)((long) yyvsp[0]); }
#line 1749 "y.tab.c"
    break;

  case 19: /* dev_arg: IOR_L_OFFSET size  */
#line 434 "ior_pars.y"
            { cur_dev.d_offset = yyvsp[0]; }
#line 1755 "y.tab.c"
    break;

  case 20: /* dev_arg: IOR_L_CAPACITY size  */
#line 436 "ior_pars.y"
            { cur_dev.d_capacity = yyvsp[0]; }
#line 1761 "y.tab.c"
    break;

  case 21: /* dev_arg: IOR_L_BLOCK IOR_L_SIZE size  */
#line 438 "ior_pars.y"
            { cur_dev.d_block_size = yyvsp[0]; }
#line 1767 "y.tab.c"
    break;

  case 22: /* dev_arg: IOR_L_BLOCK size  */
#line 440 "ior_pars.y"
            { cur_dev.d_block_size = yyvsp[0]; }
#line 1773 "y.tab.c"
    break;

  case 23: /* dev_arg: IOR_L_COUNT number  */
#line 442 "ior_pars.y"
            { cur_dev.d_count = yyvsp[0]; }
#line 1779 "y.tab.c"
    break;

  case 24: /* dev_arg: IOR_L_COPY number  */
#line 444 "ior_pars.y"
            { cur_dev.d_count = yyvsp[0]; }
#line 1785 "y.tab.c"
    break;

  case 25: /* dev_arg: IOR_L_READ  */
#line 446 "ior_pars.y"
            { cur_dev.d_read_only = 1; }
#line 1791 "y.tab.c"
    break;

  case 26: /* dev_arg: IOR_L_READ IOR_L_ONLY  */
#line 448 "ior_pars.y"
            { cur_dev.d_read_only = 1; }
#line 1797 "y.tab.c"
    break;

  case 27: /* dev_arg: IOR_L_TEMP  */
#line 450 "ior_pars.y"
            { cur_dev.d_is_temp = 1; }
#line 1803 "y.tab.c"
    break;

  case 28: /* dev_arg: IOR_L_CREATE  */
#line 452 "ior_pars.y"
            { cur_dev.d_create = 1; }
#line 1809 "y.tab.c"
    break;

  case 29: /* dev_arg: IOR_L_LOCK  */
#line 454 "ior_pars.y"
            { cur_dev.d_lock = 1; }
#line 1815 "y.tab.c"
    break;

  case 32: /* pat_arg: IOR_L_PUT  */
#line 462 "ior_pars.y"
            { cur_pat.p_is_s3 = 1; cur_pat.p_s3_mode = IOR_S3_PUT; cur_pat.p_read_pct = 0; }
#line 1821 "y.tab.c"
    break;

  case 33: /* pat_arg: IOR_L_GET  */
#line 464 "ior_pars.y"
            { cur_pat.p_is_s3 = 1; cur_pat.p_s3_mode = IOR_S3_GET; if (( !cur_pat.p_io_size_set ) && ( cur_pat.p_io_size < IOR_BLOCK_SIZE )) { cur_pat.p_io_size = 8 * 1024; } }
#line 1827 "y.tab.c"
    break;

  case 34: /* pat_arg: IOR_L_ENUM  */
#line 466 "ior_pars.y"
            { cur_pat.p_is_s3 = 1; cur_pat.p_s3_mode = IOR_S3_ENUM; cur_pat.p_is_unmap = 2; }
#line 1833 "y.tab.c"
    break;

  case 35: /* pat_arg: IOR_L_IO IOR_L_SIZE size  */
#line 468 "ior_pars.y"
            { cur_pat.p_io_size = yyvsp[0]; cur_pat.p_io_size_set = 1; }
#line 1839 "y.tab.c"
    break;

  case 36: /* pat_arg: IOR_L_META  */
#line 470 "ior_pars.y"
            { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = 3; }
#line 1845 "y.tab.c"
    break;

  case 37: /* pat_arg: IOR_L_STAT  */
#line 472 "ior_pars.y"
            { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = 0; }
#line 1851 "y.tab.c"
    break;

  case 38: /* pat_arg: IOR_L_OPENCLOSE  */
#line 474 "ior_pars.y"
            { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = 1; }
#line 1857 "y.tab.c"
    break;

  case 39: /* pat_arg: IOR_L_READDIR  */
#line 476 "ior_pars.y"
            { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = 2; }
#line 1863 "y.tab.c"
    break;

  case 40: /* pat_arg: IOR_L_MAXIMUM IOR_L_SEQUENTIAL number  */
#line 478 "ior_pars.y"
            { cur_pat.p_max_seq = yyvsp[0]; }
#line 1869 "y.tab.c"
    break;

  case 41: /* pat_arg: IOR_L_SEQUENTIAL number  */
#line 480 "ior_pars.y"
            { cur_pat.p_max_seq = yyvsp[0]; }
#line 1875 "y.tab.c"
    break;

  case 42: /* pat_arg: IOR_L_RANDOM  */
#line 482 "ior_pars.y"
            { cur_pat.p_is_seq = 0; }
#line 1881 "y.tab.c"
    break;

  case 43: /* pat_arg: IOR_L_SEQUENTIAL  */
#line 484 "ior_pars.y"
            { cur_pat.p_is_seq = 1; }
#line 1887 "y.tab.c"
    break;

  case 44: /* pat_arg: IOR_L_READ  */
#line 486 "ior_pars.y"
            { cur_pat.p_read_pct = 100; cur_pat.p_is_unmap = 0; }
#line 1893 "y.tab.c"
    break;

  case 45: /* pat_arg: IOR_L_READ pct  */
#line 488 "ior_pars.y"
            { cur_pat.p_read_pct = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); cur_pat.p_is_unmap = 0; }
#line 1899 "y.tab.c"
    break;

  case 46: /* pat_arg: IOR_L_WRITE  */
#line 490 "ior_pars.y"
            { cur_pat.p_read_pct = 0; cur_pat.p_is_unmap = 0; }
#line 1905 "y.tab.c"
    break;

  case 47: /* pat_arg: IOR_L_WRITE pct  */
#line 492 "ior_pars.y"
            { cur_pat.p_read_pct = (int)( 100.5 - ( yyvsp[0] / IOR_PCT_BASE )); cur_pat.p_is_unmap = 0; }
#line 1911 "y.tab.c"
    break;

  case 48: /* pat_arg: IOR_L_UNMAP  */
#line 494 "ior_pars.y"
            { cur_pat.p_is_unmap = 1; }
#line 1917 "y.tab.c"
    break;

  case 49: /* pat_arg: IOR_L_ZONE size  */
#line 496 "ior_pars.y"
            { cur_pat.p_local_size = yyvsp[0]; }
#line 1923 "y.tab.c"
    break;

  case 50: /* pat_arg: IOR_L_ZONE pct  */
#line 498 "ior_pars.y"
            { cur_pat.p_local_pct = ( yyvsp[0] / IOR_PCT_BASE ); }
#line 1929 "y.tab.c"
    break;

  case 51: /* pat_arg: IOR_L_COUNT number  */
#line 500 "ior_pars.y"
            { cur_pat.p_local_count = yyvsp[0]; }
#line 1935 "y.tab.c"
    break;

  case 52: /* pat_arg: IOR_L_LIMIT number  */
#line 502 "ior_pars.y"
            { cur_pat.p_local_limit = yyvsp[0]; }
#line 1941 "y.tab.c"
    break;

  case 53: /* pat_arg: IOR_L_REUSE pct  */
#line 504 "ior_pars.y"
            { cur_pat.p_reuse_pct = ( yyvsp[0] / IOR_PCT_BASE ); }
#line 1947 "y.tab.c"
    break;

  case 54: /* pat_arg: IOR_L_HISTORY number  */
#line 506 "ior_pars.y"
            { cur_pat.p_history = yyvsp[0]; }
#line 1953 "y.tab.c"
    break;

  case 55: /* pat_arg: IOR_L_FROM size  */
#line 508 "ior_pars.y"
            { cur_pat.p_start = yyvsp[0]; }
#line 1959 "y.tab.c"
    break;

  case 56: /* pat_arg: IOR_L_FROM pct  */
#line 510 "ior_pars.y"
            { cur_pat.p_start_pct = ( yyvsp[0] / IOR_PCT_BASE ); }
#line 1965 "y.tab.c"
    break;

  case 57: /* pat_arg: IOR_L_SIZE size  */
#line 512 "ior_pars.y"
            { cur_pat.p_size = yyvsp[0]; }
#line 1971 "y.tab.c"
    break;

  case 58: /* pat_arg: IOR_L_SIZE pct  */
#line 514 "ior_pars.y"
            { cur_pat.p_size_pct = ( yyvsp[0] / IOR_PCT_BASE ); }
#line 1977 "y.tab.c"
    break;

  case 62: /* test_arg: IOR_L_PAUSE time  */
#line 523 "ior_pars.y"
            { cur_test.t_pause = yyvsp[0]; }
#line 1983 "y.tab.c"
    break;

  case 63: /* test_arg: IOR_L_FOR time  */
#line 525 "ior_pars.y"
            { cur_test.t_duration = yyvsp[0]; }
#line 1989 "y.tab.c"
    break;

  case 64: /* test_arg: IOR_L_IGNORE time  */
#line 527 "ior_pars.y"
            { cur_test.t_ignore = yyvsp[0]; }
#line 1995 "y.tab.c"
    break;

  case 65: /* test_arg: number IOR_L_IOPS  */
#line 529 "ior_pars.y"
            { cur_test.t_iops = yyvsp[-1]; }
#line 2001 "y.tab.c"
    break;

  case 66: /* test_arg: IOR_L_FROM size  */
#line 531 "ior_pars.y"
            { cur_test.t_start = yyvsp[0]; }
#line 2007 "y.tab.c"
    break;

  case 67: /* test_arg: IOR_L_FROM pct  */
#line 533 "ior_pars.y"
            { cur_test.t_start_pct = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); }
#line 2013 "y.tab.c"
    break;

  case 68: /* test_arg: IOR_L_SIZE size  */
#line 535 "ior_pars.y"
            { cur_test.t_size = yyvsp[0]; }
#line 2019 "y.tab.c"
    break;

  case 69: /* test_arg: IOR_L_SIZE pct  */
#line 537 "ior_pars.y"
            { cur_test.t_size_pct = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); }
#line 2025 "y.tab.c"
    break;

  case 70: /* test_arg: IOR_L_SKEW pct  */
#line 539 "ior_pars.y"
            { cur_test.t_skew = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); }
#line 2031 "y.tab.c"
    break;

  case 71: /* test_arg: IOR_L_SEED number  */
#line 541 "ior_pars.y"
            { cur_test.t_seed = yyvsp[0]; }
#line 2037 "y.tab.c"
    break;

  case 72: /* test_arg: IOR_L_SHIFT pct  */
#line 543 "ior_pars.y"
            { cur_test.t_shift = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); }
#line 2043 "y.tab.c"
    break;

  case 73: /* test_arg: IOR_L_CORRELATE pct  */
#line 545 "ior_pars.y"
            { cur_test.t_correlate = (int)(( yyvsp[0] / IOR_PCT_BASE ) + 0.5 ); }
#line 2049 "y.tab.c"
    break;

  case 74: /* test_arg: IOR_L_AREA size  */
#line 547 "ior_pars.y"
            { cur_test.t_area = yyvsp[0]; }
#line 2055 "y.tab.c"
    break;

  case 75: /* pat_pct: pct IOR_L_PATTERN number comma  */
#line 551 "ior_pars.y"
            {
		yyvsp[-3] = (long int)(yyvsp[-3] / IOR_PCT_BASE);
		sprintf( msg_buf, "parsed PAT_PCT: %d%% pat %d",
			(int) yyvsp[-3], (int) yyvsp[-1] );
		ior_debug( parse_cfg, msg_buf );
		if (( yyvsp[-1] < 1 ) || ( yyvsp[-1] > IOR_MAX_PATTERNS )) {
		    sprintf( msg_buf,
			    "%s: %d: Invalid pattern number for %% (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) yyvsp[-1] );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    parse_cur_pat = yyvsp[-1] - 1;
		    if ( parse_pat_pct[ parse_cur_pat ] != 0 ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of %% for pattern %d (was %d)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) yyvsp[-1], parse_pat_pct[ yyvsp[-1] ]);
			ior_warn( parse_cfg, msg_buf );
		    };

		    parse_pat_pct[ parse_cur_pat ] = yyvsp[-3];
		};
	    }
#line 2084 "y.tab.c"
    break;

  case 76: /* time: expr  */
#line 578 "ior_pars.y"
            { yyval = yyvsp[0] / 1024L; }
#line 2090 "y.tab.c"
    break;

  case 77: /* size: expr  */
#line 582 "ior_pars.y"
            { yyval = yyvsp[0] / 1024L; }
#line 2096 "y.tab.c"
    break;

  case 78: /* pct: expr '%'  */
#line 587 "ior_pars.y"
            { yyval = yyvsp[-1] / 1024L * IOR_PCT_BASE; }
#line 2102 "y.tab.c"
    break;

  case 79: /* opt_number: number  */
#line 591 "ior_pars.y"
            { yyval = yyvsp[0]; }
#line 2108 "y.tab.c"
    break;

  case 80: /* opt_number: %empty  */
#line 593 "ior_pars.y"
            { yyval = -1; }
#line 2114 "y.tab.c"
    break;

  case 81: /* number: expr  */
#line 597 "ior_pars.y"
            { yyval = yyvsp[0] / 1024L; }
#line 2120 "y.tab.c"
    break;

  case 82: /* expr: IOR_L_NUMBER  */
#line 603 "ior_pars.y"
            { yyval = parse_cfg->c_l_value * 1024L ; }
#line 2126 "y.tab.c"
    break;

  case 83: /* expr: expr '+' expr  */
#line 606 "ior_pars.y"
            { yyval = yyvsp[-2] + yyvsp[0]; }
#line 2132 "y.tab.c"
    break;

  case 84: /* expr: expr '-' expr  */
#line 608 "ior_pars.y"
            { yyval = yyvsp[-2] - yyvsp[0]; }
#line 2138 "y.tab.c"
    break;

  case 85: /* expr: expr '*' expr  */
#line 610 "ior_pars.y"
            { yyval = yyvsp[-2] * yyvsp[0]; }
#line 2144 "y.tab.c"
    break;

  case 86: /* expr: expr '/' expr  */
#line 612 "ior_pars.y"
            { yyval = yyvsp[-2] / yyvsp[0]; }
#line 2150 "y.tab.c"
    break;

  case 87: /* expr: '(' expr ')'  */
#line 614 "ior_pars.y"
            { yyval = yyvsp[-1]; }
#line 2156 "y.tab.c"
    break;

  case 88: /* expr: expr IOR_L_KB  */
#line 620 "ior_pars.y"
            { yyval = yyvsp[-1] * 1024; }
#line 2162 "y.tab.c"
    break;

  case 89: /* expr: expr IOR_L_MB  */
#line 623 "ior_pars.y"
            { ior_n_size = yyvsp[-1] * 1024;
		    yyval = 1024 * ior_n_size; }
#line 2169 "y.tab.c"
    break;

  case 90: /* expr: expr IOR_L_GB  */
#line 627 "ior_pars.y"
            { ior_n_size = yyvsp[-1] * 1024;
		    yyval = 1024 * 1024 * ior_n_size; }
#line 2176 "y.tab.c"
    break;

  case 91: /* expr: expr IOR_L_TB  */
#line 631 "ior_pars.y"
            { ior_n_size = yyvsp[-1] * 1024;
		    ior_n_size *= 1024 * 1024;
		    yyval = 1024 * ior_n_size; }
#line 2184 "y.tab.c"
    break;

  case 92: /* expr: expr IOR_L_PB  */
#line 636 "ior_pars.y"
            { ior_n_size = yyvsp[-1] * 1024;
		    ior_n_size *= 1024 * 1024;
		    yyval = 1024 * 1024 * ior_n_size; }
#line 2192 "y.tab.c"
    break;

  case 93: /* expr: expr IOR_L_SECONDS  */
#line 642 "ior_pars.y"
            { yyval = yyvsp[-1]; }
#line 2198 "y.tab.c"
    break;

  case 94: /* expr: expr IOR_L_MINUTES  */
#line 645 "ior_pars.y"
            { yyval = yyvsp[-1] * 60; }
#line 2204 "y.tab.c"
    break;

  case 95: /* expr: expr IOR_L_HOURS  */
#line 648 "ior_pars.y"
            { yyval = yyvsp[-1] * 60 * 60; }
#line 2210 "y.tab.c"
    break;

  case 96: /* name: IOR_L_STRING  */
#line 652 "ior_pars.y"
            { yyval = (long) ior_strdup( parse_cfg, parse_cfg->c_l_str ); }
#line 2216 "y.tab.c"
    break;

  case 97: /* name: IOR_L_STRING_WITH_NEWLINE  */
#line 654 "ior_pars.y"
            {
		sprintf( msg_buf,
			"%s: %d: Invalid string (includes newline)",
			parse_cfg->c_l_name, parse_cfg->c_l_line );
		ior_error( parse_cfg, msg_buf );
		yyval = (long) ior_strdup( parse_cfg, "INVALID STRING" );
	    }
#line 2228 "y.tab.c"
    break;


#line 2232 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 667 "ior_pars.y"


#include <stdio.h>

extern FILE *yyin;

/*
 * ior_parse_prep - prepare to parse a file
 */
int	ior_parse_prep(ior_config *cfg, char *f_name )
/* ior_config	*cfg;			 our configuration */
/* char		*f_name;		 name of file we will use */
{
    int		result;			/* final return code */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0;				/* all OK so far */

    sprintf( msg_buf, "Beginning parse of file '%s'", f_name );
    ior_debug( cfg, msg_buf );

    cfg->c_l_name = f_name;
    cfg->c_l_line = 1;

    parse_cfg = cfg;			/* remember the config we are in */

    result = ior_lex_prep( cfg );	/* prepare lexical analyzer */
    if ( result ) {
	return( result );
    };
					/* open file for reading */
    if (( yyin = fopen( f_name, "r" )) == NULL ) {
	perror( f_name );
	sprintf( msg_buf, "Unable to open information file '%s'",
		f_name );
	ior_error( cfg, msg_buf );

	result = -1;
    };

    ior_parse_dev_clear( cfg );		/* clear device info */
    ior_parse_pat_clear( cfg );		/* clear pattern info */
    ior_parse_test_clear( cfg );	/* clear test info */

    return( result );
}

/*
 * ior_parse_dev_clear - clear out device read area
 */
int	ior_parse_dev_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_dev, '\0', sizeof( ior_device ));

    cur_dev.d_offset = IOR_MIN_POS;	/* default to min. offset */
    cur_dev.d_block_size = IOR_BLOCK_SIZE; /* default to min. block size */
    cur_dev.d_count = 1;		/* only one copy */

    return( result );
}

/*
 * ior_parse_pat_clear - clear out pattern read area
 */
int	ior_parse_pat_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_pat, '\0', sizeof( ior_pattern ));

    cur_pat.p_start = -1;		/* clear all sizes */
    cur_pat.p_size = -1;
    cur_pat.p_start_pct = -1;		/* clear all percents */
    cur_pat.p_size_pct = -1;
    cur_pat.p_local_size = -1;
    cur_pat.p_local_pct = -1;
    cur_pat.p_local_count = -1;
    cur_pat.p_local_limit = -1;
    cur_pat.p_history = -1;
    cur_pat.p_reuse_pct = -1;
    cur_pat.p_reuse_pct = -1;
    cur_pat.p_io_size_set = 0;

    cur_pat.p_read_pct = 100;		/* default is all reads */
    cur_pat.p_is_seq = 1;		/* default is sequential */
    cur_pat.p_is_meta = 0;		/* default is not metadata */
    cur_pat.p_meta_mode = 0;		/* default meta mode */

    return( result );
}

/*
 * ior_parse_test_clear - clear out test read area
 */
int	ior_parse_test_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_test, '\0', sizeof( ior_test ));

    cur_test.t_start = -1;
    cur_test.t_start_pct = -1;
    cur_test.t_size = -1;
    cur_test.t_size_pct = -1;

    cur_test.t_skew = -1;		/* no skew, by default */
    cur_test.t_seed = IOR_SKEW_SEED;	/* skew seed for randomization */
    cur_test.t_shift = 0;		/* skew is not shifted */
    cur_test.t_correlate = 50;		/* default correlation */
    cur_test.t_area = 4 * 1024 * 1024;	/* default area of 4 MB */

					/* clear pattern percentages */
    for ( parse_cur_pat = 0; parse_cur_pat < IOR_MAX_PATTERNS;
	    parse_cur_pat++ ) {
	parse_pat_pct[ parse_cur_pat ] = 0;
    };

    return( result );
}


/*
 * ior_parse_done - finished parsing the file
 */
int	ior_parse_done( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    sprintf( msg_buf, "Completed parse of file '%s'",
	    cfg->c_l_name );
    ior_debug( cfg, msg_buf );

    parse_cfg = NULL;

    result = ior_lex_done( cfg );

    return( result );
}


/*
 * yyerr_show - show the location of the error we have seen
 *
 *  The trick is to expand any tabs to spaces for alignment
 */
void	yyerr_show( ior_config *cfg )
{
    char	*src;
    char	*tgt;
    int		pos;
    int		tab_chars;

					/* print current line */
    tgt = msg_buf;
    pos = 0;
    tab_chars = 0;
    src = cfg->c_l_cur_txt;
    while (( *src != '\0' ) &&
	    ( *src != '\n' )){

	if ( *src == '\t' ) {		/* expand tabs */
	    do {
		*( tgt++ ) = ' ';
		pos++;
		tab_chars++;
	    } while ( pos % 8 != 0 );
	    tab_chars--;		/* really one less */
	    src++;
	} else {			/* copy others */
	    *( tgt++ ) = *( src++ );
	    pos++;
	};
    };
    *tgt = '\0';			/* end the string */
    ior_msg( cfg, NULL, msg_buf );

					/* point to error */
    sprintf( msg_buf, "%*s^",
	    cfg->c_l_cur_pos + tab_chars - 1, "" );
    ior_msg( cfg, NULL, msg_buf );
};

/*
 * yyerror - clear up an error in the input
 */
int	yyerror( char *s )
{
    if ( feof( yyin )) {		/* on EOF, stop reading */
	sprintf( msg_buf, "%s: line %d: end of file",
		parse_cfg->c_l_name, parse_cfg->c_l_line );
	ior_error( parse_cfg, msg_buf );

    } else if ( parse_cfg->c_l_error[ 0 ]) { /* give LEX error */

			/* print current line & point to error */
	yyerr_show( parse_cfg );
					/* print error */
	sprintf( msg_buf, "%s: line %d: %s",
		parse_cfg->c_l_name, parse_cfg->c_l_line,
		parse_cfg->c_l_error );
	ior_error( parse_cfg, msg_buf );
	parse_cfg->c_l_error[ 0 ] = '\0'; /* drop error now */

    } else {				/* otherwise, give the error */

			/* print current line & point to error */
	yyerr_show( parse_cfg );
					/* print error */
	sprintf( msg_buf, "%s: line %d: %s",
		parse_cfg->c_l_name, parse_cfg->c_l_line, s );
	ior_error( parse_cfg, msg_buf );
    };

    return( 0 );			/* all OK */
}

