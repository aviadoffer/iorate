%{
/**************************************************************************
 *
 * Yes, the shift/reduce errors from YACC/bison are expected.  It comes
 * from allowing flexible formulas to be used for number data entry, rather
 * than fixed input syntax.  This is a desired result.
 *
 *************************************************************************/

/**************************************************************************
 *
 *  ior_pars.y - the parser for iorate
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_pars.y,v 3.7 2011/11/03 11:13:29 westiv Exp westiv $";

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include "iorate.h"


#define	IOR_PCT_BASE	10000.0		/* we pass HUGE, so add some digits */

static ior_config *parse_cfg;		/* config we are parsing for */
static ior_device *parse_dev;		/* device we have parsed */
static ior_device cur_dev;		/* device we are parsing */
static ior_pattern *parse_pat;		/* pattern we have parsed */
static ior_pattern cur_pat;		/* pattern we are parsing */
static ior_test	*parse_test;		/* test we have successfully parsed */
static ior_test	cur_test;		/* test we are parsing */
static int parse_cur_pat;		/* current pattern */
static int parse_pat_pct[ IOR_MAX_PATTERNS + 2 ]; /* pattern allocation in 0.1% units */
static HUGE ior_n_size;			/* size we read */
static char *name;			/* name of our item */

extern int yyerror( char *s );

%}

%start	config				/* items to start looking for */

/* the differnt tokens we accept */
/* NOTE: single character tokens are simply passed as that character */

%token	IOR_L_NUMBER			/* found a number */
%token	IOR_L_STRING			/* found a string */
%token	IOR_L_STRING_WITH_NEWLINE	/* found bad string - not closed */
%token	IOR_L_KB
%token	IOR_L_MB
%token	IOR_L_GB
%token	IOR_L_TB
%token	IOR_L_PB
%token	IOR_L_SECONDS
%token	IOR_L_MINUTES
%token	IOR_L_HOURS
%token	IOR_L_DEVICE
%token	IOR_L_PATTERN
%token	IOR_L_TEST
%token	IOR_L_SEQUENTIAL
%token	IOR_L_RANDOM
%token	IOR_L_CAPACITY
%token	IOR_L_MAXIMUM
%token	IOR_L_IGNORE
%token	IOR_L_OFFSET
%token  IOR_L_BLOCK
%token  IOR_L_ACCESS_KEY
%token  IOR_L_SECRET_KEY
%token  IOR_L_BUCKET
%token  IOR_L_PUT
%token  IOR_L_GET
%token  IOR_L_ENUM
%token	IOR_L_IOPS
%token	IOR_L_WRITE
%token	IOR_L_READ
%token	IOR_L_UNMAP
%token	IOR_L_BLOCKING
%token	IOR_L_SIZE
%token	IOR_L_PAUSE
%token	IOR_L_FROM
%token	IOR_L_FOR
%token	IOR_L_IO
%token	IOR_L_TARGET
%token	IOR_L_AT
%token	IOR_L_ONLY
%token	IOR_L_TEMP
%token	IOR_L_CREATE
%token	IOR_L_LOCK
%token	IOR_L_ZONE
%token	IOR_L_HISTORY
%token	IOR_L_REUSE
%token	IOR_L_COUNT
%token	IOR_L_LIMIT
%token	IOR_L_COPY
%token	IOR_L_SKEW
%token	IOR_L_SEED
%token	IOR_L_CORRELATE
%token	IOR_L_AREA
%token	IOR_L_SHIFT
%token	IOR_L_META
%token	IOR_L_STAT
%token	IOR_L_OPENCLOSE
%token	IOR_L_READDIR
%token	IOR_L_FILECREATE
%token	IOR_L_UNKNOWN


/* the precedence of our operators, in increasing order */
%left	'=' '%' '@' ','
%left	'+' '-'
%left	'*' '/'
%left	'(' ')'
%left	';'

/* NOTE: CAP is used here, allowing separate precedence for */
/* capacity adjustments - see below for details */
%left	CAPACITY			/* second is capacity */

/* supress errors if we EXACTLY match this number of shift/reduce */
/* conflicts, which are needed to generate the grammar correctly */
/*   Since this is not universally supported, it is commented out */
/* %expect	28  */

%%

config	:	file_lines		/* a valid file */
	    { ior_debug( parse_cfg, "parsed a valid config" );
	    return( 0 ); }
	;

file_lines :	file_line		/* a single line */
	|	file_lines file_line	/* or many */
	;

file_line :	dev_line		/* a device line */
	|	pat_line		/* a pattern line */
	|	test_line		/* a test line */
	|	iops_line		/* an iops line */
	|	error ';'		/* bad line - trash it */
	    {
		ior_parse_dev_clear( parse_cfg ); /* clean up any input */
		ior_parse_pat_clear( parse_cfg );
		ior_parse_test_clear( parse_cfg );
		yyerrok;
	    }
	;

dev_line :	IOR_L_DEVICE opt_number '=' name dev_args ';'
	    {
		name = (char *)((long)( $4 ));
		sprintf( msg_buf, "parsed DEV: %d = %s %dk %dk %dk",
			(int) $2, name,
			(int)( cur_dev.d_offset / 1024 ),
			(int)( cur_dev.d_capacity / 1024 ),
			(int)( cur_dev.d_block_size / 1024 ));
		ior_debug( parse_cfg, msg_buf );

		if ( $2 == -1 ) {	/* create a device ID */
		    $2 = ++parse_cfg->c_ndev;
		};

		if (( $2 < 1 ) || ( $2 > IOR_MAX_DEVICES )) {
		    sprintf( msg_buf, "%s: %d: Invalid device number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) $2 );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_ndev < $2 ) {
			parse_cfg->c_ndev = $2;
		    };

		    parse_dev = &( parse_cfg->c_devs[ $2 - 1 ]);

		    if ( parse_dev->d_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of device %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) $2, parse_dev->d_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_dev->d_name );
		    };

		    parse_dev->d_name = name;
		    parse_dev->d_valid = 1; /* mark as valid */

		    parse_dev->d_offset = cur_dev.d_offset;
		    parse_dev->d_capacity = cur_dev.d_capacity;
		    parse_dev->d_block_size = cur_dev.d_block_size;
		    parse_dev->d_is_async = cur_dev.d_is_async;
		    parse_dev->d_read_only = cur_dev.d_read_only;
		    parse_dev->d_is_temp = cur_dev.d_is_temp;
		    parse_dev->d_create = cur_dev.d_create;
		    parse_dev->d_lock = cur_dev.d_lock;
		    parse_dev->d_count = cur_dev.d_count;
                    parse_dev->d_fid = -1;
                    parse_dev->d_is_s3 = cur_dev.d_is_s3;
                    parse_dev->d_access_key = cur_dev.d_access_key;
                    parse_dev->d_secret_key = cur_dev.d_secret_key;
                    parse_dev->d_bucket = cur_dev.d_bucket;

                    ior_debug( parse_cfg, "parsed a valid device" );
		};
					/* clear out parsing data area */
		ior_parse_dev_clear( parse_cfg );
	    }
	;


pat_line :	IOR_L_PATTERN number '=' name pat_args ';'
	    {
		name = (char *)((long)( $4 ));
		sprintf( msg_buf,
			"parsed PAT: %d = %s %dK %d %d %d%% %dK %d%% %dK %d%% %dK %d%% %d %d %d %d%%",
			(int) $2, name,
			(int)( cur_pat.p_io_size / 1024 ),
			(int) cur_pat.p_max_seq,
			(int) cur_pat.p_is_seq,
			(int) cur_pat.p_read_pct,
			(int)( cur_pat.p_start / 1024 ),
			(int) cur_pat.p_start_pct,
			(int)( cur_pat.p_size / 1024 ),
			(int) cur_pat.p_size_pct,
		    	(int)( cur_pat.p_local_size / 1024 ),
		    	(int) cur_pat.p_local_pct,
		    	(int) cur_pat.p_local_count,
		    	(int) cur_pat.p_local_limit,
		    	(int) cur_pat.p_history,
		    	(int) cur_pat.p_reuse_pct );
		ior_debug( parse_cfg, msg_buf );
		if (( $2 < 1 ) || ( $2 > IOR_MAX_PATTERNS )) {
		    sprintf( msg_buf, "%s: %d: Invalid pattern number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) $2 );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_npat < $2 ) {
			parse_cfg->c_npat = $2;
		    };

		    parse_pat = &( parse_cfg->c_pats[ $2 - 1 ]);

		    if ( parse_pat->p_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of pattern %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) $2, parse_pat->p_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_pat->p_name );
		    };

		    parse_pat->p_name = name;
		    parse_pat->p_end = -1; /* know where the end is */
		    parse_pat->p_valid = 1; /* mark as valid */

		    parse_pat->p_io_size = cur_pat.p_io_size;
		    parse_pat->p_io_size_set = cur_pat.p_io_size_set;
		    parse_pat->p_max_seq = cur_pat.p_max_seq;
		    parse_pat->p_is_seq = cur_pat.p_is_seq;
		    parse_pat->p_read_pct = cur_pat.p_read_pct;
		    parse_pat->p_is_blocking = cur_pat.p_is_blocking;
		    parse_pat->p_is_unmap = cur_pat.p_is_unmap;
		    parse_pat->p_start = cur_pat.p_start;
		    parse_pat->p_start_pct = cur_pat.p_start_pct;
		    parse_pat->p_size = cur_pat.p_size;
		    parse_pat->p_size_pct = cur_pat.p_size_pct;
		    parse_pat->p_local_size = cur_pat.p_local_size;
		    parse_pat->p_local_pct = cur_pat.p_local_pct;
		    parse_pat->p_local_count = cur_pat.p_local_count;
		    parse_pat->p_local_limit = cur_pat.p_local_limit;
		    parse_pat->p_history = cur_pat.p_history;
		    parse_pat->p_reuse_pct = cur_pat.p_reuse_pct;
		    parse_pat->p_is_s3 = cur_pat.p_is_s3;
		    parse_pat->p_s3_mode = cur_pat.p_s3_mode;
		    parse_pat->p_is_meta = cur_pat.p_is_meta;
		    parse_pat->p_meta_mode = cur_pat.p_meta_mode;

		    ior_debug( parse_cfg, "parsed a valid pattern" );
		};
					/* clear out parsing data area */
		ior_parse_pat_clear( parse_cfg );
	    }
	;

test_line :	IOR_L_TEST opt_number '=' name test_args ';'
	    {
		name = (char *)((long)( $4 ));
		sprintf( msg_buf, "parsed TEST: %d = %s %d %d %d %d %dk %dk",
			(int) $2, name,
			(int) cur_test.t_pause,
			(int) cur_test.t_duration,
			(int) cur_test.t_ignore,
			(int) cur_test.t_iops,
			(int)( cur_test.t_start / 1024 ),
			(int)( cur_test.t_size / 1024 ));
		ior_debug( parse_cfg, msg_buf );
		sprintf( msg_buf, "    TEST : skew %d%%, seed %d, shift %d%%, cor %d%%, area %dk",
			(int) cur_test.t_skew,
			(int) cur_test.t_seed,
			(int) cur_test.t_shift,
			(int) cur_test.t_correlate,
			(int)( cur_test.t_area / 1024 ));
		ior_debug( parse_cfg, msg_buf );

		if ( $2 == -1 ) {	/* create a test ID */
		    $2 = ++parse_cfg->c_ntest;
		};

		if (( $2 < 1 ) || ( $2 > IOR_MAX_TESTS )) {
		    sprintf( msg_buf, "%s: %d: Invalid test number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) $2 );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    if ( parse_cfg->c_ntest < $2 ) {
			parse_cfg->c_ntest = $2;
		    };

		    parse_test = &( parse_cfg->c_tests[ $2 - 1 ]);

		    if ( parse_test->t_valid ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of test %d (was %s)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) $2, parse_test->t_name );
			ior_warn( parse_cfg, msg_buf );
			free( parse_test->t_name );
		    };

		    parse_test->t_name = name;
		    parse_test->t_valid = 1; /* mark as valid */

		    parse_test->t_pause = cur_test.t_pause;
		    parse_test->t_duration = cur_test.t_duration;
		    parse_test->t_ignore = cur_test.t_ignore;
		    parse_test->t_iops = cur_test.t_iops;
		    parse_test->t_start = cur_test.t_start;
		    parse_test->t_start_pct = cur_test.t_start_pct;
		    parse_test->t_size = cur_test.t_size;
		    parse_test->t_size_pct = cur_test.t_size_pct;

		    parse_test->t_skew = cur_test.t_skew;
		    parse_test->t_seed = cur_test.t_seed;
		    parse_test->t_shift = cur_test.t_shift;
		    parse_test->t_correlate = cur_test.t_correlate;
		    parse_test->t_area = cur_test.t_area;

					/* save pattern percentages */
		    for ( parse_cur_pat = 0;
			    parse_cur_pat < IOR_MAX_PATTERNS;
			    parse_cur_pat++ ) {

					/* save current pattern percent */
			parse_test->t_pat_pct[ parse_cur_pat ] =
				parse_pat_pct[ parse_cur_pat ];
		    };

		    ior_debug( parse_cfg, "parsed a valid test" );
		};

					/* clear out parsing data area */
		ior_parse_test_clear( parse_cfg );
	    }
	;

iops_line :	IOR_L_TARGET IOR_L_TEST number IOR_L_AT number IOR_L_IOPS ';'
	    {
		sprintf( msg_buf, "parsed IOPS: Test %d @ %d",
			(int) $3, (int) $5 );
		ior_debug( parse_cfg, msg_buf );
		if (( $3 < 1 ) || ( $3 > IOR_MAX_TESTS )) {
		    sprintf( msg_buf, "%s: %d: Invalid test number (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) $3 );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    parse_test = &( parse_cfg->c_tests[ $3 - 1 ]);

		    if ( !parse_test->t_valid ) {
			sprintf( msg_buf,
				"%s: %d: iops for invalid test (%d)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) $3 );
			ior_warn( parse_cfg, msg_buf );
		    } else {
			if ( $5 < 0 ) {
			    sprintf( msg_buf,
				    "Invalid iops target (%d) for test %d (ignored)",
				    (int) $5, (int)( $3 + 1 ));
			    ior_warn( parse_cfg, msg_buf );
			} else {
			    if ( parse_test->t_iops > 0 ) {
				sprintf( msg_buf, "IOPS for test %d previously set to %ld",
					(int)( $3 + 1 ), parse_test->t_iops );
				ior_debug( parse_cfg, msg_buf );
			    };
			    parse_test->t_iops = $5;
			};
		    };

		    ior_debug( parse_cfg, "parsed a valid iops" );
		};
	    }
	;

dev_args :	dev_args dev_arg	/* multiple arguments */
	|				/* ends when no more */
	;

dev_arg :  IOR_L_ACCESS_KEY name
            { cur_dev.d_access_key = (char *)((long) $2); cur_dev.d_is_s3 = 1; }
        |       IOR_L_SECRET_KEY name
            { cur_dev.d_secret_key = (char *)((long) $2); }
        |       IOR_L_BUCKET name
            { cur_dev.d_bucket = (char *)((long) $2); }
        |       IOR_L_OFFSET size
	    { cur_dev.d_offset = $2; }
	|	IOR_L_CAPACITY size
	    { cur_dev.d_capacity = $2; }
	|	IOR_L_BLOCK IOR_L_SIZE size
	    { cur_dev.d_block_size = $3; }
	|	IOR_L_BLOCK size
	    { cur_dev.d_block_size = $2; }
	|	IOR_L_COUNT number	/* number of copies to test */
	    { cur_dev.d_count = $2; }
	|	IOR_L_COPY number	/* number of copies to test */
	    { cur_dev.d_count = $2; }
	|	IOR_L_READ
	    { cur_dev.d_read_only = 1; }
	|	IOR_L_READ IOR_L_ONLY
	    { cur_dev.d_read_only = 1; }
	|	IOR_L_TEMP
	    { cur_dev.d_is_temp = 1; }
	|	IOR_L_CREATE
	    { cur_dev.d_create = 1; }
	|	IOR_L_LOCK
	    { cur_dev.d_lock = 1; }
	;

pat_args :	pat_args pat_arg	/* multiple arguments */
	|				/* ends when no more */
	;

pat_arg :   IOR_L_PUT
            { cur_pat.p_is_s3 = 1; cur_pat.p_s3_mode = IOR_S3_PUT; cur_pat.p_read_pct = 0; }
        |       IOR_L_GET
			{
				cur_pat.p_is_s3 = 1;
				cur_pat.p_s3_mode = IOR_S3_GET;
				if (( !cur_pat.p_io_size_set ) && ( cur_pat.p_io_size < IOR_BLOCK_SIZE )) {
					cur_pat.p_io_size = 8 * 1024;
				}
			}
        |       IOR_L_ENUM
			{
				cur_pat.p_is_s3 = 1;
				cur_pat.p_s3_mode = IOR_S3_ENUM;
				cur_pat.p_is_unmap = 2;
				if ( cur_pat.p_io_size < IOR_BLOCK_SIZE ) {
					cur_pat.p_io_size = 8 * 1024;
				}
			}
        |       IOR_L_IO IOR_L_SIZE size /* size of I/Os */
	    { cur_pat.p_io_size = $3; cur_pat.p_io_size_set = 1; }
	|	IOR_L_META		/* metadata mix mode */
	    { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = IOR_META_MIX; }
	|   IOR_L_STAT		/* metadata stat mode */
	    { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = IOR_META_STAT; }
	|   IOR_L_OPENCLOSE	/* metadata open/close mode */
	    { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = IOR_META_OPENCLOSE; }
	|   IOR_L_READDIR	/* metadata readdir mode */
	    { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = IOR_META_READDIR; }
	|   IOR_L_FILECREATE	/* metadata filecreate mode: create new file and write io_size bytes */
	    { cur_pat.p_is_meta = 1; cur_pat.p_meta_mode = IOR_META_FILECREATE; }
	|	IOR_L_MAXIMUM IOR_L_SEQUENTIAL number  /* max seq I/Os */
	    { cur_pat.p_max_seq = $3; }
	|	IOR_L_SEQUENTIAL number	/* max seq I/Os */
	    { cur_pat.p_max_seq = $2; }
	|	IOR_L_RANDOM		/* I/O is random */
	    { cur_pat.p_is_seq = 0; }
	|	IOR_L_BLOCKING		/* publish positions for later blocking I/O */
	    { cur_pat.p_is_blocking = 1; }
	|	IOR_L_SEQUENTIAL	/* I/O is sequnetial */
	    { cur_pat.p_is_seq = 1; }
	|	IOR_L_READ		/* do all reads */
	    { cur_pat.p_read_pct = 100; cur_pat.p_is_unmap = 0; }
	|	IOR_L_READ pct		/* do some reads */
	    { cur_pat.p_read_pct = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); cur_pat.p_is_unmap = 0; }
	|	IOR_L_WRITE		/* do all writes */
	    { cur_pat.p_read_pct = 0; cur_pat.p_is_unmap = 0; }
	|	IOR_L_WRITE pct		/* do some writes */
	    { cur_pat.p_read_pct = (int)( 100.5 - ( $2 / IOR_PCT_BASE )); cur_pat.p_is_unmap = 0; }
	|	IOR_L_UNMAP		/* do all unmaps/discards */
	    { cur_pat.p_is_unmap = 1; }
	|	IOR_L_ZONE size		/* locality size */
	    { cur_pat.p_local_size = $2; }
	|	IOR_L_ZONE pct		/* locality size as % */
	    { cur_pat.p_local_pct = ( $2 / IOR_PCT_BASE ); }
	|	IOR_L_COUNT number	/* number of localities */
	    { cur_pat.p_local_count = $2; }
	|	IOR_L_LIMIT number	/* limit on local I/Os */
	    { cur_pat.p_local_limit = $2; }
	|	IOR_L_REUSE pct		/* reuse - I/O hits */
	    { cur_pat.p_reuse_pct = ( $2 / IOR_PCT_BASE ); }
	|	IOR_L_HISTORY number	/* number of I/Os of history */
	    { cur_pat.p_history = $2; }
	|	IOR_L_FROM size		/* location to start from */
	    { cur_pat.p_start = $2; }
	|	IOR_L_FROM pct		/* location to start from as % */
	    { cur_pat.p_start_pct = ( $2 / IOR_PCT_BASE ); }
	|	IOR_L_SIZE size		/* size to test over */
	    { cur_pat.p_size = $2; }
	|	IOR_L_SIZE pct		/* size to test over as % */
	    { cur_pat.p_size_pct = ( $2 / IOR_PCT_BASE ); }
	;

test_args :	test_args test_arg	/* multiple arguments */
	|				/* ends when no more */
	;

test_arg :	pat_pct
	|	IOR_L_PAUSE time	/* time to wait before test starts */
	    { cur_test.t_pause = $2; }
	|	IOR_L_FOR time		/* time to run test for */
	    { cur_test.t_duration = $2; }
	|	IOR_L_IGNORE time	/* time not to measure */
	    { cur_test.t_ignore = $2; }
	|	number IOR_L_IOPS	/* maximum I/Os per second for test */
	    { cur_test.t_iops = $1; }
	|	IOR_L_FROM size		/* location to start from */
	    { cur_test.t_start = $2; }
	|	IOR_L_FROM pct		/* start location as % */
	    { cur_test.t_start_pct = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); }
	|	IOR_L_SIZE size		/* size to test over */
	    { cur_test.t_size = $2; }
	|	IOR_L_SIZE pct		/* size to test as % */
	    { cur_test.t_size_pct = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); }
	|	IOR_L_SKEW pct		/* sub-LUN skew level as % */
	    { cur_test.t_skew = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); }
	|	IOR_L_SEED number	/* seed for skew randomization */
	    { cur_test.t_seed = $2; }
	|	IOR_L_SHIFT pct		/* areas to shift in skew as % */
	    { cur_test.t_shift = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); }
	|	IOR_L_CORRELATE pct	/* are hot areas skewed together? */
	    { cur_test.t_correlate = (int)(( $2 / IOR_PCT_BASE ) + 0.5 ); }
	|	IOR_L_AREA size		/* size of each skew area */
	    { cur_test.t_area = $2; }
	;

pat_pct	:	pct IOR_L_PATTERN number comma
	    {
		$1 = (long int)(((double)$1 * IOR_TEST_PCT_SCALE / IOR_PCT_BASE ) + 0.5);
		sprintf( msg_buf, "parsed PAT_PCT: %.1f%% pat %d",
			(double) $1 / IOR_TEST_PCT_SCALE, (int) $3 );
		ior_debug( parse_cfg, msg_buf );
		if (( $3 < 1 ) || ( $3 > IOR_MAX_PATTERNS )) {
		    sprintf( msg_buf,
			    "%s: %d: Invalid pattern number for %% (%d)",
			    parse_cfg->c_l_name, parse_cfg->c_l_line,
			    (int) $3 );
		    ior_error( parse_cfg, msg_buf );
		} else {
		    parse_cur_pat = $3 - 1;
		    if ( parse_pat_pct[ parse_cur_pat ] != 0 ) {
			sprintf( msg_buf,
				"%s: %d: Redefinition of %% for pattern %d (was %.1f%%)",
				parse_cfg->c_l_name, parse_cfg->c_l_line,
				(int) $3,
				(double) parse_pat_pct[ parse_cur_pat ] / IOR_TEST_PCT_SCALE);
			ior_warn( parse_cfg, msg_buf );
		    };

		    parse_pat_pct[ parse_cur_pat ] = $1;
		};
	    }
	;

time	:	expr			/* a valid number */
	    { $$ = $1 / 1024L; }
	;

size	:	expr			/* a valid number */
	    { $$ = $1 / 1024L; }
	;


pct	:	expr '%'		/* number as percentage */
	    { $$ = (long int)(((double)$1 / 1024.0 * IOR_PCT_BASE ) + 0.5); }
	;

opt_number :	number			/* optional number */
	    { $$ = $1; }
	|
	    { $$ = -1; }
	;

number	:	expr			/* a valid number */
	    { $$ = $1 / 1024L; }
	;

    /* NOTE: negative numbers are excluded by design;		*/
    /*       there should not be any used in these programs	*/
expr	:	IOR_L_NUMBER		/* a float */
	    { $$ = parse_cfg->c_l_value * 1024L ; }

	|	expr '+' expr		/* addition */
	    { $$ = $1 + $3; }
	|	expr '-' expr		/* subtraction */
	    { $$ = $1 - $3; }
	|	expr '*' expr		/* multiplication */
	    { $$ = $1 * $3; }
	|	expr '/' expr		/* division */
	    { $$ = $1 / $3; }
	|	'(' expr ')'		/* a parenthetic expression */
	    { $$ = $2; }

		/**** this forces a clean multiple of 1024 ****/
		/**** outputs will thus match inputs       ****/
					/* Kilobyte size */
	|	expr IOR_L_KB	%prec CAPACITY
	    { $$ = $1 * 1024; }
					/* Megabyte size */
	|	expr IOR_L_MB	%prec CAPACITY
	    { ior_n_size = $1 * 1024;
		    $$ = 1024 * ior_n_size; }
					/* Gigabyte size */
	|	expr IOR_L_GB	%prec CAPACITY
	    { ior_n_size = $1 * 1024;
		    $$ = 1024 * 1024 * ior_n_size; }
					/* Terabyte size */
	|	expr IOR_L_TB	%prec CAPACITY
	    { ior_n_size = $1 * 1024;
		    ior_n_size *= 1024 * 1024;
		    $$ = 1024 * ior_n_size; }
					/* Petabyte size */
	|	expr IOR_L_PB	%prec CAPACITY
	    { ior_n_size = $1 * 1024;
		    ior_n_size *= 1024 * 1024;
		    $$ = 1024 * 1024 * ior_n_size; }

					/* time in seconds */
	|	expr IOR_L_SECONDS  %prec CAPACITY
	    { $$ = $1; }
					/* time in minutes */
	|	expr IOR_L_MINUTES  %prec CAPACITY
	    { $$ = $1 * 60; }
					/* time in hours */
	|	expr IOR_L_HOURS    %prec CAPACITY
	    { $$ = $1 * 60 * 60; }
	;

name	:	IOR_L_STRING		/* a valid string/name */
	    { $$ = (long) ior_strdup( parse_cfg, parse_cfg->c_l_str ); }
	|	IOR_L_STRING_WITH_NEWLINE  /* a string with an error */
	    {
		sprintf( msg_buf,
			"%s: %d: Invalid string (includes newline)",
			parse_cfg->c_l_name, parse_cfg->c_l_line );
		ior_error( parse_cfg, msg_buf );
		$$ = (long) ior_strdup( parse_cfg, "INVALID STRING" );
	    }
	;

comma	:	/* empty */		/* comma is optional */
	|	','
	;

%%

#include <stdio.h>

extern FILE *yyin;

/*
 * ior_parse_prep - prepare to parse a file
 */
int	ior_parse_prep(ior_config *cfg, char *f_name )
/* ior_config	*cfg;			 our configuration */
/* char		*f_name;		 name of file we will use */
{
    int		result;			/* final return code */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0;				/* all OK so far */

    sprintf( msg_buf, "Beginning parse of file '%s'", f_name );
    ior_debug( cfg, msg_buf );

    cfg->c_l_name = f_name;
    cfg->c_l_line = 1;

    parse_cfg = cfg;			/* remember the config we are in */

    result = ior_lex_prep( cfg );	/* prepare lexical analyzer */
    if ( result ) {
	return( result );
    };
					/* open file for reading */
    if (( yyin = fopen( f_name, "r" )) == NULL ) {
	perror( f_name );
	sprintf( msg_buf, "Unable to open information file '%s'",
		f_name );
	ior_error( cfg, msg_buf );

	result = -1;
    };

    ior_parse_dev_clear( cfg );		/* clear device info */
    ior_parse_pat_clear( cfg );		/* clear pattern info */
    ior_parse_test_clear( cfg );	/* clear test info */

    return( result );
}

/*
 * ior_parse_dev_clear - clear out device read area
 */
int	ior_parse_dev_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_dev, '\0', sizeof( ior_device ));

    cur_dev.d_offset = IOR_MIN_POS;	/* default to min. offset */
    cur_dev.d_block_size = IOR_BLOCK_SIZE; /* default to min. block size */
    cur_dev.d_count = 1;		/* only one copy */

    return( result );
}

/*
 * ior_parse_pat_clear - clear out pattern read area
 */
int	ior_parse_pat_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_pat, '\0', sizeof( ior_pattern ));

    cur_pat.p_start = -1;		/* clear all sizes */
    cur_pat.p_size = -1;
    cur_pat.p_start_pct = -1;		/* clear all percents */
    cur_pat.p_size_pct = -1;
    cur_pat.p_local_size = -1;
    cur_pat.p_local_pct = -1;
    cur_pat.p_local_count = -1;
    cur_pat.p_local_limit = -1;
    cur_pat.p_history = -1;
    cur_pat.p_reuse_pct = -1;
    cur_pat.p_reuse_pct = -1;
	cur_pat.p_io_size_set = 0;

    cur_pat.p_read_pct = 100;		/* default is all reads */
    cur_pat.p_is_seq = 1;		/* default is sequential */
	cur_pat.p_is_blocking = 0;		/* default is non-blocking */
    cur_pat.p_is_meta = 0;		/* default is not metadata */
    cur_pat.p_meta_mode = 0;		/* default meta mode */

    return( result );
}

/*
 * ior_parse_test_clear - clear out test read area
 */
int	ior_parse_test_clear( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

					/* clear out parsing data areas */
    memset( &cur_test, '\0', sizeof( ior_test ));

    cur_test.t_start = -1;
    cur_test.t_start_pct = -1;
    cur_test.t_size = -1;
    cur_test.t_size_pct = -1;

    cur_test.t_skew = -1;		/* no skew, by default */
    cur_test.t_seed = IOR_SKEW_SEED;	/* skew seed for randomization */
    cur_test.t_shift = 0;		/* skew is not shifted */
    cur_test.t_correlate = 50;		/* default correlation */
    cur_test.t_area = 4 * 1024 * 1024;	/* default area of 4 MB */

					/* clear pattern percentages */
    for ( parse_cur_pat = 0; parse_cur_pat < IOR_MAX_PATTERNS;
	    parse_cur_pat++ ) {
	parse_pat_pct[ parse_cur_pat ] = 0;
    };

    return( result );
}


/*
 * ior_parse_done - finished parsing the file
 */
int	ior_parse_done( ior_config *cfg )
/* ior_config	*cfg;			 our configuration */
{
    int		result;			/* final return code */

    result = 0;				/* all OK so far */

    sprintf( msg_buf, "Completed parse of file '%s'",
	    cfg->c_l_name );
    ior_debug( cfg, msg_buf );

    parse_cfg = NULL;

    result = ior_lex_done( cfg );

    return( result );
}


/*
 * yyerr_show - show the location of the error we have seen
 *
 *  The trick is to expand any tabs to spaces for alignment
 */
void	yyerr_show( ior_config *cfg )
{
    char	*src;
    char	*tgt;
    int		pos;
    int		tab_chars;

					/* print current line */
    tgt = msg_buf;
    pos = 0;
    tab_chars = 0;
    src = cfg->c_l_cur_txt;
    while (( *src != '\0' ) &&
	    ( *src != '\n' )){

	if ( *src == '\t' ) {		/* expand tabs */
	    do {
		*( tgt++ ) = ' ';
		pos++;
		tab_chars++;
	    } while ( pos % 8 != 0 );
	    tab_chars--;		/* really one less */
	    src++;
	} else {			/* copy others */
	    *( tgt++ ) = *( src++ );
	    pos++;
	};
    };
    *tgt = '\0';			/* end the string */
    ior_msg( cfg, NULL, msg_buf );

					/* point to error */
    sprintf( msg_buf, "%*s^",
	    cfg->c_l_cur_pos + tab_chars - 1, "" );
    ior_msg( cfg, NULL, msg_buf );
};

/*
 * yyerror - clear up an error in the input
 */
int	yyerror( char *s )
{
    if ( feof( yyin )) {		/* on EOF, stop reading */
	sprintf( msg_buf, "%s: line %d: end of file",
		parse_cfg->c_l_name, parse_cfg->c_l_line );
	ior_error( parse_cfg, msg_buf );

    } else if ( parse_cfg->c_l_error[ 0 ]) { /* give LEX error */

			/* print current line & point to error */
	yyerr_show( parse_cfg );
					/* print error */
	sprintf( msg_buf, "%s: line %d: %s",
		parse_cfg->c_l_name, parse_cfg->c_l_line,
		parse_cfg->c_l_error );
	ior_error( parse_cfg, msg_buf );
	parse_cfg->c_l_error[ 0 ] = '\0'; /* drop error now */

    } else {				/* otherwise, give the error */

			/* print current line & point to error */
	yyerr_show( parse_cfg );
					/* print error */
	sprintf( msg_buf, "%s: line %d: %s",
		parse_cfg->c_l_name, parse_cfg->c_l_line, s );
	ior_error( parse_cfg, msg_buf );
    };

    return( 0 );			/* all OK */
}

