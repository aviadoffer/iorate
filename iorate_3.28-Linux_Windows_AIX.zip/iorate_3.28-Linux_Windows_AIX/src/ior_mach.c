/**************************************************************************
 *
 *  ior_mach.c - the IORATE machine specific routines
 *
 *  Copyright by EMC Corporation, 1997-2011.
 *  All rights reserved.
 *
 *  Written by Vince Westin (vince.westin@emc.com), with a lot of
 *  assistance from the EMC Engineering Team.
 *
 *  This code is the property of EMC Corporation.  However, it may be used,
 *  reproduced, and passed on to others as long as the contents, including
 *  all copyright notices, remain intact.  Modifications to, or modified
 *  versions of these files, may also be distributed, provided that they
 *  are clearly labeled as having been modified from the original.  In the
 *  event that modified files are created, the original files are to be
 *  included with every distribution of those modified files.  Inclusion of
 *  this code into a commercial product by any company other than EMC is
 *  prohibited without prior written consent.
 *
 *  Having said the legal stuff, this code is designed to provide a good,
 *  generic tool for testing I/O subsystems under various kinds of loads.
 *  If you have suggestions for improvements in this tool, please send them
 *  along to the above address.
 *
 *************************************************************************/

static char rcsid[] = "$Header: /home/westiv/iorate/RCS/ior_mach.c,v 3.7 2011/11/03 15:27:25 westiv Exp westiv $";

/*
 * We load fcntl for AIX early, or bad things happen
 */
#if	defined( _AIX )
#include <fcntl.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#ifdef __linux__
#include <sys/ioctl.h>
#include <linux/fs.h>
#endif
#if defined(_WIN32) && !defined(__CYGWIN__)
#include <windows.h>
#include <winioctl.h>
#include <io.h>
#endif


#if !defined( _AIX )
#include <fcntl.h>
#endif
/*
 * Solaris needs ior_mach.h to be after the above or
 *     llseek() returns 4-byte values
 *  -- Specifically this seems to be sys/types.h
 */

#include <curl/curl.h>
#include "iorate.h"

/*
 * Default: enabled (set -DIOR_USE_PREAD_PWRITE=0 to disable).
 * FIX: Cygwin raw devices fail with pread/pwrite ("Illegal seek"),
 *      so force legacy lseek+read/write method on Cygwin.
 * FIX: AIX raw devices do NOT support pread/pwrite; must use lseek+read/write.
 */
#ifndef IOR_USE_PREAD_PWRITE
#ifdef __CYGWIN__
#define IOR_USE_PREAD_PWRITE 0
#elif defined(_AIX)
#define IOR_USE_PREAD_PWRITE 0
#else
#define IOR_USE_PREAD_PWRITE 1
#endif
#endif


/*
 * File locking portability:
 * - Some platforms (notably Cygwin) do not provide flock64/F_SETLK64.
 * - When _FILE_OFFSET_BITS=64 is set, struct flock uses 64-bit off_t anyway.
 */
#if defined(IOR_LARGE_FILES) && defined(F_SETLK64) && !defined(__CYGWIN__)
typedef struct flock64 ior_flock_t;
#define IOR_SET_LOCK_FLAG F_SETLK64
#else
typedef struct flock  ior_flock_t;
#define IOR_SET_LOCK_FLAG F_SETLK
#endif

int	errno;				/* define global error number */

extern int ior_dev_lock( ior_config *cfg, long dev );
extern int ior_dev_unlock( ior_config *cfg, long dev );
extern int ior_time_usec( ior_config *cfg, long *sec, long *usec );

struct s3_list_context {
    char *buf;
    size_t size;
};

#define IOR_S3_MAX_KEYS 1000000

static void s3_print_list_progress(ior_device *cur_dev, int cached_count, int page_count)
{
    static const char spinner[] = "|/-\\";
    char spin = spinner[page_count & 3];

    printf("\r[%c] IORate mapping objects from bucket %s: %d keys (%d pages)",
        spin, cur_dev->d_bucket, cached_count, page_count);
    fflush(stdout);
}

static size_t s3_list_cb(void *ptr, size_t size, size_t nmemb, void *stream) {
    size_t realsize = size * nmemb;
    struct s3_list_context *ctx = (struct s3_list_context *)stream;
    char *new_buf = realloc(ctx->buf, ctx->size + realsize + 1);
    if (!new_buf) return 0;
    ctx->buf = new_buf;
    memcpy(&(ctx->buf[ctx->size]), ptr, realsize);
    ctx->size += realsize;
    ctx->buf[ctx->size] = 0;
    return realsize;
}

static long s3_env_long(const char *name, long def_val)
{
    char *endptr = NULL;
    const char *raw = getenv(name);
    long val;

    if (raw == NULL || *raw == '\0') {
        return def_val;
    }

    val = strtol(raw, &endptr, 10);
    if (endptr == raw || *endptr != '\0' || val < 0) {
        return def_val;
    }

    return val;
}

static void s3_apply_common_curl_timeouts(CURL *curl)
{
    static int inited = 0;
    static long connect_timeout = 10;
    static long transfer_timeout = 0;
    static long low_speed_time = 30;
    static long low_speed_limit = 1;

    if (!inited) {
        connect_timeout = s3_env_long("IOR_S3_CONNECT_TIMEOUT_SEC", 10);
        transfer_timeout = s3_env_long("IOR_S3_TIMEOUT_SEC", 0);
        low_speed_time = s3_env_long("IOR_S3_LOW_SPEED_TIME_SEC", 30);
        low_speed_limit = s3_env_long("IOR_S3_LOW_SPEED_BYTES", 1);
        inited = 1;
    }

    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, connect_timeout);
    if (transfer_timeout > 0) {
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, transfer_timeout);
    }
    if (low_speed_time > 0 && low_speed_limit > 0) {
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, low_speed_time);
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, low_speed_limit);
    }
}

static void s3_apply_list_curl_timeouts(CURL *curl)
{
    static int inited = 0;
    static long list_timeout = 10;
    static long list_low_speed_time = 0;
    static long list_low_speed_limit = 0;

    if (!inited) {
        list_timeout = s3_env_long("IOR_S3_LIST_TIMEOUT_SEC", 10);
        list_low_speed_time = s3_env_long("IOR_S3_LIST_LOW_SPEED_TIME_SEC", 0);
        list_low_speed_limit = s3_env_long("IOR_S3_LIST_LOW_SPEED_BYTES", 0);
        inited = 1;
    }

    if (list_timeout > 0) {
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, list_timeout);
    }

    if (list_low_speed_time > 0 && list_low_speed_limit > 0) {
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, list_low_speed_time);
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, list_low_speed_limit);
    } else {
        /* Disable low-speed aborts for LIST by default; some endpoints pause mid-page. */
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 0L);
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 0L);
    }
}

static void s3_clear_key_cache(ior_device *cur_dev)
{
    int i;

    if (cur_dev->d_s3_keys == NULL) {
        cur_dev->d_s3_key_count = 0;
        return;
    }

    for (i = 0; i < cur_dev->d_s3_key_count; i++) {
        if (cur_dev->d_s3_keys[i] != NULL) {
            free(cur_dev->d_s3_keys[i]);
        }
    }
    free(cur_dev->d_s3_keys);
    cur_dev->d_s3_keys = NULL;
    cur_dev->d_s3_key_count = 0;
}

/*
 * Reuse one GET easy handle per device to keep HTTP/TLS sessions warm.
 * PUT path remains per-request to avoid method state interactions.
 */
static CURL *s3_get_or_create_read_handle(ior_device *cur_dev)
{
    CURL *curl;

    if (cur_dev->d_curl_handle != NULL) {
        return (CURL *) cur_dev->d_curl_handle;
    }

    curl = curl_easy_init();
    if (curl == NULL) {
        return NULL;
    }

    cur_dev->d_curl_handle = (void *) curl;
    return curl;
}

static void s3_prepare_get_handle(CURL *curl, ior_device *cur_dev)
{
    curl_easy_reset(curl);
    s3_apply_common_curl_timeouts(curl);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_easy_setopt(curl, CURLOPT_FRESH_CONNECT, 0L);
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 0L);
#ifdef CURLOPT_TCP_KEEPALIVE
    curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1L);
#endif
    curl_easy_setopt(curl, CURLOPT_NOBODY, 0L);
    curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
    curl_easy_setopt(curl, CURLOPT_POST, 0L);
    curl_easy_setopt(curl, CURLOPT_UPLOAD, 0L);
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, NULL);
#ifdef CURLAUTH_AWS_SIGV4
    curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_AWS_SIGV4);
    curl_easy_setopt(curl, CURLOPT_AWS_SIGV4, "aws:amz:us-east-1:s3");
#endif
    curl_easy_setopt(curl, CURLOPT_USERNAME, cur_dev->d_access_key);
    curl_easy_setopt(curl, CURLOPT_PASSWORD, cur_dev->d_secret_key);
}

static CURL *s3_get_or_create_write_handle(ior_device *cur_dev)
{
    CURL *curl;

    if (cur_dev->d_curl_put_handle != NULL) {
        return (CURL *) cur_dev->d_curl_put_handle;
    }

    curl = curl_easy_init();
    if (curl == NULL) {
        return NULL;
    }

    cur_dev->d_curl_put_handle = (void *) curl;
    return curl;
}

static void s3_prepare_put_handle(CURL *curl, ior_device *cur_dev)
{
    curl_easy_reset(curl);
    s3_apply_common_curl_timeouts(curl);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_easy_setopt(curl, CURLOPT_FRESH_CONNECT, 0L);
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 0L);
#ifdef CURLOPT_TCP_KEEPALIVE
    curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1L);
#endif
    curl_easy_setopt(curl, CURLOPT_NOBODY, 0L);
    curl_easy_setopt(curl, CURLOPT_HTTPGET, 0L);
    curl_easy_setopt(curl, CURLOPT_POST, 0L);
    curl_easy_setopt(curl, CURLOPT_UPLOAD, 0L);
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
#ifdef CURLAUTH_AWS_SIGV4
    curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_AWS_SIGV4);
    curl_easy_setopt(curl, CURLOPT_AWS_SIGV4, "aws:amz:us-east-1:s3");
#endif
    curl_easy_setopt(curl, CURLOPT_USERNAME, cur_dev->d_access_key);
    curl_easy_setopt(curl, CURLOPT_PASSWORD, cur_dev->d_secret_key);
}


/*
 * s3_list_bucket - list bucket objects and optionally cache keys for GET workloads.
 * store_keys=0 keeps enum stateless (no key list retained in memory) and
 * performs a single-page LIST request per call so mixed GET/ENUM workloads
 * don't spend long periods blocked in full-bucket enumeration.
 */
static int s3_list_bucket(ior_device *cur_dev, int store_keys, int *listed_count)
{
    int cached_count = 0;
    int page_count = 0;

    if (listed_count != NULL) {
        *listed_count = 0;
    }

    if (store_keys) {
        s3_clear_key_cache(cur_dev);
        cur_dev->d_s3_keys = (char **) malloc(sizeof(char*) * IOR_S3_MAX_KEYS);
        if (cur_dev->d_s3_keys == NULL) {
            return -1;
        }
    }

    char continuation_token[1024] = "";
    int has_more = 1;
    
    while (has_more && (!store_keys || cached_count < IOR_S3_MAX_KEYS)) {
        char url[2048];
        if (strlen(continuation_token) > 0) {
            sprintf(url, "%s%s%s?list-type=2&continuation-token=%s", 
                cur_dev->d_name, 
                cur_dev->d_name[strlen(cur_dev->d_name)-1] == '/' ? "" : "/", 
                cur_dev->d_bucket,
                continuation_token);
        } else {
            sprintf(url, "%s%s%s?list-type=2", 
                cur_dev->d_name, 
                cur_dev->d_name[strlen(cur_dev->d_name)-1] == '/' ? "" : "/", 
                cur_dev->d_bucket);
        }
        
        CURL *ch = curl_easy_init();
        if (!ch) break;
        
        struct s3_list_context ctx = { NULL, 0 };
        s3_apply_common_curl_timeouts(ch);
        s3_apply_list_curl_timeouts(ch);
        curl_easy_setopt(ch, CURLOPT_URL, url);
        curl_easy_setopt(ch, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_easy_setopt(ch, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(ch, CURLOPT_WRITEFUNCTION, s3_list_cb);
        curl_easy_setopt(ch, CURLOPT_WRITEDATA, &ctx);
        curl_easy_setopt(ch, CURLOPT_HTTPAUTH, CURLAUTH_AWS_SIGV4);
        curl_easy_setopt(ch, CURLOPT_AWS_SIGV4, "aws:amz:us-east-1:s3");
        curl_easy_setopt(ch, CURLOPT_USERNAME, cur_dev->d_access_key);
        curl_easy_setopt(ch, CURLOPT_PASSWORD, cur_dev->d_secret_key);
        
        CURLcode res_code = curl_easy_perform(ch);
        long http_code = 0;
        int allow_partial_timeout = 0;
        curl_easy_getinfo(ch, CURLINFO_RESPONSE_CODE, &http_code);

        if (store_keys && res_code == CURLE_OPERATION_TIMEDOUT
                && http_code == 200 && ctx.buf != NULL
                && strstr(ctx.buf, "<Key>") != NULL) {
            allow_partial_timeout = 1;
            printf("S3 List Warning: timed out while reading page; using partial page data\n");
        }
        
        if ((res_code == CURLE_OK || allow_partial_timeout) && http_code == 200 && ctx.buf) {
            /* Count each successful list response page once. */
            page_count++;

            if (store_keys) {
                char *ptr = ctx.buf;
                int found_in_this_page = 0;
                while (cached_count < IOR_S3_MAX_KEYS) {
                    char *key_start = strstr(ptr, "<Key>");
                    if (!key_start) break;
                    key_start += 5;
                    char *key_end = strstr(key_start, "</Key>");
                    if (!key_end) break;

                    int key_len = (int)(key_end - key_start);
                    cur_dev->d_s3_keys[cached_count] = (char *) malloc(key_len + 1);
                    if (cur_dev->d_s3_keys[cached_count] == NULL) {
                        if (ctx.buf) free(ctx.buf);
                        curl_easy_cleanup(ch);
                        s3_clear_key_cache(cur_dev);
                        return -1;
                    }
                    strncpy(cur_dev->d_s3_keys[cached_count], key_start, key_len);
                    cur_dev->d_s3_keys[cached_count][key_len] = '\0';

                    cached_count++;
                    found_in_this_page++;
                    ptr = key_end + 6;
                }
                s3_print_list_progress(cur_dev, cached_count, page_count);
                if (found_in_this_page == 0) {
                    printf("S3 List Warning: HTTP 200 but no <Key> mapping found! First 1000 bytes of bucket response:\n%.1000s\n", ctx.buf);
                }

                char *ct_start = strstr(ctx.buf, "<NextContinuationToken>");
                if (ct_start) {
                    ct_start += 23;
                    char *ct_end = strstr(ct_start, "</NextContinuationToken>");
                    if (ct_end && (ct_end - ct_start) < sizeof(continuation_token)) {
                        strncpy(continuation_token, ct_start, ct_end - ct_start);
                        continuation_token[ct_end - ct_start] = '\0';
                    } else {
                        has_more = 0;
                    }
                } else {
                    has_more = 0;
                }
            } else {
                /* ENUM mode: exactly one LIST page per call to bound latency. */
                has_more = 0;
            }
        } else { 
            printf("S3 List Error: HTTP %ld, CURL %d on URL %s\n", http_code, res_code, url);
            if (ctx.buf) printf("S3 Response: %s\n", ctx.buf);
            if (store_keys) {
                if (cached_count == 0) {
                    s3_clear_key_cache(cur_dev);
                } else {
                    printf("S3 List Warning: keeping %d already-mapped keys despite LIST error\n", cached_count);
                }
            }
            has_more = 0; 
        }
        if (ctx.buf) free(ctx.buf);
        curl_easy_cleanup(ch);
    }

    if (store_keys) {
        printf("\n");
        cur_dev->d_s3_key_count = cached_count;
        if ( !cur_dev->d_s3_get_cache_logged ) {
            printf("IORate mapped %d objects from bucket %s\n", cur_dev->d_s3_key_count, cur_dev->d_bucket);
            cur_dev->d_s3_get_cache_logged = 1;
        }
    }

    if (listed_count != NULL) {
        *listed_count = store_keys ? cached_count : page_count;
    }

    return 0;
}

/*
 * ior_open_dev - open a device for access
 */
int	ior_open_dev( ior_config *cfg, int dev )
/* ior_config	*cfg; our configuration */
/* int	dev; which device to open */
{
    int	result; /* final return code */
    int	err; /* file error we saw */
    int	open_flags; /* how to open file */
    ior_device	*cur_dev; /* our device */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    if (cur_dev->d_is_s3) {
        int needs_read = 0;
        int i;
        for (i = 0; i < cfg->c_npat; i++) {
            if (cfg->c_pats[i].p_is_s3) {
                if (cfg->c_pats[i].p_s3_mode == IOR_S3_GET) {
                    needs_read = 1;
                    break;
                }
            } else if (cfg->c_pats[i].p_read_pct > 0) {
                needs_read = 1;
                break;
            }
        }
        if (cfg->c_npat == 0) needs_read = 1;

        if (needs_read && cur_dev->d_s3_key_count == 0 && cur_dev->d_s3_keys == NULL) {
            (void) s3_list_bucket(cur_dev, 1, NULL);
        }
        cur_dev->d_fid = 9999; 
        return 0; 
    }

    sprintf( msg_buf, "ior_open_dev: Opening file %d '%s'", (int) dev + 1, cur_dev->d_name);
    ior_debug( cfg, msg_buf );

    if ( cur_dev->d_fid > -1 ) {
	    sprintf( msg_buf, "Attempt to open file %d '%s' - already open",
		dev + 1, cur_dev->d_name );
	    ior_error( cfg, msg_buf );
	    result = -1;
    } else {
	    open_flags = ( cur_dev->d_read_only ? IOR_OPEN_RD : IOR_OPEN_RDWR )
		| ( cur_dev->d_is_async ? IOR_OPEN_ASYNC : IOR_OPEN_ASYNC );
#if defined(_AIX)
	    /* On AIX, do NOT use O_DIRECT for raw devices; it can cause EINVAL. */
	    /* If device name starts with /dev/r, assume raw and skip O_DIRECT. */
	    if (cfg->c_direct_io && strncmp(cur_dev->d_name, "/dev/r", 6) != 0) {
		    open_flags |= IOR_DIRECT_IO;
	    }
#else
	    if ( cfg->c_direct_io ) {
		    open_flags |= IOR_DIRECT_IO;
	    }
#endif
#ifdef __CYGWIN__
    open_flags |= O_BINARY;
    if (open_flags & O_DIRECT) {
        open_flags &= ~O_DIRECT;
        ior_debug(cfg, "ior_open_dev: Forced removal of O_DIRECT for Cygwin compatibility");
    }
#endif
	    sprintf( msg_buf, "    -> file flags are %d", open_flags );
	    ior_debug( cfg, msg_buf );
	    cur_dev->d_fid = open( cur_dev->d_name, open_flags );
	    if ( cur_dev->d_fid <= 0 ) {
		    cur_dev->d_fid = -1;
		    err = errno;
		    perror( cur_dev->d_name );
		    sprintf( msg_buf, "Attempt to open file %d '%s' failed",
			    dev + 1, cur_dev->d_name );
		    ior_error( cfg, msg_buf );
		    sprintf( msg_buf, "    -> Error number was %d", err );
		    ior_debug( cfg, msg_buf );
		    result = -2;
	    } else {
		    if ( cur_dev->d_capacity < 1 ) {
			    result = ior_get_capacity( cfg, dev );
		    };
	    };
	    result = ior_dev_lock( cfg, dev );
    };
    cfg->c_pos = -10000;
    return( result );
}

/*
 * ior_close_dev - close a device
 */
int	ior_close_dev( ior_config *cfg, int dev )
/* ior_config	*cfg; our configuration */
/* int	dev; which device to close */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    if (cur_dev->d_is_s3) {
        if (cur_dev->d_curl_handle != NULL) {
            curl_easy_cleanup((CURL *) cur_dev->d_curl_handle);
            cur_dev->d_curl_handle = NULL;
        }
        if (cur_dev->d_curl_put_handle != NULL) {
            curl_easy_cleanup((CURL *) cur_dev->d_curl_put_handle);
            cur_dev->d_curl_put_handle = NULL;
        }
        cur_dev->d_fid = 9999;
        return 0;
    }

    sprintf( msg_buf, "Closing file %d '%s'", dev + 1, cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

    if ( cur_dev->d_fid < 0 ) { /* not open? */
	sprintf( msg_buf, "Attempt to close file %d '%s' - not open",
		(int) dev + 1, cur_dev->d_name );
	ior_error( cfg, msg_buf );
	result = -1;
    } else {				/* close the file */

	ior_dev_unlock( cfg, dev );	/* remove lock if needed */

	result = close( cur_dev->d_fid );
	if ( result < 0 ) {		/* close error? */
	    perror( cur_dev->d_name );
	    ior_error( cfg, "Error in file close" );
	};
    };

    cfg->c_pos = -1;			/* be sure no valid position */
    cur_dev->d_fid = -1;		/* make sure it is not used again */

    return( result );
}

/*
 * ior_read - do a read from the target device
 */

// S3 callbacks
struct s3_write_context {
    BYTE *buf;
    size_t size;
    size_t offset;
    unsigned long long total_bytes;
};

static size_t s3_read_cb(void *ptr, size_t size, size_t nmemb, void *stream) {
    struct s3_write_context *ctx = (struct s3_write_context *)stream;
    size_t realsize = size * nmemb;
    ctx->total_bytes += (unsigned long long) realsize;
    if (ctx->offset + realsize > ctx->size) {
        realsize = ctx->size - ctx->offset;
    }
    memcpy(ctx->buf + ctx->offset, ptr, realsize);
    ctx->offset += realsize;
    return size * nmemb;
}

/*
 * Percent-encode an S3 object key for URL path usage.
 * Keep '/' as path separator, encode all other non-unreserved bytes.
 */
static char *s3_encode_key_for_url(const char *key)
{
    const char *hex = "0123456789ABCDEF";
    const unsigned char *src;
    char *out;
    char *dst;
    size_t len;

    if (key == NULL) {
        return NULL;
    }

    len = strlen(key);
    out = (char *) malloc((len * 3) + 1);
    if (out == NULL) {
        return NULL;
    }

    dst = out;
    src = (const unsigned char *) key;
    while (*src != '\0') {
        unsigned char c = *src++;
        if ((c >= 'A' && c <= 'Z')
                || (c >= 'a' && c <= 'z')
                || (c >= '0' && c <= '9')
                || c == '-' || c == '_' || c == '.' || c == '~'
                || c == '/') {
            *dst++ = (char) c;
        } else {
            *dst++ = '%';
            *dst++ = hex[(c >> 4) & 0x0F];
            *dst++ = hex[c & 0x0F];
        }
    }
    *dst = '\0';
    return out;
}

static size_t s3_write_cb(void *ptr, size_t size, size_t nmemb, void *stream) {
    return size * nmemb;
}

int	ior_read( ior_config *cfg, long io_size, double *io_resp )
/* ior_config	*cfg; our configuration */
/* long		io_size; size of this read */
/* double	*io_resp; response time seen */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    ior_pattern *cur_pat; /* active pattern */
    long	bytes_read; /* size read */
    long	position_step; /* step for synthetic S3 positions */
    long	tollerate; /* size to tollerate being off by */
    long	start_sec; /* starting seconds */
    long	start_usec; /* starting micro seconds */
    long	end_sec; /* ending seconds */
    long	end_usec; /* ending micro seconds */
    double	resp_time; /* overall response time */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    cur_pat = ( cfg->c_cur_pat >= 0 && cfg->c_cur_pat < cfg->c_npat )
        ? &( cfg->c_pats[ cfg->c_cur_pat ]) : NULL;
    cfg->c_last_read_bytes = 0;
    position_step = ( io_size > 0 ) ? io_size : 4096;

    					/* do the read */
    ior_time_usec( cfg, &start_sec, &start_usec );

    if (cur_dev->d_is_s3) {
        char url[4096];
        int s3_get_mode = ( cur_pat != NULL && cur_pat->p_is_s3
            && cur_pat->p_s3_mode == IOR_S3_GET );
        int s3_get_full_object = ( s3_get_mode && !cur_pat->p_io_size_set );
        if (cur_dev->d_s3_key_count > 0) {
            char *encoded_key;
            long long item_idx = ((long long)(cfg->c_pos + cur_dev->d_offset) / position_step);
            item_idx = item_idx % cur_dev->d_s3_key_count;
            encoded_key = s3_encode_key_for_url(cur_dev->d_s3_keys[item_idx]);
            if (encoded_key == NULL) {
                bytes_read = -1;
                goto s3_read_done;
            }
            sprintf(url, "%s%s%s/%s", 
                cur_dev->d_name, 
                cur_dev->d_name[strlen(cur_dev->d_name)-1] == '/' ? "" : "/", 
                cur_dev->d_bucket, 
                encoded_key);
            free(encoded_key);
        } else {
            long long file_off = (long long)(cfg->c_pos + cur_dev->d_offset);
            sprintf(url, "%s%s%s/obj_%lld", 
                cur_dev->d_name, 
                cur_dev->d_name[strlen(cur_dev->d_name)-1] == '/' ? "" : "/", 
                cur_dev->d_bucket, 
                file_off);
        }
        
        CURL *curl = s3_get_or_create_read_handle(cur_dev);
        if (curl) {
            struct s3_write_context ctx = { cfg->c_read_buf, (size_t) IOR_MAX_IO_SIZE, 0, 0 };
            char range_header[64];

            s3_prepare_get_handle(curl, cur_dev);

            curl_easy_setopt(curl, CURLOPT_URL, url);
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, s3_read_cb);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ctx);
            if (s3_get_mode && !s3_get_full_object && io_size > 0) {
                sprintf(range_header, "%ld-%ld", 0L, io_size - 1L);
                curl_easy_setopt(curl, CURLOPT_RANGE, range_header);
            } else {
                curl_easy_setopt(curl, CURLOPT_RANGE, NULL);
            }
            
            CURLcode res = curl_easy_perform(curl);
            
            long response_code = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
            
            if (res == CURLE_OK && response_code >= 200 && response_code < 300) {
                bytes_read = (long) ctx.total_bytes;
            } else {
                bytes_read = -1;
                if (res != CURLE_OK) {
                    fprintf(stderr, "CURL GET error: %s\\n", curl_easy_strerror(res));
                } else {
                    fprintf(stderr, "CURL GET S3 error: HTTP %ld on URL %s\\n", response_code, url);
                }
            }
        } else {
            bytes_read = -1;
        }
s3_read_done:
        ;
    } else {
#if IOR_USE_PREAD_PWRITE
    {
        off_t file_off = (off_t)( cfg->c_pos + cur_dev->d_offset );
        bytes_read = pread( cur_dev->d_fid, cfg->c_read_buf, io_size, file_off );
    }
#else
    bytes_read = read( cur_dev->d_fid, cfg->c_read_buf, io_size );
#endif
    }
    ior_time_usec( cfg, &end_sec, &end_usec );
					/* check for short read to tollerate */
    if (( bytes_read != io_size ) && ( cfg->c_tollerate_short_reads )
            && !( cur_dev->d_is_s3 && cur_pat != NULL && cur_pat->p_is_s3
                && cur_pat->p_s3_mode == IOR_S3_GET )) {
	tollerate = io_size > 8192 ? io_size / 10 : 100;
	if ( bytes_read > io_size - tollerate ) {
	    ior_verbose( cfg, "Bytes read was short, but tollerable" );
	    bytes_read = io_size;
	};
    };
    if (( bytes_read != io_size )
            && !( cur_dev->d_is_s3 && cur_pat != NULL && cur_pat->p_is_s3
                && cur_pat->p_s3_mode == IOR_S3_GET )) {	/* something is broken */
	result = -2;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"Read of %ldk bytes to file %d %s'%s' returned %ld",
		(long)( io_size / 1024L ), cfg->c_cur_dev + 1, msg,
		cur_dev->d_name, (long)( bytes_read ));
	ior_error( cfg, msg_buf );
    };

    if ( bytes_read > 0 ) {
	cfg->c_last_read_bytes = (HUGE) bytes_read;
    }

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    cfg->c_read_time_msecs += resp_time;

    if ( cfg->c_shared_stats ) {
        long total_usec = (end_sec - start_sec) * 1000000 + (end_usec - start_usec);
        cfg->c_shared_stats[cfg->c_my_index].reads++;
        cfg->c_shared_stats[cfg->c_my_index].bytes_read += bytes_read;
        cfg->c_shared_stats[cfg->c_my_index].read_usec += total_usec;
    }

    if ( io_resp != NULL ) {
	*io_resp = resp_time;
    };

#ifdef	IOR_ENGINEERING
    ior_eng_read( cfg, io_size, bytes_read, resp_time );
#endif

    if ( result != 0 ) { /* we had an error */
	cfg->c_pos = -1; /* force seek for next I/O */
	cfg->c_errors++; /* note that we had an error */
    } else {
    cfg->c_pos += position_step; /* update our position */
    };

    return( result );
}

/*
 * ior_write - do write to the target device
 */
static void ior_fill_compressible_buf( ior_config *cfg, BYTE *buf, long io_size, HUGE file_off )
{
    long off;
    int i;
    int chunk_size = 4 * 1024;
    double ratio_adj = cfg->c_compressible_ratio * 1.09;

    for ( off = 0; off < io_size; off += chunk_size ) {
        int cur_chunk = (int) (( io_size - off < chunk_size ) ? ( io_size - off ) : chunk_size);
        HUGE chunk_index = (HUGE) (( file_off + (HUGE) off ) / chunk_size);
        BYTE fill_ch = (BYTE) ( 1 + ( (int) ( chunk_index % 255 ) ) );
        int base_len = (int) ( cur_chunk / ratio_adj );
        unsigned int seed = (unsigned int) ( chunk_index ^ ( chunk_index >> 32 ) ^ 0xA5A5A5A5u );
        if ( seed == 0 ) seed = 1u;
        if ( base_len < 1 ) base_len = 1;

        /* Write 4 bytes at a time from 32-bit PRNG (4x fewer iterations) */
        int base_aligned = base_len & ~3;
        for ( i = 0; i < base_aligned; i += 4 ) {
            seed ^= seed << 13;
            seed ^= seed >> 17;
            seed ^= seed << 5;
            memcpy( buf + off + i, &seed, 4 );
        }
        for ( ; i < base_len; i++ ) {
            seed ^= seed << 13;
            seed ^= seed >> 17;
            seed ^= seed << 5;
            buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
        }
        /* Use SIMD-optimized memset for compressible fill portion */
        memset( buf + off + base_len, fill_ch, cur_chunk - base_len );
    }
}

/*
 * ior_fill_dedup_buf - fill a write buffer with dedupable data
 *
 * Divides the I/O into dedup_block_size chunks.  For a dedup ratio of X:1,
 * every X consecutive dedup blocks share the same content (determined by a
 * unique_id derived from the absolute block index).  The unique_id is simply
 * abs_block / dedup_ratio, so each group of X blocks shares the same seed
 * and thus identical byte content.  Different groups get different seeds.
 *
 * When compressible_ratio is also > 1.0, each unique block is filled with a
 * compressible pattern (partial random + repeating fill byte) so the data is
 * simultaneously dedupable AND compressible.
 */

static void ior_fill_dedup_buf( ior_config *cfg, BYTE *buf, long io_size, HUGE file_off )
{
    long dedup_bs = cfg->c_dedup_block_size;
    long off;
    int  i;
    int  do_compress = ( cfg->c_compressible_ratio > 1.0 );
    double ratio_adj = do_compress ? ( cfg->c_compressible_ratio * 1.09 ) : 0.0;

    for ( off = 0; off < io_size; off += dedup_bs ) {
        long cur_chunk = (long) (( io_size - off < dedup_bs ) ? ( io_size - off ) : dedup_bs);
        HUGE abs_block = (HUGE) (( file_off + (HUGE) off ) / dedup_bs);

        /* Map groups of dedup_ratio consecutive blocks to the same unique_id */
        HUGE unique_id = abs_block / (HUGE) cfg->c_dedup_ratio;

        /*
         * Embed the 8-byte unique_id as the first bytes of each block.
         * This guarantees blocks with different unique_ids are never
         * byte-identical, even at 96TB (25B+ blocks, 6B+ unique groups)
         * where a 32-bit PRNG seed would collide.
         */
        int hdr_len = 8;
        if ( hdr_len > cur_chunk ) hdr_len = (int) cur_chunk;
        memcpy( buf + off, &unique_id, hdr_len );

        /* Deterministic PRNG seed from unique_id for remaining bytes */
        unsigned int seed = (unsigned int) ( (unsigned long) unique_id * 2654435761u + 0x12345678u );
        seed ^= (unsigned int) ( unique_id >> 32 );
        if ( seed == 0 ) seed = 1u;

        if ( do_compress ) {
            /* Compressible + dedupable: random portion after header, then fill */
            int base_len = (int) ( cur_chunk / ratio_adj );
            BYTE fill_ch = (BYTE) ( 1 + ( (int) ( unique_id % 255 ) ) );
            if ( base_len < hdr_len + 1 ) base_len = hdr_len + 1;
            /* Write 4 bytes at a time from 32-bit PRNG (4x fewer iterations) */
            int base_aligned = hdr_len + (( base_len - hdr_len ) & ~3);
            for ( i = hdr_len; i < base_aligned; i += 4 ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                memcpy( buf + off + i, &seed, 4 );
            }
            for ( ; i < base_len; i++ ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
            }
            /* Use SIMD-optimized memset for compressible fill portion */
            memset( buf + off + base_len, fill_ch, cur_chunk - base_len );
        } else {
            /* Dedup only: PRNG fill after header, 4 bytes at a time */
            int end_aligned = hdr_len + (( (int) cur_chunk - hdr_len ) & ~3);
            for ( i = hdr_len; i < end_aligned; i += 4 ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                memcpy( buf + off + i, &seed, 4 );
            }
            for ( ; i < (int) cur_chunk; i++ ) {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                buf[ off + i ] = (BYTE) ( ( seed >> 24 ) & 0xFF );
            }
        }
    }
}

int	ior_write( ior_config *cfg, long io_size, double *io_resp )
/* ior_config	*cfg; our configuration */
/* long		io_size; size of this write */
/* double	*io_resp; response time seen */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    long	bytes_written; /* size written */
    BYTE	*write_buf; /* selected write buffer */
    long	start_sec; /* starting seconds */
    long	start_usec; /* starting micro seconds */
    long	end_sec; /* ending seconds */
    long	end_usec; /* ending micro seconds */
    double	resp_time; /* overall response time */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);
    write_buf = cfg->c_write_buf;
    if ( ( cfg->c_compressible_ratio > 1.0 || cfg->c_dedup_ratio > 1.0 )
            && cfg->c_cur_pat >= 0
            && cfg->c_cur_pat < IOR_MAX_PATTERNS + 2
            && cfg->c_write_bufs[ cfg->c_cur_pat ] != NULL ) {
        write_buf = cfg->c_write_bufs[ cfg->c_cur_pat ];
    }

    /* Fill write buffer: dedup takes priority (handles compression internally) */
    if ( cfg->c_dedup_ratio > 1.0 ) {
        HUGE file_off = (HUGE) ( cfg->c_pos + cur_dev->d_offset );
        ior_fill_dedup_buf( cfg, write_buf, io_size, file_off );
    } else if ( cfg->c_compressible_ratio > 1.0 ) {
        HUGE file_off = (HUGE) ( cfg->c_pos + cur_dev->d_offset );
        ior_fill_compressible_buf( cfg, write_buf, io_size, file_off );
    }

    					/* do the write */
    ior_time_usec( cfg, &start_sec, &start_usec );

    if (cur_dev->d_is_s3) {
        char url[1024];
        long long file_off = (long long)(cfg->c_pos + cur_dev->d_offset);
        sprintf(url, "%s%s%s/obj_%lld", 
            cur_dev->d_name, 
            cur_dev->d_name[strlen(cur_dev->d_name)-1] == '/' ? "" : "/", 
            cur_dev->d_bucket, 
            file_off);
        
        CURL *curl = s3_get_or_create_write_handle(cur_dev);
        if (curl) {
            struct curl_slist *headers = NULL;

            s3_prepare_put_handle(curl, cur_dev);

            headers = curl_slist_append(headers, "Content-Type: application/octet-stream");
            headers = curl_slist_append(headers, "Expect:");
            curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

            // In case we want to see HTTP debugging later
            //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

            curl_easy_setopt(curl, CURLOPT_URL, url);
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, write_buf);
            curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, io_size);
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, s3_write_cb);
            
            CURLcode res = curl_easy_perform(curl);
            
            long response_code = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
            
            if (res == CURLE_OK && response_code >= 200 && response_code < 300) {
                bytes_written = io_size;
            } else {
                bytes_written = -1;
                if (res != CURLE_OK) {
                    fprintf(stderr, "CURL PUT error: %s\\n", curl_easy_strerror(res));
                } else {
                    fprintf(stderr, "CURL PUT S3 error: HTTP %ld on URL %s\\n", response_code, url);
                }
            }
            curl_slist_free_all(headers);
        } else {
            bytes_written = -1;
        }
    } else {
#if IOR_USE_PREAD_PWRITE
    {
        off_t file_off = (off_t)( cfg->c_pos + cur_dev->d_offset );
        bytes_written = pwrite( cur_dev->d_fid, write_buf, io_size, file_off );
    }
#else
    bytes_written = write( cur_dev->d_fid, write_buf, io_size );
#endif
    }
    ior_time_usec( cfg, &end_sec, &end_usec );
    if ( bytes_written != io_size ) {	/* something is broken */
	result = -2;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"Write of %ldk bytes to file %d %s'%s' returned %ld",
		(long)( io_size / 1024L ), cfg->c_cur_dev + 1, msg,
		cur_dev->d_name, (long)( bytes_written ));
	ior_error( cfg, msg_buf );
    };

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    cfg->c_write_time_msecs += resp_time;

    if ( cfg->c_shared_stats ) {
        long total_usec = (end_sec - start_sec) * 1000000 + (end_usec - start_usec);
        cfg->c_shared_stats[cfg->c_my_index].writes++;
        cfg->c_shared_stats[cfg->c_my_index].bytes_written += bytes_written;
        cfg->c_shared_stats[cfg->c_my_index].write_usec += total_usec;
    }

    if ( io_resp != NULL ) {
	*io_resp = resp_time;
    };

#ifdef	IOR_ENGINEERING
    ior_eng_write( cfg, io_size, bytes_written, resp_time );
#endif

    if ( result != 0 ) {		/* we had an error */
	cfg->c_pos = -1;		/* force seek for next I/O */
	cfg->c_errors++;		/* note that we had an error */
    } else {
	cfg->c_pos += io_size;		/* update our position */
    };

    return( result );
}

/*
 * ior_unmap - issue a discard/unmap for the target range
 */
int	ior_unmap( ior_config *cfg, long io_size, double *io_resp )
/* ior_config	*cfg; our configuration */
/* long		io_size; size of this unmap */
/* double	*io_resp; response time seen */
{
    int		result; /* final return code */
    ior_device	*cur_dev; /* our device */
    long	start_sec; /* starting seconds */
    long	start_usec; /* starting micro seconds */
    long	end_sec; /* ending seconds */
    long	end_usec; /* ending micro seconds */
    double	resp_time; /* overall response time */

    result = 0;
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    ior_time_usec( cfg, &start_sec, &start_usec );

    if ( cur_dev->d_is_s3 ) {
        /* S3 ENUM patterns are routed through UNMAP slot in p_read_use. */
        if ( cfg->c_cur_pat >= 0 && cfg->c_cur_pat < cfg->c_npat
                && cfg->c_pats[ cfg->c_cur_pat ].p_is_s3
                && cfg->c_pats[ cfg->c_cur_pat ].p_s3_mode == IOR_S3_ENUM ) {
            result = ior_enum( cfg, &resp_time );
            if ( result != 0 ) {
                cfg->c_pos = -1;
                cfg->c_errors++;
                return( result );
            }

            cfg->c_unmap_time_msecs += resp_time;

            if ( cfg->c_shared_stats ) {
                long total_usec = (long)( resp_time * 1000.0 );
                cfg->c_shared_stats[cfg->c_my_index].unmaps++;
                cfg->c_shared_stats[cfg->c_my_index].enum_objects += cfg->c_last_enum_objects;
                cfg->c_shared_stats[cfg->c_my_index].bytes_unmapped += io_size;
                cfg->c_shared_stats[cfg->c_my_index].unmap_usec += total_usec;
            }

            if ( io_resp != NULL ) {
                *io_resp = resp_time;
            }

            cfg->c_pos += io_size;
            return( 0 );
        }

        ior_error( cfg, "UNMAP is not supported for S3 devices (use ENUM for list testing)" );
        cfg->c_pos = -1;
        cfg->c_errors++;
        return( -9 );
    }

#ifdef __linux__
    {
        struct stat st;
        off_t file_off = (off_t)( cfg->c_pos + cur_dev->d_offset );

        if ( fstat( cur_dev->d_fid, &st ) != 0 ) {
            result = -2;
        } else if ( S_ISBLK( st.st_mode )) {
            unsigned long long range[ 2 ];
            range[ 0 ] = (unsigned long long) file_off;
            range[ 1 ] = (unsigned long long) io_size;
            if ( ioctl( cur_dev->d_fid, BLKDISCARD, &range ) != 0 ) {
                result = -3;
            }
        } else if ( S_ISREG( st.st_mode )) {
            if ( fallocate( cur_dev->d_fid,
                    FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE,
                    file_off, io_size ) != 0 ) {
                result = -4;
            }
        } else {
            result = -5;
        }
    }
#elif defined(_WIN32) && !defined(__CYGWIN__)
    {
        __int64 file_off = (__int64)( cfg->c_pos + cur_dev->d_offset );
        HANDLE h = (HANDLE) _get_osfhandle( cur_dev->d_fid );

        if ( h == INVALID_HANDLE_VALUE ) {
            result = -2;
        }
#if defined(IOCTL_STORAGE_MANAGE_DATA_SET_ATTRIBUTES) && defined(DeviceDsmAction_Trim)
        else {
            BYTE dsm_buf[ sizeof( DEVICE_MANAGE_DATA_SET_ATTRIBUTES ) +
                          sizeof( DEVICE_DATA_SET_RANGE ) ];
            DEVICE_MANAGE_DATA_SET_ATTRIBUTES *dsm;
            DEVICE_DATA_SET_RANGE *range;
            DWORD bytes_returned;

            memset( dsm_buf, '\0', sizeof( dsm_buf ));

            dsm = (DEVICE_MANAGE_DATA_SET_ATTRIBUTES *) dsm_buf;
            range = (DEVICE_DATA_SET_RANGE *)
                ( dsm_buf + sizeof( DEVICE_MANAGE_DATA_SET_ATTRIBUTES ));

            dsm->Size = sizeof( DEVICE_MANAGE_DATA_SET_ATTRIBUTES );
            dsm->Action = DeviceDsmAction_Trim;
            dsm->Flags = 0;
            dsm->ParameterBlockOffset = 0;
            dsm->ParameterBlockLength = 0;
            dsm->DataSetRangesOffset = sizeof( DEVICE_MANAGE_DATA_SET_ATTRIBUTES );
            dsm->DataSetRangesLength = sizeof( DEVICE_DATA_SET_RANGE );

            range->StartingOffset = (ULONGLONG) file_off;
            range->LengthInBytes = (ULONGLONG) io_size;

            if ( !DeviceIoControl( h,
                    IOCTL_STORAGE_MANAGE_DATA_SET_ATTRIBUTES,
                    dsm_buf,
                    sizeof( dsm_buf ),
                    NULL,
                    0,
                    &bytes_returned,
                    NULL )) {
                result = -3;
            }
        }
#else
        else {
            result = -7;
        }
#endif
    }
#elif defined(_AIX)
    result = -8;
#else
    result = -6;
#endif

    ior_time_usec( cfg, &end_sec, &end_usec );

    if ( result != 0 ) {
        perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
#ifndef __linux__
#if defined(_AIX)
    ior_error( cfg, "UNMAP requested, but AIX backend is not implemented yet in ior_unmap" );
#elif defined(_WIN32) && !defined(__CYGWIN__)
    ior_error( cfg, "UNMAP/TRIM requested, but Windows backend is unavailable on this build/target" );
#else
    ior_error( cfg, "UNMAP requested but this platform does not support ior_unmap" );
#endif
#else
        ior_error( cfg, "UNMAP failed for requested range" );
#endif
        cfg->c_pos = -1;
        cfg->c_errors++;
        return( result );
    }

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    cfg->c_unmap_time_msecs += resp_time;

    if ( cfg->c_shared_stats ) {
        long total_usec = (end_sec - start_sec) * 1000000 + (end_usec - start_usec);
        cfg->c_shared_stats[cfg->c_my_index].unmaps++;
        cfg->c_shared_stats[cfg->c_my_index].bytes_unmapped += io_size;
        cfg->c_shared_stats[cfg->c_my_index].unmap_usec += total_usec;
    }

    if ( io_resp != NULL ) {
	*io_resp = resp_time;
    };

    cfg->c_pos += io_size;

    return( result );
}

/*
 * ior_seek - seek to a new position in the target file
 */
int	ior_seek( ior_config *cfg, HUGE pos )
/* ior_config	*cfg; our configuration */
/* HUGE		pos; position to seek to */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    HUGE	target; /* pos we wanted to go to */
    HUGE	new_pos; /* pos we seeked to */
    char	msg[20]; /* copy message */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    target = pos + cur_dev->d_offset;

#if IOR_USE_PREAD_PWRITE
    /*
     * When using pread/pwrite, we do not need to move the shared file position
     * for normal test I/O. Keep the real seek for the capacity check.
     */
    if ( pos != cur_dev->d_capacity ) {
        cfg->c_pos = pos;
        return( 0 );
    }
#endif


    sprintf( msg_buf, "ior_seek: Seeking from %ldk to %ldk in file %d.%d '%s'",
	    (long)(( cfg->c_pos + cur_dev->d_offset )/ 1024L ),
	    (long)( target / 1024L ), cfg->c_cur_dev + 1,
	    cfg->c_cur_adev + 1, cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

					/* do the seek */
    new_pos = IOR_SEEK( cur_dev->d_fid,
		    target, IOR_SEEK_SET );
    /* NOTE: checking for real position is broken with llseek on Sun, */
    /*       and always returns small (positive) values for good.     */
    /*       Since this is only true for SPARC Solaris, we skip that. */
    if ( new_pos < 0 ) {		/* OOPS - something is broken */
	result = -1;
	perror( cfg->c_devs[ cfg->c_cur_dev ].d_name );
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf, "Seek from %ldk to %ldk in file %d %s'%s' FAILED",
		(long)( cfg->c_pos / 1024L ), (long)( pos / 1024L ),
		cfg->c_cur_dev + 1, msg, cur_dev->d_name);
	ior_error( cfg, msg_buf );

		    /** Some platforms don't give good data from llseek **/
#if	!defined(SOLARIS_SPARC) && !defined(HPUX)

		    /** debug code courtesy of Don Fike -
			make sure we succeeded at our seek **/
    } else if ( new_pos < target ) {
	if ( cur_dev->d_count > 1 ) {
	    sprintf( msg, "(copy %d) ", cfg->c_cur_adev + 1 );
	} else {
	    strcpy( msg, "" );
	};
	sprintf( msg_buf,
		"ior_seek: Seek new position %ldk < Seek set position %ldk in file %d %s'%s'",
		(long)( new_pos / 1024L ),
		(long)( target / 1024L ),
		cfg->c_cur_dev + 1, msg, cur_dev->d_name );
	ior_warn( cfg, msg_buf );
#endif
    };

    if ( result != 0 ) {		/* we had an error */
	cfg->c_pos = -1;		/* force seek for next I/O */
	cfg->c_errors++;		/* note that we had an error */
    } else {
	cfg->c_pos = pos;		/* update our position */
    };

    return( result );
}

#define	IOR_LOCK_READ		F_RDLCK
#define	IOR_LOCK_WRITE		F_WRLCK
#define	IOR_LOCK_REMOVE		F_UNLCK

/*
 * ior_dev_lock - lock the target device if set
 */
int	ior_dev_lock( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; target device to check/lock */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

#if	defined(IOR_LARGE_FILES) && defined(HPUX)
    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( cur_dev->d_lock ) {
	    ior_warn( cfg, "ior_dev_lock: large file locks not available on HP-UX (ignored)");
    };	

#else
    ior_flock_t d_lock;		/* lock command to run */

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( !cur_dev->d_lock ) {
	sprintf( msg_buf, "No locking for file %d '%s'",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_verbose( cfg, msg_buf );

	return( result );
    };

    if ( cur_dev->d_fid < 0 ) {		/* not open? */
	sprintf( msg_buf, "Attempt to lock file %d '%s' - not open",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_error( cfg, msg_buf );

	return( -1 );
    };
					/* configure the lock to set */
    d_lock.l_type = cur_dev->d_read_only ? IOR_LOCK_READ : IOR_LOCK_WRITE;
    d_lock.l_start = cur_dev->d_offset;	/* use device offset */
    d_lock.l_len = cur_dev->d_capacity;	/* -- and capacity */
    d_lock.l_whence = IOR_SEEK_SET;

    result = fcntl( cur_dev->d_fid, IOR_SET_LOCK_FLAG, &d_lock );

    if ( result != 0 ) {		/* we had an error */
	perror( cur_dev->d_name );
	sprintf( msg_buf, "Lock of file %d '%s' from %ldk to %ldk FAILED",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_error( cfg, msg_buf );
    } else {
	sprintf( msg_buf, "Locked file %d '%s' from %ldk to %ldk",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_verbose( cfg, msg_buf );
    };
#endif

    return( result );
}


/*
 * ior_dev_unlock - unlock the target device if set
 */
int	ior_dev_unlock( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; target device to check/unlock */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */

#if	defined(IOR_LARGE_FILES) && defined(HPUX)
    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( cur_dev->d_lock ) {
	    ior_warn( cfg, "ior_dev_unlock: large file locks not available on HP-UX (ignored)");
    };	

#else
    ior_flock_t d_lock;		/* lock command to run */

    result = 0;				/* all OK so far */

    cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ]);

    if ( !cur_dev->d_lock ) {
	sprintf( msg_buf, "No locking for file %d '%s'",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_verbose( cfg, msg_buf );

	return( result );
    };

    if ( cur_dev->d_fid < 0 ) {		/* not open? */
	sprintf( msg_buf, "Attempt to unlock file %d '%s' - not open",
		(int)( dev + 1 ), cur_dev->d_name );
	ior_error( cfg, msg_buf );

	return( -1 );
    };

    d_lock.l_type = IOR_LOCK_REMOVE;	/* configure the lock to set */
    d_lock.l_start = cur_dev->d_offset;	/* use device offset */
    d_lock.l_len = cur_dev->d_capacity;	/* -- and capacity */
    d_lock.l_whence = IOR_SEEK_SET;

    result = fcntl( cur_dev->d_fid, IOR_SET_LOCK_FLAG, &d_lock );

    if ( result != 0 ) {		/* we had an error */
	perror( cur_dev->d_name );
	sprintf( msg_buf, "Unlock of file %d '%s' from %ldk to %ldk FAILED",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_error( cfg, msg_buf );
    } else {
	sprintf( msg_buf, "Unlocked file %d '%s' from %ldk to %ldk",
		(int)( dev + 1 ), cur_dev->d_name, 
		(long)(( cur_dev->d_offset )/ 1024L ),
		(long)(( cur_dev->d_capacity )/ 1024L ));
	ior_verbose( cfg, msg_buf );
    };
#endif

    return( result );
}

/*
 * ior_get_capacity - find capacity for an open device
 */
int	ior_get_capacity( ior_config *cfg, long dev )
/* ior_config	*cfg; our configuration */
/* long		dev; which device to check */
{
    int	result; /* final return code */
    ior_device	*cur_dev; /* our device */
    HUGE	pos; /* current test position */
    HUGE	incr; /* next increment to try */
    HUGE	seek_status; /* did we seek OK? */

    result = 0; /* all OK so far */
    cur_dev = &( cfg->c_devs[ dev ]);

    if (cur_dev->d_is_s3) { cur_dev->d_fid = 9999; return 0; }

    sprintf( msg_buf, "Determining size of file %ld '%s'", dev + 1,
	    cur_dev->d_name);
    ior_verbose( cfg, msg_buf );

    if ( cur_dev->d_fid < 0 ) {	/* are we ready? */
	ior_error( cfg, "File not open in 'ior_get_capacity'" );
	return( -1 );
    };

    pos = 0;				/* start at beginning */
					/* try half the maximum size */
    incr = ( IOR_MAX_SEEK / ( 2 * IOR_BLOCK_SIZE )) * IOR_BLOCK_SIZE;
    while ( incr > IOR_BLOCK_SIZE ) {
	seek_status = IOR_SEEK( cur_dev->d_fid, pos + incr, IOR_SEEK_SET );
	if ( seek_status == pos + incr ) {
	    pos += incr;
	};
	incr /= 2;			/* half this seek for next time */
    };

    if ( pos < 0 ) {		/*  - or WRAP */
	pos = IOR_MAX_SEEK;
    };
					/* record the capacity */
    cur_dev->d_capacity = pos - cur_dev->d_offset;

    cfg->c_pos = -1;			/* force seek for next I/O */

    return( result );
}

/*
 * ior_rand - generate a nice, large random number
 */
HUGE	ior_rand( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    HUGE	result; /* final return code */

    result = RAND();

    return( result );
}

/*
 * ior_random_seed - set up the random number generator with the given seed
 */
int	ior_random_seed( ior_config *cfg, long seed )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

    sprintf( msg_buf, "ior_random_seed: setting seed to %ld", seed );
    ior_debug( cfg, msg_buf );

    SEED( seed );			/* fix random generation */

    return( result );
}

/*
 * ior_randomize - set up the random number generator
 */
int	ior_randomize( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */
    long	seed; /* seed to use */

    result = strlen( rcsid );		/* STOP unused complaints from compiler */
    result = 0; /* all OK so far */

    seed = ior_get_time( cfg );		/* get time as seed */

    seed += getpid();			/* add process ID */

    ior_random_seed( cfg, seed );	/* fix random generation */

    ior_debug( cfg, "ior_randomize: random number generation randomized" );

    return( result );
}

/*
 * ior_get_time - get current time in seconds
 */
long	ior_get_time(ior_config *cfg)
/* ior_config	*cfg; our configuration */
{
    long	result; /* final return code */

    struct timeval tp;

    if ( gettimeofday( &tp, 0 ) == -1 ) {
	result = -1;
    } else {
	result = tp.tv_sec;
    };

    return( result );
}

/*
 * ior_date_string - convert seconds to a date string
 */
int	ior_date_string( ior_config *cfg, ior_clock clk, char *str )
/* ior_config	*cfg; our configuration */
/* ior_clock	clk; clock for the date */
/* char		*str; string for our date */
{
    int	result; /* final return code */
    struct tm *local_time; /* dissected local time */

    result = 0; /* all OK so far */

    local_time = (struct tm *) localtime((time_t *)( &clk )); /* get time details */
    strftime( str, 26, "%a %b %d %Y %H:%M:%S", local_time );
    str[ 24 ] = '\0';

    return( result );
}

/*
 * ior_sleep - rough sleep in seconds
 */
int	ior_sleep( ior_config *cfg, int sec )
/* ior_config	*cfg; our configuration */
/* int		sec; how long to sleep */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

    sleep( sec );			/* sleep for requested time */

    return( result );
}

#ifdef	USE_LOCK_CODE
static BYTE	ior_have_locked = 0;
#endif

/*
 * ior_set_lock - lock for file access
 */
int	ior_set_lock( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

	/* Using these advisory UNIX file locks was a fine idea, but it	*/
	/* doesn't work out in the real world.  By using these locks to	*/
	/* control output to the performance file, we wound up with a	*/
	/* number of the testing processes hanging after completion,	*/
	/* with no performance data written.  To ensure that this	*/
	/* problem does not spread, these locks are being disabled	*/
	/* here.							*/
	/* This was seen on Solaris, AIX, and HP-UX systems.  Testing	*/
	/* on other platforms did not report the problem, but were not	*/
	/* used as often and may simply have not come across it.  The	*/
	/* problem appears more often as the device count increases.	*/

#ifdef	USE_LOCK_CODE
    if ( !cfg->c_is_active ) {		/* not active - no leed to lock */
	return( 0 );
    };

    if ( ior_have_locked ) {		/* process already has a lock! */
	return( -1 );
    };
					/* get exclusive file lock */
    result = lockf( fileno( cfg->c_log_file ), F_LOCK, 64L );

    if ( result == 0 ) {
	ior_have_locked = 1;		/* lock set */
    } else {				/* if not, there isn't much we can do */
	perror( cfg->c_log_name );
	ior_error( cfg, "LOCK failed to set" );
    };
#endif

    return( result );
}

/*
 * ior_clear_lock - lock for file access
 */
int	ior_clear_lock( ior_config *cfg )
/* ior_config	*cfg; our configuration */
{
    int	result; /* final return code */

    result = 0; /* all OK so far */

	/* See above note on use of file locking code. */

#ifdef	USE_LOCK_CODE
    if ( !cfg->c_is_active ) {		/* not active - no leed to unlock */
	return( 0 );
    };

    if ( !ior_have_locked ) {		/* process doesn't have a lock! */
	return( -1 );
    };
					/* release exclusive file lock */
    result = lockf( fileno( cfg->c_log_file ), F_ULOCK, 64L );

    if ( result == 0 ) {
	ior_have_locked = 0;		/* lock released */
    } else {				/* if not, there isn't much we can do */
	perror( cfg->c_log_name );
	ior_error( cfg, "LOCK failed to release" );
    };
#endif

    return( result );
}

/*
 * ior_time_usec - get the time to a very fine level
 */
int	ior_time_usec( ior_config *cfg, long *sec, long *usec )
/* ior_config	*cfg; our configuration */
/* long		*sec; pointer to time in sec */
/* long		*usec; pointer to time in usec */
{
    int	result; /* final return code */
    struct timeval tp;			/* time pointer */

    result = 0; /* all OK so far */

					/* get the current time */
    if ( gettimeofday( &tp, (struct timezone *) NULL ) < 0 ) {
	result = -1;
	*sec = 0;
	*usec = 0;
    } else {
	*sec = tp.tv_sec;		/* recored the time */
	*usec = tp.tv_usec;
    };

    return( result );
}

/*
 * ior_sleep_usec - go to sleep to a very fine level
 */
int	ior_sleep_usec( ior_config *cfg, long usec )
/* ior_config	*cfg; our configuration */
/* long   		usec;			 time to sleep in usec */
{
    long   	sec;			/* sleep time in seconds */
    int		result;			/* final return code */

    struct timeval selectTimeout;	/* actual time to sleep */

    result = 0;				/* all OK so far */

    sec = usec / 1000000;
    usec = usec % 1000000;

    selectTimeout.tv_sec = sec;
    selectTimeout.tv_usec = usec;

    result = select(0, NULL, NULL, NULL, &selectTimeout);

    if ( result < 0 && errno == EINTR ) {
	result = 0;
    }

    return( result );
}

/*
 * ior_meta_stat - perform a stat() metadata operation
 */
int	ior_meta_stat( ior_config *cfg, const char *path, double *resp )
{
    struct stat	st;
    long	start_sec, start_usec, end_sec, end_usec;
    int		result = 0;

    ior_time_usec( cfg, &start_sec, &start_usec );
    if ( stat( path, &st ) != 0 ) {
	result = -1;
    }
    ior_time_usec( cfg, &end_sec, &end_usec );

    *resp = (( end_sec - start_sec ) * 1000000 + end_usec - start_usec ) / 1000.0;
    return( result );
}

/*
 * ior_meta_openclose - perform an open()+close() metadata operation
 */
int	ior_meta_openclose( ior_config *cfg, const char *path, double *resp )
{
    int		fd;
    long	start_sec, start_usec, end_sec, end_usec;
    int		result = 0;

    ior_time_usec( cfg, &start_sec, &start_usec );
    fd = open( path, O_RDONLY );
    if ( fd < 0 ) {
	result = -1;
    } else {
	close( fd );
    }
    ior_time_usec( cfg, &end_sec, &end_usec );

    *resp = (( end_sec - start_sec ) * 1000000 + end_usec - start_usec ) / 1000.0;
    return( result );
}

/*
 * ior_meta_readdir - perform opendir()+readdir()+closedir() metadata operation
 */
int	ior_meta_readdir( ior_config *cfg, const char *path, double *resp, long *entry_count )
{
    DIR		*dirp;
    struct dirent *entry;
    long	start_sec, start_usec, end_sec, end_usec;
    int		result = 0;
    long	local_entries = 0;

    ior_time_usec( cfg, &start_sec, &start_usec );
    dirp = opendir( path );
    if ( dirp == NULL ) {
	result = -1;
    } else {
	while (( entry = readdir( dirp )) != NULL ) {
	    /* consume all entries */
        local_entries++;
	}
	closedir( dirp );
    }
    ior_time_usec( cfg, &end_sec, &end_usec );

    if (entry_count) *entry_count = local_entries;
    *resp = (( end_sec - start_sec ) * 1000000 + end_usec - start_usec ) / 1000.0;
    return( result );
}

/*
 * ior_meta_scan_dir - recursively scan a directory and build file/dir lists
 *
 *   Populates cfg->c_meta_files[] and cfg->c_meta_dirs[]
 *   Returns 0 on success, negative on error
 */
#define IOR_META_INIT_FILES	65536
#define IOR_META_INIT_DIRS	8192

static int ior_meta_grow_files( ior_config *cfg )
{
    long	new_cap = cfg->c_meta_files_cap * 2;
    char	**tmp;

    tmp = (char **) realloc( cfg->c_meta_files, new_cap * sizeof( char * ));
    if ( tmp == NULL ) return( -1 );
    memset( tmp + cfg->c_meta_files_cap, 0, cfg->c_meta_files_cap * sizeof( char * ));
    cfg->c_meta_files = tmp;
    cfg->c_meta_files_cap = new_cap;
    return( 0 );
}

static int ior_meta_grow_dirs( ior_config *cfg )
{
    long	new_cap = cfg->c_meta_dirs_cap * 2;
    char	**tmp;

    tmp = (char **) realloc( cfg->c_meta_dirs, new_cap * sizeof( char * ));
    if ( tmp == NULL ) return( -1 );
    memset( tmp + cfg->c_meta_dirs_cap, 0, cfg->c_meta_dirs_cap * sizeof( char * ));
    cfg->c_meta_dirs = tmp;
    cfg->c_meta_dirs_cap = new_cap;
    return( 0 );
}

static int ior_meta_scan_dir_r( ior_config *cfg, const char *base_dir, int depth )
{
    DIR		*dirp;
    struct dirent *entry;
    struct stat	st;
    char	fullpath[4096];
    int		result = 0;

    if ( depth > 100 ) return( 0 );	/* limit recursion depth */

    dirp = opendir( base_dir );
    if ( dirp == NULL ) return( -1 );

    /* add this directory to the dir list */
    if ( cfg->c_meta_ndirs >= cfg->c_meta_dirs_cap ) {
	if ( ior_meta_grow_dirs( cfg ) != 0 ) { closedir( dirp ); return( -1 ); }
    }
    cfg->c_meta_dirs[ cfg->c_meta_ndirs++ ] = strdup( base_dir );

    while (( entry = readdir( dirp )) != NULL ) {
	if ( strcmp( entry->d_name, "." ) == 0 ||
		strcmp( entry->d_name, ".." ) == 0 ) {
	    continue;
	}

	snprintf( fullpath, sizeof( fullpath ), "%s/%s", base_dir, entry->d_name );

	if ( stat( fullpath, &st ) != 0 ) continue;

	if ( S_ISDIR( st.st_mode )) {
	    result = ior_meta_scan_dir_r( cfg, fullpath, depth + 1 );
	    if ( result < 0 ) break;
	} else if ( S_ISREG( st.st_mode )) {
	    if ( cfg->c_meta_nfiles >= cfg->c_meta_files_cap ) {
		if ( ior_meta_grow_files( cfg ) != 0 ) { closedir( dirp ); return( -1 ); }
	    }
	    cfg->c_meta_files[ cfg->c_meta_nfiles++ ] = strdup( fullpath );
	}
    }

    closedir( dirp );
    return( result );
}

int	ior_meta_scan_dir( ior_config *cfg, const char *base_dir )
{
    /* allocate lists if needed */
    if ( cfg->c_meta_files == NULL ) {
	cfg->c_meta_files_cap = IOR_META_INIT_FILES;
	cfg->c_meta_dirs_cap = IOR_META_INIT_DIRS;
	cfg->c_meta_files = (char **) calloc( cfg->c_meta_files_cap, sizeof( char * ));
	cfg->c_meta_dirs = (char **) calloc( cfg->c_meta_dirs_cap, sizeof( char * ));
	if ( !cfg->c_meta_files || !cfg->c_meta_dirs ) {
	    ior_error( cfg, "Failed to allocate metadata file lists" );
	    return( -1 );
	}
    }

    cfg->c_meta_nfiles = 0;
    cfg->c_meta_ndirs = 0;

    return( ior_meta_scan_dir_r( cfg, base_dir, 0 ));
}

/*
 * ior_meta_fileio - perform a file-based read or write against a random file
 *
 *   For mixed meta+IO tests where the device is a directory.
 *   Opens a random file, seeks to a random offset, reads or writes io_size bytes, closes.
 */
int	ior_meta_fileio( ior_config *cfg, const char *filepath, long io_size, int is_read, double *resp )
{
    int		result = 0;
    int		fd;
    long	start_sec, start_usec, end_sec, end_usec;
    double	resp_time;
    struct stat	st;
    off_t	offset = 0;
    ssize_t	bytes;
    char	*buf;

    if ( !filepath || io_size < 1 ) return( -1 );

    buf = (char *) malloc( io_size );
    if ( !buf ) return( -1 );

    ior_time_usec( cfg, &start_sec, &start_usec );

    fd = open( filepath, is_read ? O_RDONLY : O_RDWR );
    if ( fd < 0 ) {
	/* if O_RDWR fails (e.g. read-only NFS), fall back to read */
	if ( !is_read ) fd = open( filepath, O_RDONLY );
	if ( fd < 0 ) {
	    free( buf );
	    *resp = 0.0;
	    return( -1 );
	}
	is_read = 1;
    }

    /* seek to a random offset within the file */
    if ( fstat( fd, &st ) == 0 && st.st_size > io_size ) {
	offset = (off_t)( ior_rand( cfg ) % (HUGE)( st.st_size - io_size ));
	lseek( fd, offset, SEEK_SET );
    }

    if ( is_read ) {
	bytes = read( fd, buf, io_size );
    } else {
	memset( buf, 0xAA, io_size );
	bytes = write( fd, buf, io_size );
    }
    (void) bytes;  /* we don't fail on short reads for this */

    close( fd );

    ior_time_usec( cfg, &end_sec, &end_usec );

    resp_time = (( end_sec - start_sec ) * 1000000 +
		end_usec - start_usec ) / 1000.0;

    *resp = resp_time;
    free( buf );
    return( result );
}

/*
 * ior_meta_filecreate - create a new file in base_dir and write io_size bytes
 *
 *   Generates a unique filename per process using pid + monotonic counter.
 *   Measures the combined create+write+close time as the operation latency.
 *   Files are left in place (they accumulate during the test run).
 */
int	ior_meta_filecreate( ior_config *cfg, const char *base_dir, long io_size, double *resp )
{
    char		path[4096];
    static long		fc_counter = 0;
    static char		*fc_buf = NULL;
    static long		fc_buf_size = 0;
    long		start_sec, start_usec, end_sec, end_usec;
    int			fd;
    int			result = 0;
    ssize_t		written;

    if ( !base_dir || io_size < 1 ) {
	*resp = 0.0;
	return( -1 );
    }

    /* Allocate/grow the write buffer once; never freed (lives for the process lifetime) */
    if ( io_size > fc_buf_size ) {
	char *new_buf = (char *) realloc( fc_buf, io_size );
	if ( !new_buf ) {
	    *resp = 0.0;
	    return( -1 );
	}
	memset( new_buf + fc_buf_size, 0xCC, io_size - fc_buf_size );
	fc_buf = new_buf;
	fc_buf_size = io_size;
    }

    snprintf( path, sizeof( path ), "%s/ior_fc_%d_%ld.tmp",
	    base_dir, (int) getpid(), ++fc_counter );

    ior_time_usec( cfg, &start_sec, &start_usec );

    fd = open( path, O_WRONLY | O_CREAT | O_TRUNC, 0644 );
    if ( fd < 0 ) {
	*resp = 0.0;
	return( -1 );
    }

    written = write( fd, fc_buf, io_size );
    if ( written != (ssize_t) io_size ) {
	result = -1;
    }
    close( fd );

    ior_time_usec( cfg, &end_sec, &end_usec );

    *resp = (( end_sec - start_sec ) * 1000000 + end_usec - start_usec ) / 1000.0;
    return( result );
}

int ior_enum( ior_config *cfg, double *io_resp )
{
    int result = 0;
    long start_sec, start_usec, end_sec, end_usec;
    int listed_count = 0;
    double resp_time;
    ior_device *cur_dev = &( cfg->c_devs[ cfg->c_cur_dev ] );

    if ( cfg->c_verbose ) {
        sprintf( msg_buf, "Enumerating keys in bucket %s ", cur_dev->d_bucket );
        ior_verbose( cfg, msg_buf );
    }

    ior_time_usec( cfg, &start_sec, &start_usec );

    cfg->c_last_enum_objects = 0;

    if (cur_dev->d_is_s3) {
        result = s3_list_bucket(cur_dev, 0, &listed_count);
        if ( result != 0 ) {
            ior_error( cfg, "S3 enum failed while listing bucket objects" );
        }
        cfg->c_last_enum_objects = (unsigned long long) listed_count;
    } else {
        result = -1;
        ior_error( cfg, "ENUM requested for non-S3 device" );
    }

    ior_time_usec( cfg, &end_sec, &end_usec );
    resp_time = (( end_sec - start_sec ) * 1000000 + end_usec - start_usec ) / 1000.0;
    if ( io_resp != NULL ) {
        *io_resp = resp_time;
    }

    return result;
}
