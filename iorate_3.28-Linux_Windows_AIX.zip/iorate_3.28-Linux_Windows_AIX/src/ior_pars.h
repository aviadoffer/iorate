/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    IOR_L_NUMBER = 258,            /* IOR_L_NUMBER  */
    IOR_L_STRING = 259,            /* IOR_L_STRING  */
    IOR_L_STRING_WITH_NEWLINE = 260, /* IOR_L_STRING_WITH_NEWLINE  */
    IOR_L_KB = 261,                /* IOR_L_KB  */
    IOR_L_MB = 262,                /* IOR_L_MB  */
    IOR_L_GB = 263,                /* IOR_L_GB  */
    IOR_L_TB = 264,                /* IOR_L_TB  */
    IOR_L_PB = 265,                /* IOR_L_PB  */
    IOR_L_SECONDS = 266,           /* IOR_L_SECONDS  */
    IOR_L_MINUTES = 267,           /* IOR_L_MINUTES  */
    IOR_L_HOURS = 268,             /* IOR_L_HOURS  */
    IOR_L_DEVICE = 269,            /* IOR_L_DEVICE  */
    IOR_L_PATTERN = 270,           /* IOR_L_PATTERN  */
    IOR_L_TEST = 271,              /* IOR_L_TEST  */
    IOR_L_SEQUENTIAL = 272,        /* IOR_L_SEQUENTIAL  */
    IOR_L_RANDOM = 273,            /* IOR_L_RANDOM  */
    IOR_L_CAPACITY = 274,          /* IOR_L_CAPACITY  */
    IOR_L_MAXIMUM = 275,           /* IOR_L_MAXIMUM  */
    IOR_L_IGNORE = 276,            /* IOR_L_IGNORE  */
    IOR_L_OFFSET = 277,            /* IOR_L_OFFSET  */
    IOR_L_BLOCK = 278,             /* IOR_L_BLOCK  */
    IOR_L_ACCESS_KEY = 279,        /* IOR_L_ACCESS_KEY  */
    IOR_L_SECRET_KEY = 280,        /* IOR_L_SECRET_KEY  */
    IOR_L_BUCKET = 281,            /* IOR_L_BUCKET  */
    IOR_L_PUT = 282,               /* IOR_L_PUT  */
    IOR_L_GET = 283,               /* IOR_L_GET  */
    IOR_L_ENUM = 284,              /* IOR_L_ENUM  */
    IOR_L_IOPS = 285,              /* IOR_L_IOPS  */
    IOR_L_WRITE = 286,             /* IOR_L_WRITE  */
    IOR_L_READ = 287,              /* IOR_L_READ  */
    IOR_L_UNMAP = 288,             /* IOR_L_UNMAP  */
    IOR_L_BLOCKING = 289,          /* IOR_L_BLOCKING  */
    IOR_L_SIZE = 290,              /* IOR_L_SIZE  */
    IOR_L_PAUSE = 291,             /* IOR_L_PAUSE  */
    IOR_L_FROM = 292,              /* IOR_L_FROM  */
    IOR_L_FOR = 293,               /* IOR_L_FOR  */
    IOR_L_IO = 294,                /* IOR_L_IO  */
    IOR_L_TARGET = 295,            /* IOR_L_TARGET  */
    IOR_L_AT = 296,                /* IOR_L_AT  */
    IOR_L_ONLY = 297,              /* IOR_L_ONLY  */
    IOR_L_TEMP = 298,              /* IOR_L_TEMP  */
    IOR_L_CREATE = 299,            /* IOR_L_CREATE  */
    IOR_L_LOCK = 300,              /* IOR_L_LOCK  */
    IOR_L_ZONE = 301,              /* IOR_L_ZONE  */
    IOR_L_HISTORY = 302,           /* IOR_L_HISTORY  */
    IOR_L_REUSE = 303,             /* IOR_L_REUSE  */
    IOR_L_COUNT = 304,             /* IOR_L_COUNT  */
    IOR_L_LIMIT = 305,             /* IOR_L_LIMIT  */
    IOR_L_COPY = 306,              /* IOR_L_COPY  */
    IOR_L_SKEW = 307,              /* IOR_L_SKEW  */
    IOR_L_SEED = 308,              /* IOR_L_SEED  */
    IOR_L_CORRELATE = 309,         /* IOR_L_CORRELATE  */
    IOR_L_AREA = 310,              /* IOR_L_AREA  */
    IOR_L_SHIFT = 311,             /* IOR_L_SHIFT  */
    IOR_L_META = 312,              /* IOR_L_META  */
    IOR_L_STAT = 313,              /* IOR_L_STAT  */
    IOR_L_OPENCLOSE = 314,         /* IOR_L_OPENCLOSE  */
    IOR_L_READDIR = 315,           /* IOR_L_READDIR  */
    IOR_L_FILECREATE = 316,        /* IOR_L_FILECREATE  */
    IOR_L_UNKNOWN = 317,           /* IOR_L_UNKNOWN  */
    CAPACITY = 318                 /* CAPACITY  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
