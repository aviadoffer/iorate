/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IOR_L_NUMBER = 258,
     IOR_L_STRING = 259,
     IOR_L_STRING_WITH_NEWLINE = 260,
     IOR_L_KB = 261,
     IOR_L_MB = 262,
     IOR_L_GB = 263,
     IOR_L_TB = 264,
     IOR_L_PB = 265,
     IOR_L_SECONDS = 266,
     IOR_L_MINUTES = 267,
     IOR_L_HOURS = 268,
     IOR_L_DEVICE = 269,
     IOR_L_PATTERN = 270,
     IOR_L_TEST = 271,
     IOR_L_SEQUENTIAL = 272,
     IOR_L_RANDOM = 273,
     IOR_L_CAPACITY = 274,
     IOR_L_MAXIMUM = 275,
     IOR_L_IGNORE = 276,
     IOR_L_OFFSET = 277,
     IOR_L_BLOCK = 278,
     IOR_L_IOPS = 279,
     IOR_L_WRITE = 280,
     IOR_L_READ = 281,
     IOR_L_SIZE = 282,
     IOR_L_PAUSE = 283,
     IOR_L_FROM = 284,
     IOR_L_FOR = 285,
     IOR_L_IO = 286,
     IOR_L_TARGET = 287,
     IOR_L_AT = 288,
     IOR_L_ONLY = 289,
     IOR_L_TEMP = 290,
     IOR_L_CREATE = 291,
     IOR_L_LOCK = 292,
     IOR_L_ZONE = 293,
     IOR_L_HISTORY = 294,
     IOR_L_REUSE = 295,
     IOR_L_COUNT = 296,
     IOR_L_LIMIT = 297,
     IOR_L_COPY = 298,
     IOR_L_SKEW = 299,
     IOR_L_SEED = 300,
     IOR_L_CORRELATE = 301,
     IOR_L_AREA = 302,
     IOR_L_SHIFT = 303,
     IOR_L_UNKNOWN = 304,
     CAPACITY = 305
   };
#endif
/* Tokens.  */
#define IOR_L_NUMBER 258
#define IOR_L_STRING 259
#define IOR_L_STRING_WITH_NEWLINE 260
#define IOR_L_KB 261
#define IOR_L_MB 262
#define IOR_L_GB 263
#define IOR_L_TB 264
#define IOR_L_PB 265
#define IOR_L_SECONDS 266
#define IOR_L_MINUTES 267
#define IOR_L_HOURS 268
#define IOR_L_DEVICE 269
#define IOR_L_PATTERN 270
#define IOR_L_TEST 271
#define IOR_L_SEQUENTIAL 272
#define IOR_L_RANDOM 273
#define IOR_L_CAPACITY 274
#define IOR_L_MAXIMUM 275
#define IOR_L_IGNORE 276
#define IOR_L_OFFSET 277
#define IOR_L_BLOCK 278
#define IOR_L_IOPS 279
#define IOR_L_WRITE 280
#define IOR_L_READ 281
#define IOR_L_SIZE 282
#define IOR_L_PAUSE 283
#define IOR_L_FROM 284
#define IOR_L_FOR 285
#define IOR_L_IO 286
#define IOR_L_TARGET 287
#define IOR_L_AT 288
#define IOR_L_ONLY 289
#define IOR_L_TEMP 290
#define IOR_L_CREATE 291
#define IOR_L_LOCK 292
#define IOR_L_ZONE 293
#define IOR_L_HISTORY 294
#define IOR_L_REUSE 295
#define IOR_L_COUNT 296
#define IOR_L_LIMIT 297
#define IOR_L_COPY 298
#define IOR_L_SKEW 299
#define IOR_L_SEED 300
#define IOR_L_CORRELATE 301
#define IOR_L_AREA 302
#define IOR_L_SHIFT 303
#define IOR_L_UNKNOWN 304
#define CAPACITY 305




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

